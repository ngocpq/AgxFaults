package gov.nasa.jpf.jvm;

public class SkipAnnotation extends RuntimeException {

}
