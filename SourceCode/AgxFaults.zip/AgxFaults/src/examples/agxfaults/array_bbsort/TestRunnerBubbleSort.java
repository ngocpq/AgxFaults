package agxfaults.array_bbsort;
public class TestRunnerBubbleSort {
	
	static int[] input_a;	
	private static int[] out_expected;
	
	public static void main(String[] argv) {
		//argv=new String[]{"1","3","2","4"};		
		//argv=new String[]{"2","1","3"};
		if (argv.length < 1) {
			System.out.println("Error: Command line arguments are: x array");			
			System.exit(1);
		}
		input_a = new int[argv.length];
		for(int i=0;i<argv.length;i++)
			input_a[i]=Integer.parseInt(argv[i]);
		
		out_expected = input_a.clone();
		bubbleSort_golden(out_expected);
		
		run_agx();
		System.out.println("finish");
	}

	private static void run_agx() {		
		run_symb(input_a);
	}

	private static void run_symb(int[] a) {
		BubbleSort.bubbleSort(a);
		checkAssert(a);
	}

	private static void checkAssert(int[] out) {
		for(int i=0;i<out_expected.length;i++)
			assert out_expected[i] == out[i];
	}

	static void bubbleSort_golden(int[] tab) {
		int i = 0;
		int j = tab.length;
		int aux = 0;
		int fini = 0;
		while (fini == 0) {
			fini = 1;
			i = 1;
			while (i < j) {
				/* @ assert (i > 0 && i < tab.length); */
				if (tab[i - 1] > tab[i]) {
					aux = tab[i - 1];
					tab[i - 1] = tab[i];
					tab[i] = aux;
					fini = 0;
				}
				i = i + 1;
			}
			j = j - 1;
		}
		return;
	}

}