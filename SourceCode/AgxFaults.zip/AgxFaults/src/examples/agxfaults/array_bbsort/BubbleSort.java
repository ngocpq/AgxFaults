package agxfaults.array_bbsort;
public class BubbleSort {
	//[3,1,2] => [1,2,3]
	static void bubbleSort1(int[] arr) {
		int i=1;		
		int tmp = arr[i]; //err: tmp = arr[i-1]					
		arr[i - 1] = arr[i];
		arr[i] = tmp; //[1,1,2]		
		i=2;
		tmp = arr[i - 1];				
		arr[i - 1] = arr[i];
		arr[i] = tmp; //[1,2,1]
		return; //expected is [1,2,3] 
	}

	static void bubbleSort2(int[] arr) {
		int i=1;		
		int tmp = arr[i-1]; //err: tmp = arr[i-1]
		try{
			if (i<arr.length){
				arr[i - 1] = arr[i];
			}
			arr[i] = tmp; //[1,1,2]
		}catch (Exception ex){
			
		}		
		return; //expected is [1,2,3] 
	}
	
	static void bubbleSort(int[] arr) {
		int i = 0;
		int j = arr.length;
		int aux = 0;
		int fini = 0;
		while (fini == 0) {
			fini = 1;
			i = 1;
			while (i < j) { 
				if (arr[i - 1] > arr[i]) {					
					aux = arr[i];				
					arr[i - 1] = arr[i];
					arr[i] = aux;
					fini = 0;
				}				
				i = i + 1;			
			}
			j = j - 1;
		}
		return;
	}
	
}
