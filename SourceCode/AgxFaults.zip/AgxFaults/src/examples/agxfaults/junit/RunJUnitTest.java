
package agxfaults.junit;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

import junit.framework.TestCase;

public class RunJUnitTest {
	static String testClassName ;
	static String testMethod ;
	static Request request;
	
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException{				
		testClassName =args[0];
		testMethod = args[1];
		System.out.println("args size: "+args.length);
		System.out.println("testClass: "+testClassName+", method: "+testMethod);						
		runUnitTest();		
	}
	
	public static void runUnitTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		Class<?> clzz = Class.forName(testClassName);
		Object instance =null;
		try {
			instance = clzz.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			Constructor<?> contructor = clzz.getConstructor(String.class);
			instance = contructor.newInstance(testMethod);
		}			
		Method method = clzz.getMethod(testMethod);
		method.invoke(instance);
	}
	
//	public static void main2(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {				
//		testClassName =args[0];
//		testMethod = args[1];
//		System.out.println("args size: "+args.length);
//		System.out.println("testClass: "+testClassName+", method: "+testMethod);		
//		request = Request.method(Class.forName(testClassName),testMethod);		
//		Result result = runUnitTest();
//		if (result==null)
//			return;		
//		System.out.println("Success?  "+result.wasSuccessful());		
//		System.out.println("#Test: "+result.getRunCount());
//		System.out.println("Run: "+result.getRunCount());
//		System.out.println("Ignore: "+result.getIgnoreCount());
//		System.out.println("Failure: "+result.getFailureCount());
//		int i=1;
//		for(Failure f:result.getFailures()){
//			System.out.println("\t"+(i++)+") "+f.getMessage());
//			System.out.println("\t\t"+f.getTrace());
//		}		
//	}
//	public static Result runAllUnitTest(String testClassName) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
//		System.out.println(testClassName);		
//		JUnitCore junit = new JUnitCore();
//		Class<?> testClass= Class.forName(testClassName);
//    Result result = junit.run(testClass);
//		return result;
//	}
//	
//	public static Result runUnitTest1() throws ClassNotFoundException{
//		request = Request.method(Class.forName(testClassName),testMethod);
//		JUnitCore junit = new JUnitCore();		
//    Result result = junit.run(request);    
//    assert result.wasSuccessful();
//    return result;
//	}
	
}
