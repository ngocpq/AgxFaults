package agxfaults.array;

public class ArrayInitKO{

	/*@ requires 
   @(\forall int k;(k >= 0 && k < a.length);a[k] == 0);
   @ ensures 
   @ (a[8] != 0); 
   @*/
	int arrayInit(int[] a){
		int i;
		i = 0;
		while (i < a.length) {
			a[i] = 0; // error in the assignment : should be "a[i]=i+1"
			i = i + 1;
		}
		return 0;
	}
	
	public static void main(String[] args) {
		test();
	}

	static int n;
	private static void test() {
		int[] a = new int[2];
		for(int i=0;i<a.length;i++)
			a[i]=0;
		n = a.length;
		testSymb(a);
	}

	private static void testSymb(int[] a) {
		ArrayInitKO obj = new ArrayInitKO();
		obj.arrayInit(a);
		
		int[] b = obj.arrayInit_golden();
		for(int i=0;i<a.length;i++)
			assert a[i] == b[i];
	}

	private int[] arrayInit_golden() {
		int[] a = new int[n];		
		int i;
		i = 0;
		while (i < a.length) {
			a[i] = i+1;
			i = i + 1;
		}
		return a;
	}

}
