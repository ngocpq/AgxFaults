package agxfaults.tcas;

import agxfaults.tcas.v2.tcas;
public class RunTCAS {
	public static void main(String[] args) {
		//try{
			runtcas_agx();
//		}catch (AssertionError ex){
//			System.out.println("exception");
//		}		
	}
	
	public static int runtcas(int cur_Vertical_Sep, boolean high_Confidence, boolean two_of_Three_Reports_Valid,
			int own_Tracked_Alt, int own_Tracked_Alt_Rate, int other_Tracked_Alt, int alt_Layer_Value, int up_Separation,
			int down_Separation, int other_RAC, int other_Capability, int climb_Inhibit) {

		tcas p=new tcas();
		p.initialize();
		p.Cur_Vertical_Sep = cur_Vertical_Sep;
		p.High_Confidence = high_Confidence;
		p.Two_of_Three_Reports_Valid = two_of_Three_Reports_Valid;
		p.Own_Tracked_Alt = own_Tracked_Alt;
		p.Own_Tracked_Alt_Rate = own_Tracked_Alt_Rate;
		p.Other_Tracked_Alt = other_Tracked_Alt;
		p.Alt_Layer_Value = alt_Layer_Value;
		p.Up_Separation = up_Separation;
		p.Down_Separation = down_Separation;
		p.Other_RAC = other_RAC;
		p.Other_Capability = other_Capability;
		p.Climb_Inhibit = climb_Inhibit;
		int out = p.alt_sep_test();
		checkAssert(out);
		return out;
				
	}
	
	private static void checkAssert(int out) {		
		assert out==expectedOut;
	}

	static int cur_Vertical_Sep=890;
	static boolean high_Confidence=true;
	static boolean two_of_Three_Reports_Valid=false;
	static int own_Tracked_Alt=0;
	static int own_Tracked_Alt_Rate=577;
	static int other_Tracked_Alt=622;
	static int alt_Layer_Value=0;
	static int up_Separation=0;
	static int down_Separation=284;
	static int other_RAC=0;
	static int other_Capability=2;
	static int climb_Inhibit=1;
	
	private static int expectedOut;
	
	public static int runtcas_agx() {
		expectedOut = run_goldtcas(); 
		int out = runtcas(cur_Vertical_Sep, high_Confidence, two_of_Three_Reports_Valid, own_Tracked_Alt,own_Tracked_Alt_Rate, other_Tracked_Alt, alt_Layer_Value, up_Separation, down_Separation, other_RAC,other_Capability, climb_Inhibit);
		return out;
	}		
	
	static int run_goldtcas() {
//		cur_Vertical_Sep=890;
//		high_Confidence=true;
//		two_of_Three_Reports_Valid=false;
//		own_Tracked_Alt=0;
//		own_Tracked_Alt_Rate=577;
//		other_Tracked_Alt=622;
//		alt_Layer_Value=0;
//		up_Separation=0;
//		down_Separation=284;
//		other_RAC=0;
//		other_Capability=2;
//		climb_Inhibit=1;
		
		tcas_gold p=new tcas_gold();
		p.initialize();
		p.Cur_Vertical_Sep = cur_Vertical_Sep;
		p.High_Confidence = high_Confidence;
		p.Two_of_Three_Reports_Valid = two_of_Three_Reports_Valid;
		p.Own_Tracked_Alt = own_Tracked_Alt;
		p.Own_Tracked_Alt_Rate = own_Tracked_Alt_Rate;
		p.Other_Tracked_Alt = other_Tracked_Alt;
		p.Alt_Layer_Value = alt_Layer_Value;
		p.Up_Separation = up_Separation;
		p.Down_Separation = down_Separation;
		p.Other_RAC = other_RAC;
		p.Other_Capability = other_Capability;
		p.Climb_Inhibit = climb_Inhibit;

		return p.alt_sep_test();
	}
}
