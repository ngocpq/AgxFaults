package agxfaults.example.loop;
public class LoopExample{
  /*@ ensures((res*res <= val) && (res+1)*(res+1) > val);*/
  int squareRoot(int val)
    {        
        int i = 1;
        int v = 0;
        int res = 0;
        while (v < val){
             v = v + 2*i + 1;
             i = i + 1; 
        }
        res = i; /*error: the instruction should be res = i - 1 */
        return res;
   }
  

	/*@ requires (n==20);
	  @ ensures (\result == 210);
	  @*/
	static int sum(int n) {
		int s = 0;
		int i = 1;
		int errorRank = 3;
		while (i <= n) {
			s = s + i;
			i = i + 1;
			if (i>=errorRank) {
				s=1;
			}			
		}
		return s;
	}
	
  public static void main(String[] args) {
	  LoopExample p = new LoopExample();
  	System.out.println(p.squareRoot(300));
  	System.out.println(p.sum(5));
  }
}
