package agxfaults.example.loop;

public class CodyWaiteTest{	 
    public static void main(String[] args) {
    	test();
	}
    public static void test(){
    	double xa=300;
        double xb = 0.0;
        int quadrant = 0;
        CodyWaite cw = new CodyWaite(xa, xb);
        quadrant = cw.getK() & 3;
        xa = cw.getRemA();
        xb = cw.getRemB();
        System.out.println("xa: "+xa);
        System.out.println("xb: "+xb);
        System.out.println("quadrant: "+quadrant);
        assert ((xa==1.5486979089696424)&&(xb==-8.782513579822683E-17)&&(quadrant==2));
    }
}