package agxfaults.example.mid;

public class Example {
	static boolean greater(int a,int b){
		return a>b;
	}
	static int foo2(int x,int y, int z){
	  int min = x;
	  int max = y; //max=x
	  if (greater(y,x))
	    max = y;
	  else
	    min = y;  
	  int mid = z;
	  if (greater(min,mid)){ //mid>min greater(mid,min)
	    if (greater(mid,max))
	      mid = max;
	  }else{
	    mid = min;
	  }
	  return mid;
	}

	static int foo_(int x,int y, int z){ //foo(3,1,2)	
		int min = x;
		int max = x;
		if (x<y){
			max = y;
		}else{
			min = y; 
		}
		int mid = y; //min=z  @\label{runningExp_line_error1}@
		if (mid>min){
			if (mid>max){ //mid<max @\label{runningExp_line_error2}@
				mid = max;
			}
		}else{
			mid = min;
		}
		return mid; //assert (mid==2)
	}	
	
	static int foox(int x,int y, int z){ //foo(3,1,2)	
		int min = x;
		int max = x;			
		if (max<y)
			max = y;
		else
			min = y; 	
		int mid = min; //min=z  @\label{runningExp_line_error1}@
		if (mid<max){
			if (mid<min)
				mid = min;
		}else
			mid = max;
		return mid; //assert (mid==2)
	}
	
	static int foo4(int x, int y, int z) {
		int min = x;
		int max = y; // max=x
		if (x < y)
			max = y;
		else
			min = y;
		int mid = z;
		if (mid < min) { // min<z
			if (mid > max)
				mid = max;
		} else {
			mid = min;
		}
		return mid;
	}
	
	static int foo5(int x, int y, int z) {
		int min = x;
		int max = y; // max=x
		if (x < y)
			max = y;
		else
			min = y;
		
		int mid = z;
		if (mid < min) { // min<z
			if (mid > max)
				mid = max;
		} else {
			mid = min;
		}
		return mid;
	}
	
	static int foo3(int x, int y, int z) {
		int min = x;
		int max = y; // max=x
		if (x < y)
			max = y;
		else
			min = y;
		int mid = z;
		if (mid < min) { // min<z
			if (mid > max)
				mid = max;
		} else {
			mid = min;
		}
		return mid;
	}
	
	static int foo6(int x, int y, int z) {
		int min = x;
		int max = x;
		int mid = y; // mid=z
		if (x < y)
			max = y;
		else
			min = y;			
		if (mid < min) { // mid<=min
			if (mid > max)
				mid = max;
		} else {
			mid = min;
		}
		return mid;
	}
	
	static int foo1(int x,int y, int z){ //foo(3,1,2)	
		int min = x;
		int max = x;
		if (x<y){
			max = y;
		}else{
			min = x; //min=y  @\label{runningExp_line_error1}@
		}
		int mid = z; 
		if (mid<min){
			mid = min;
		}else{
			if (mid<max){ //mid>max @\label{runningExp_line_error2}@
				mid = max;
			}			
		}
		return mid; //assert (mid==2)
	}
	
	
	
	void testFoo(){
		int x=3,y=1,z=2;
		assert (foo(x, y, z)==2);
		assert (foo(x, z, y)==2);
		assert (foo(y, x, z)==2);
	}
	
	int compare(int a, int b){
		if (a==b)
			return 0;
		else if (a<b)
			return -1;
		else 
			return 1;
	}
	
	static int foo_x(int x,int y, int z){ //foo(3,1,2)	
		int min = x;
		int max = x;			
		if (Integer.compare(x, y) == -1)
			max = y;
		else
			min = y; 	
		int mid = min; //min=z  @\label{runningExp_line_error1}@
		if (Integer.compare(mid, max)==-1){
			if (mid<min)
				mid = min;
		}else
			mid = max;
		return mid; //assert (mid==2)
	}
	
	static int foo(int x,int y, int z){ //foo(3,1,2)	
		int min = x;
		int max = x;			
		if (x< y)
			max = y;
		else
			min = y; 	
		int mid = min; //min=z  @\label{runningExp_line_error1}@
		if (mid< max){
			if (mid<min)
				mid = min;
		}else
			mid = max;
		return mid; //assert (mid==2)
	}

	public static void main(String[] args) {
		System.out.println("foo(3, 2, 1): "+foo(3, 2, 1));
		System.out.println("foo(3, 1, 2): "+foo(3, 1, 2));
		System.out.println("foo(1, 3, 2): "+foo(1, 3, 2));
		
		System.out.println("foo(1, 2, 3): "+foo(1, 2, 3));
		
		System.out.println("foo(2, 1, 3): "+foo(2, 1, 3));
		System.out.println("foo(2, 3, 1): "+foo(2, 3, 1));
		
		
		
//		int x=3,y=1,z=2;
//  	//assert (foo(x,z,y)==2);
//  	assert (foo(x,y,z)==2);
//  	assert (foo(y,x,z)==2);
//  	assert (Example.foo(z,x,y)==2);
	}
	
//	static int max(int x,int y){
//		int rs = x;
//		if (rs<y)
//			rs = y;
//		return rs;
//	}
//	static int mid(int x,int y, int z){
//	  int a = max(x,y);
//		int b = max(y,z);
//		int rs;
//		if (a<b)
//			rs = a;
//		else
//			rs = b;	
//	  return rs;
//	}
}
