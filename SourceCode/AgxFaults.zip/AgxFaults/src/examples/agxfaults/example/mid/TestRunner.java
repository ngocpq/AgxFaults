/* The nearest integer square root function with a bug */
package agxfaults.example.mid;
public class TestRunner{	
  public static void main(String[] args) {
  	//args = new String[]{"3","1","2"};
  	if (args==null || args.length<3){
  		run_test();
  		return;
  	}  	
  	input_x=Integer.parseInt(args[0]);
  	input_y=Integer.parseInt(args[1]);
  	input_z=Integer.parseInt(args[2]);
  	expected_out=foo_golden(input_x,input_y,input_z);
  	run_agx();  	
  }
  
  static int input_x,input_y,input_z;
	private static int expected_out;
	
  public static void run_agx(){  	
  	run_symb(input_x,input_y,input_z);
  }
  
  private static void run_symb(int x, int y,int z) {
		int rs=Example.foo(x,y,z);
		assert rs==expected_out;
	}
  
  public static void run_test(){  	
//  	assert Example.foo(3,2,1)==2;
  	assert Example.foo(3,1,2)==2;
//  	assert Example.foo(1,2,3)==2;
  }
  
  static int foo_golden (int x, int y, int z) {
  	int min = x;
		int max = x; 
		if (x<y)
			max = y;
		else
			min = y;
		
		int mid = z;
		if (mid>min){
			if (mid>max)
				mid = max;
		}else{
			mid = min;
		}
		return mid;
	}
}
