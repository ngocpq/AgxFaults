/* The nearest integer square root function with a bug */
package agxfaults.example.loop_sum;
public class Sum{
	/*@ requires (n == 5);
  @ ensures (\result == (n*(n+1))/2);@*/
	int sum (int n) {
		int s = 0;
		int i = 0;
		while (i < n) {
			s = s + i;
			i = i + 1;			
		}
		return s;
	}
//
//  public static void main(String[] args) {
//  	test_sum();  	
//  }
//  
//  public static void test_sum(){
//  	Sum p = new Sum();
//  	int n = 5;
//  	int result = p.sum(n);
//  	assert result == (n*(n+1))/2;
//  	//assert res==4;
//  }
}
