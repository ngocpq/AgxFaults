/* The nearest integer square root function with a bug */
package agxfaults.example.loop_sum;
public class TestSumV1{	
  public static void main(String[] args) {
  	test_sum();  	
  }
  
  public static void test_sum(){
  	int n = 5;
  	test_sum(n);
  }
  
  public static void test_sum(int n){
  	Sum p = new Sum();
  	int result = p.sum(n);
  	assert result == (n*(n+1))/2;
  	//assert res==4;
  }
}
