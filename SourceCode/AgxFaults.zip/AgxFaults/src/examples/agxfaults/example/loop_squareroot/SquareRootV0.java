/* The nearest integer square root function with a bug */
package agxfaults.example.loop_squareroot;
public class SquareRootV0{
  private static int expectedOut;
	private static int input;


	/*@ ensures((res*res <= val) && (res+1)*(res+1) > val);*/
  int squareRoot(int val)
    {        
        int i = 1;
        int v = 0;
        int res = 0;
        while (v < val){
             v = v + 2*i + 1;
             i = i + 1; 
        }
        res = i; /*error: the instruction should be res = i - 1 */
        return res;
   }

  public static void main(String[] args) {
  	test_squareRoot_agx();  	
  }

  static void test_squareRoot_symb(int val){
  	SquareRootV0 p = new SquareRootV0();  	
  	int out = p.squareRoot(val);
  	checkAssert(out);
  }
  private static void checkAssert(int out) {
  	//assert ((out*out <= input) && (out+1)*(out+1) > input);
  	assert out==expectedOut;
	}

	public static void test_squareRoot_agx(){
		input = 5;
  	expectedOut = gold_squareRoot(input);  	
  	test_squareRoot_symb(input);
  }
  
  
  static int gold_squareRoot(int val)
  {        
      int i = 1;
      int v = 0;
      int res = 0;
      while (v < val){
           v = v + 2*i + 1;
           i = i + 1; 
      }
      res =i - 1;
      return res;
 }
}
