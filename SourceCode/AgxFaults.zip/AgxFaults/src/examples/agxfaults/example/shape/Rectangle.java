package agxfaults.example.shape;

public class Rectangle extends Shape{
	private int width, height;
	
	public Rectangle(){}
	
	public Rectangle(int w,int h) {
		this.width = w;
		this.height = h;
	}
	
	@Override
	public double area() {
		return width*height;
	}

	@Override
	public void create() {
		// TODO Auto-generated method stub
		
	}

}
