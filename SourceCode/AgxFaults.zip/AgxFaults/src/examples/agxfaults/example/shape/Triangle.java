package agxfaults.example.shape;

public class Triangle extends Shape{
	enum TriType{
		SCALENE,
		SQUARE
	}
	
	int a,b,c;
	
	public Triangle(){}
	
	public Triangle(int a,int b, int c){
		if (a==0 || b==0 || c==0)
			throw new RuntimeException("invalid triangle");
		if ((a+b) <= c || (b+c) <= a || (a+c) <= b)
			throw new RuntimeException("invalid triangle");
		this.a = a;
		this.b = b;
		this.c = c;
	}
	
	public void create(){
		
	}
	
	
	
	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}
}
