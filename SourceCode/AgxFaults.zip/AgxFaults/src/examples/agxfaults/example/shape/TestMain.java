package agxfaults.example.shape;

public class TestMain {
	public static void main(String[] args) {
		int type = Integer.parseInt(args[0]);
		Shape shape;
		if (type == 1){
			shape = new Triangle();
		}else 
			shape = new Rectangle();
		
		shape.create();
		double a = shape.area();
		
		System.out.println("area is: "+a);
	}
}
