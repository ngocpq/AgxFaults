package agxfaults.example.shape;

public abstract class Shape{	
	public abstract void create();
	public abstract double area();
}
