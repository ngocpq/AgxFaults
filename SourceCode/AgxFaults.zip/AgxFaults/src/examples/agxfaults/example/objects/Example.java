package agxfaults.example.objects;

public class Example {
	static abstract class Shape{
		public abstract int perimeter();
	}
	
	static class Rectangle extends Shape{
		private int width, height;
		
		public Rectangle(int w,int h) {
			this.width = w;
			this.height = h;
		}
		
		@Override
		public int perimeter() {
			return (width+height)*2;
		}
	}

	static class Triangle extends Shape{		
		int a,b,c;
		
		public Triangle(){}
		
		public Triangle(int a,int b, int c){
			if (a==0 || b==0 || c==0)
				throw new RuntimeException("invalid triangle");
			if ((a+b) <= c || (b+c) <= a || (a+c) <= b)
				throw new RuntimeException("invalid triangle");
			this.a = a;
			this.b = b;
			this.c = c;
		}
		
		@Override
		public int perimeter() {
			return a+b+c;
		}
	}

	public static int foo(int x, int y, int z) {
		Shape a = new Rectangle(4, 5);
		int n=x;
		if (n>y)
			a= new Rectangle(6, 7);
		else
			a = new Rectangle(8, 9);
		Shape b = new Rectangle(1, 2);
		return a.perimeter()+b.perimeter();
	}
	
	public static int foo2(int x, int y, int z) {
		Shape a = new Rectangle(4, 5);
		int n=2;
		for(int i=0;i<n;i++)
			a= new Rectangle(6, 7);		
		Shape b = new Rectangle(1, 2);
		return a.perimeter()+b.perimeter();
	}
	
}
