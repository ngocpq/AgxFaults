package agxfaults.example.foo;
public class Example{
	static int foo (int x, int y) {
		int a,b; boolean c;
		b = x+y; 	
		if (x>=0)   
			a = x; //error: a = 2*x;@\label{lst_IlustrationProgram_line_error}@
		else
			a = -2*x;		
		if (a>=y) 
			b = x - y;		
		if (b<10)
			c = true;
		else
			c = false;		
		return b;
	}
	
	static int foo(int x,int y, int z){
		int max = x;
		int min = x;
		if (x<y)
			max = y;
		else
			min = y;
		
		int mid = z;
		if (z>min){
			if (z>max)
				mid = max;
		}else{
			mid = min;
		}
		return mid;
	}
	
	int compare(int a, int b){
		if (a==b)
			return 0;
		else if (a<b)
			return -1;
		else 
			return 1;
	}
	
	static int midNumber(int x,int y, int z){
		int max = x;
		int min = x;
		if (Integer.compare(x, y) == -1)
			max = y;
		else
			min = y;
		
		int mid = z;
		if (Integer.compare(z, min)==1){
			if (z>max)
				mid = max;
		}else{
			mid = min;
		}
		return mid;
	}
	
	
}
