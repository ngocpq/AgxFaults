/* The nearest integer square root function with a bug */
package agxfaults.example.foo;
public class TestRunner{	
  public static void main(String[] args) {
  	input_x=Integer.parseInt(args[0]);
  	input_y=Integer.parseInt(args[1]);
  	expected_out=foo_golden(input_x,input_y);
  	run_agx();  	
  }
  
  static int input_x,input_y;
	private static int expected_out;
  public static void run_agx(){  	
  	run_symb(input_x,input_y);
  }
  
  private static void run_symb(int x, int y) {
		int rs=Example.foo(x,y);
		assert rs==expected_out;
	}
  
  static int foo_golden (int x, int y) {
		int a,b; boolean c;
		b = x+y; 	
		if (x>=0)   
			a = 2*x;
		else
			a = -2*x;		
		if (a>=y) 
			b = x - y;		
		if (b<10)
			c = true;
		else
			c = false;		
		return b;
	}
}
