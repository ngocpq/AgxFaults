package agxfaults.array_summinmax;
public class SumMinMax {

	int foo(int[] a){
		int len = a.length;
		int min = a[0];
		int max = a[0];
		int i = 1;
		while (i < len){
			if (a[i]<min)
				min = a[i+1]; //ERR: min = a[i];
			if (a[i]>max)
				max = a[i];
			i = i+1;
		}
		return min+max;
	}
	
	public static void main(String[] args) {
		test();
	}

	static int[] b;
	private static int expected;
	private static void test() {
		int[] a = new int[]{2,4,1};		
		b=new int[a.length];
		for(int i=0;i<a.length;i++)
			b[i]=a[i];
		expected = minimum_golden(b);
		testSymb(a);
	}

	private static void testSymb(int[] a) {
		SumMinMax obj = new SumMinMax();
		int out = obj.foo(a);				
		assert out==expected;
	}

	static int minimum_golden(int[] a) {
		int len = a.length;
		int min = a[0];
		int max = a[0];
		int i = 1;
		while (i < len){
			if (a[i]<min)
				min = a[i];
			if (a[i]>max)
				max = a[i];
			i = i+1;
		}
		return min+max;
	}
}
