package agxfaults.loop.gcd;
public class GCD {

	static  int gcd(int a,int b) {
		if(a==0)
			return b;
			
		while(a != 0){ //a != 0 && b!=0
			if(a>b)
				a = a - b;
			else
				b = b - a;
			}
		return a;
	}
	
//	static  int gcd(int a,int b) {
//		if(a==0)
//			return b;
//			
//		while(a != 0){ //a != 0 && b!=0
//			if(a>b)
//				return gcd(a - b,b);
//			else
//				return gcd(a,b - a);
//			}
//		return a;
//	}
}
