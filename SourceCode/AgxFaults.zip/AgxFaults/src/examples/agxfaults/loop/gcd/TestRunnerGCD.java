package agxfaults.loop.gcd;
public class TestRunnerGCD {
	
	static int input_a,input_b;	
	private static int out_expected;
	
	public static void main(String[] argv) {
		//argv = new String[]{"4","12"};
		
		if (argv.length != 2) {
			System.out.println("Error: Command line arguments are: x array");			
			System.exit(1);
		}
		input_a = Integer.parseInt(argv[0]);
		input_b = Integer.parseInt(argv[1]);
		
		out_expected = gcd_golden(input_a, input_b);
				
		run_agx();
		System.out.println("finish");
	}

	private static void run_agx() {		
		run_symb(input_a,input_b);
	}

	private static void run_symb(int a,int b) {		
		checkAssert(GCD.gcd(a,b));
	}

	private static void checkAssert(int out) {		
		assert out_expected == out;
	}

	static int gcd_golden(int a,int b) {
		if(a==0)
			return b;
			
		while(b != 0){
			if(a >b)
				a = a - b;
			else
				b = b - a;
			}
		return a;
	}

}