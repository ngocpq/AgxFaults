package agxfaults.array_minimum;
/* The minimum in an array of n integers
 */

import java.util.Random;

public class MinimumKO {

	/*@ requires (a[0]==3 && a[1]==2 && a[2]==1 && a[3]==0); 
          @ ensures (min<=a[0] && min<=a[1] && min<=a[2] && min<=a[3]); 
	  @*/
//	int minimum (int[] a) {
//		int min=a[0];
//		int i = 1;
//		while (i<a.length-1) { /*error, the condition should be (i<a.length)*/
//       if (a[i]<=min){
//          min=a[i];
//       }
//		   i = i+1;
//		}
//		return min;
//	}
	
	int minimum (int[] a) {
		int i = 1;
		int min=a[1]; /*error, min = a[0] */
		while (i<a.length) { 
       if (a[i]<=min){
          min=a[i];
       }
		   i = i+1;
		}
		return min;
	}
	
	public static void main(String[] args) {
		test();
	}

	static int[] b;
	private static void test() {
		int[] a = new int[]{0,2,3};
		//int[] a = new int[]{2,3,4,5,6,1,0};
		
//		int n=100;
//		int[] a = new int[n];
//		Random rand = new Random(5);
//		for(int i=0;i<a.length;i++)
//			a[i] = rand.nextInt(100);
//		a[a.length-1] = -1;
		
		b=new int[a.length];
		for(int i=0;i<a.length;i++)
			b[i]=a[i];
		
		testSymb(a);
	}

	private static void testSymb(int[] a) {
		MinimumKO obj = new MinimumKO();
		int out = obj.minimum(a);		
		int min = obj.minimum_golden();
		assert out==min;
	}

	private int minimum_golden() {
		int min=b[0];
		int i = 1;
		while (i<=b.length-1) {
       if (b[i]<=min){
          min=b[i];
       }
		     i = i+1;
		}
		return min;
	}
}
