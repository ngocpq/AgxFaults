package siemens.replace;

public class RunReplace {
	public static void main(String[] args) {
		/*try{
			run();
		}catch (AssertionError ex){
			System.out.println("exception");
		}	
		*/
		try{
			run('a', '2', '&', 'a', 'a');
		}catch (AssertionError ex){
			System.out.println("exception");
		}	
	}
	
	public static void run() {
		replace.mainProcess('a', '2', '&', 'a', 'a');
	}
	
	public static void run(char i0, char i1, char i2, char i3, char i4){
		replace.mainProcess(i0,i1,i2,i3,i4);
	}
	
}
