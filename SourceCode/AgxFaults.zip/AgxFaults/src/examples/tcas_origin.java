public class tcas_origin {
	public int OLEV = 600;
	public int MAXALTDIFF = 600;
	public int MINSEP = 300;
	public int NOZCROSS = 100;

	public int Cur_Vertical_Sep;
	public boolean High_Confidence;
	public boolean Two_of_Three_Reports_Valid;

	public int Own_Tracked_Alt;
	public int Own_Tracked_Alt_Rate;
	public int Other_Tracked_Alt;

	public int Alt_Layer_Value; /* 0, 1, 2, 3 */
	public int[] Positive_RA_Alt_Thresh;

	public int Up_Separation;
	public int Down_Separation;

	/* state variables */
	public int Other_RAC; /* NO_INTENT, DO_NOT_CLIMB, DO_NOT_DESCEND */
	public int NO_INTENT = 0;
	public int DO_NOT_CLIMB = 1;
	public int DO_NOT_DESCEND = 2;

	public int Other_Capability; /* TCAS_TA, OTHER */
	public int TCAS_TA = 1;
	public int OTHER = 2;

	public int Climb_Inhibit; /* true/false */

	public int UNRESOLVED = 0;
	public int UPWARD_RA = 1;
	public int DOWNWARD_RA = 2;

	void initialize() {
		Positive_RA_Alt_Thresh = new int[4];
		Positive_RA_Alt_Thresh[0] = 400;
		Positive_RA_Alt_Thresh[1] = 500;
		Positive_RA_Alt_Thresh[2] = 640;
		Positive_RA_Alt_Thresh[3] = 740;
	}

	int ALIM() {
		return Positive_RA_Alt_Thresh[Alt_Layer_Value];
	}

	int Inhibit_Biased_Climb() {
		if (Climb_Inhibit > 0)
			return Up_Separation + MINSEP; // error: return Up_Separation + NOZCROSS
		else
			return Up_Separation;
		// return (Climb_Inhibit ? Up_Separation + MINSEP : Up_Separation);
	}

	boolean Non_Crossing_Biased_Climb() {
		boolean upward_preferred;
		int upward_crossing_situation;
		boolean result;		
		upward_preferred = Inhibit_Biased_Climb() > Down_Separation;
		if (upward_preferred) {
			result = !(Own_Below_Threat()) || ((Own_Below_Threat()) && (!(Down_Separation >= ALIM())));
		} else {
			result = Own_Above_Threat() && (Cur_Vertical_Sep >= MINSEP) && (Up_Separation >= ALIM());
		}
		return result;
	}

	boolean Non_Crossing_Biased_Descend() {
		boolean upward_preferred;
		int upward_crossing_situation;
		boolean result;
		upward_preferred = Inhibit_Biased_Climb() > Down_Separation;
		if (upward_preferred) {
			result = Own_Below_Threat() && (Cur_Vertical_Sep >= MINSEP) && (Down_Separation >= ALIM());
		} else {
			result = !(Own_Above_Threat()) || ((Own_Above_Threat()) && (Up_Separation >= ALIM()));
		}
		return result;
	}

	boolean Own_Below_Threat() {
		return (Own_Tracked_Alt < Other_Tracked_Alt);
	}

	boolean Own_Above_Threat() {
		return (Other_Tracked_Alt < Own_Tracked_Alt);
	}

	int alt_sep_test() {
		boolean enabled, tcas_equipped, intent_not_known;
		boolean need_upward_RA, need_downward_RA;
		int alt_sep;

		enabled = High_Confidence && (Own_Tracked_Alt_Rate <= OLEV) && (Cur_Vertical_Sep > MAXALTDIFF);
		tcas_equipped = Other_Capability == TCAS_TA;
		intent_not_known = Two_of_Three_Reports_Valid && Other_RAC == NO_INTENT;

		alt_sep = UNRESOLVED;

		if (enabled && ((tcas_equipped && intent_not_known) || !tcas_equipped)) {
			need_upward_RA = Non_Crossing_Biased_Climb() && Own_Below_Threat();
			need_downward_RA = Non_Crossing_Biased_Descend() && Own_Above_Threat();
			if (need_upward_RA && need_downward_RA)			
				alt_sep = UNRESOLVED;
			else if (need_upward_RA)
				alt_sep = UPWARD_RA;
			else if (need_downward_RA)
				alt_sep = DOWNWARD_RA;
			else
				alt_sep = UNRESOLVED;
		}

		return alt_sep;
	}

	public static void main(String[] argv) {
		argv = new String[]{"634","1","1","633","500","335","0","665","795","0","1","1"};
		int argc = argv.length + 1;
		if (argc < 13) {
			System.out.println("Error: Command line arguments are");
			System.out.println("Cur_Vertical_Sep, High_Confidence, Two_of_Three_Reports_Valid");
			System.out.println("Own_Tracked_Alt, Own_Tracked_Alt_Rate, Other_Tracked_Alt");
			System.out.println("Alt_Layer_Value, Up_Separation, Down_Separation");
			System.out.println("Other_RAC, Other_Capability, Climb_Inhibit");
			System.exit(1);
		}
		tcas_origin newtcas = new tcas_origin();
		newtcas.initialize();
		newtcas.Cur_Vertical_Sep = Integer.parseInt(argv[0] + "");
		if (Integer.parseInt(argv[1] + "") == 0) {
			newtcas.High_Confidence = false;
		} else {
			newtcas.High_Confidence = true;
		}
		if (Integer.parseInt(argv[2] + "") == 0) {
			newtcas.Two_of_Three_Reports_Valid = false;
		} else {
			newtcas.Two_of_Three_Reports_Valid = true;
		}
		newtcas.Own_Tracked_Alt = Integer.parseInt(argv[3] + "");
		newtcas.Own_Tracked_Alt_Rate = Integer.parseInt(argv[4] + "");
		newtcas.Other_Tracked_Alt = Integer.parseInt(argv[5] + "");
		newtcas.Alt_Layer_Value = Integer.parseInt(argv[6] + "");
		newtcas.Up_Separation = Integer.parseInt(argv[7] + "");
		newtcas.Down_Separation = Integer.parseInt(argv[8] + "");
		newtcas.Other_RAC = Integer.parseInt(argv[9] + "");
		newtcas.Other_Capability = Integer.parseInt(argv[10] + "");
		newtcas.Climb_Inhibit = Integer.parseInt(argv[11] + "");
		System.out.println(newtcas.alt_sep_test());
	}

}
