package gov.nasa.jpf.jfaults.bytecode.field;

import gov.nasa.jpf.jcfg.variable.StaticFieldVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.perturb.FieldPerturbator;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.ThreadInfo;

public class GETSTATIC extends gov.nasa.jpf.jvm.bytecode.GETSTATIC {

	public GETSTATIC(String fieldName, String clsDescriptor, String fieldDescriptor) {
		super(fieldName, clsDescriptor, fieldDescriptor);		
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Instruction execute(ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis == null)
			return super.execute(ti);		
		
		ElementInfo elementInfo = this.getElementInfo(ti);		
		LastModifiedLocationAttribute defAtt = elementInfo.getFieldAttr(this.getFieldInfo(), LastModifiedLocationAttribute.class);
				
		StaticFieldVariableStaticInfo varStaticInfo =  (StaticFieldVariableStaticInfo) VariableStaticInfo.getVariableStaticInfo(this);				
		FieldPerturbator<?> perturbator = new FieldPerturbator(elementInfo, (StaticFieldVariableStaticInfo) varStaticInfo);			
		if (defAtt==null){								
			defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
			perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);
		}else{				
				defAtt.setPerturbator(perturbator);				
		}
		Instruction nextInsn = analysis.executeLoadInstruction(ti,perturbator.getVariableStaticInfo(),defAtt, this);
		if (nextInsn!=null)
			return nextInsn;
		else
			return super.execute(ti);		
	}
}
