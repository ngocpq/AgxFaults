package gov.nasa.jpf.jfaults.bytecode.branch.helper;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.NumericBooleanExpression;
import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.vm.MJIEnv;
import gov.nasa.jpf.vm.StackFrame;

public class IFNULL_Info extends IfBranchInfo {

	public IFNULL_Info(IfInstruction insn, NumericComparator cmp) {
		super(insn, cmp);
	}

	@Override
	public Pair<Boolean> popBranchConditionValue(StackFrame sf) {
		Expression<?> exp = (Expression<?>) sf.getOperandAttr(Expression.class);
		if (exp == null){
			boolean condVal = this.instruction.popConditionValue(sf);
			Constant<Boolean> symVal = Constant.create(BuiltinTypes.BOOL, condVal);
			return new Pair<Boolean>(condVal,symVal); //concolic value
			//return new Pair<Boolean>(this.instruction.popConditionValue(sf), null); // concolic
		}
		boolean sat = this.instruction.popConditionValue(sf);		
		Expression<Integer> val = Constant.createCasted(BuiltinTypes.SINT32, MJIEnv.NULL);
		Expression<Boolean> symCondition;
		if (cmp == NumericComparator.EQ || cmp == NumericComparator.NE) // IFNULL
			symCondition = new NumericBooleanExpression(exp, cmp, val);
		else
			throw ContractUtils.unreachable("Invalid state");
		
		return new Pair<Boolean>(sat, symCondition);
	}

	@Override
	public boolean isSymbolicConditionValue(StackFrame sf) {
		Expression<?> symExp = sf.getOperandAttr(Expression.class);
		if (symExp == null) {
			return false;
		}
		return true;
	}

}
