package gov.nasa.jpf.jfaults.bytecode.assignment;

import java.util.ArrayList;
import java.util.List;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.jcfg.variable.LocalVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.MemoryModifiableInstruction;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.bytecode.heap.HeapNode;
import gov.nasa.jpf.jfaults.bytecode.heap.SymbolicHeap;
import gov.nasa.jpf.jfaults.objects.ISymbolicObject;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.jvm.bytecode.ASTORE;
import gov.nasa.jpf.vm.ClassInfo;
import gov.nasa.jpf.vm.ClassLoaderInfo;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

/**
 * Store reference into local variable
 * ..., objref => ...
 */
public class ASTORE_SSA extends ASTORE implements MemoryModifiableInstruction{

	public ASTORE_SSA(int index) {
		super(index);		
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Instruction execute (ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
			return super.execute(ti);
		StackFrame sf = ti.getModifiableTopFrame();
		LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getModifiableVariableStaticInfo(this);
		
		Expression symbVal = ConcolicUtil.peekAttr(sf, 0, varStaticInfo.getType(), Expression.class);
		if (varStaticInfo.isUnknowType()&&symbVal!=null)
			varStaticInfo.setType(symbVal.getType());
		
		Type<?> type = varStaticInfo.getType();
		
		analysis.analyzeReferenceLocalVarAssignmentExpr(ti, sf, this, type);				
		
		MemoryPerturbator<?> perturbator = new StackLocalVariablePerturbator(sf, varStaticInfo);				
		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, defAtt, LastModifiedLocationAttribute.class);		
		return super.execute(ti);
	}
	
	//localVarRef = heapIndex
	//if (!agxScope)
	//	normal
	//else
	//	symbObjHeapIdx = getOrMakeSymbolicObject(objRef)
	//	accessibleObj[] = explorePossibleAlternative(objType);
	//	(isAgx && (localVarSSA = symbObjHeapIdx)) || (!isAgx && localVarSSA = Select(accessibleObj))
	//	localVarRef = heapIndex
	//	symbVarRef = sym
	
//	@Override
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis == null)
//			return super.execute(ti);
//		
//		StackFrame sf = ti.getModifiableTopFrame();		
//		/**
//		 * TODO: symbolic object
//		 * localValRef = objref
//		 * =>
//		 * newSymbObj = !isAgx?symObjRef: select(null,new).
//		 */
//		
//		//get valueGuard
//		//get value guard constraint of operands
//		List<LastModifiedLocationAttribute> operandAtt = this.getOperandAttribute(ti,sf,LastModifiedLocationAttribute.class);
//		//TODO: make phi objects
//		
//		//execute concrete
//		Instruction nextInsn = super.execute(ti);
//		if (nextInsn == this)
//			return nextInsn;// not executed the statement yet.
//		
//		LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getModifiableVariableStaticInfo(this);
//		MemoryPerturbator<?> perturbator = new StackLocalVariablePerturbator(sf, varStaticInfo);
//		
//		//make angelic symbol
//		if (analysis.isSuspiciousScope(this)){
//			//get object heapIndex				
//			Expression symbObjRef = sf.getLocalAttr(this.getLocalVariableSlot(), Expression.class);
//			int concObjRef = sf.getLocalVariable(this.getLocalVariableSlot());
//			if (symbObjRef ==null){ //concrete object
//				symbObjRef = Constant.create(BuiltinTypes.SINT32, concObjRef);
//			}
//			
//			String typeOfLocalVar = this.getLocalVariableType();
////			ElementInfo ei = ti.getHeap().get(concObjRef);
////			ISymbolicObject symbObj = ei.getObjectAttr(ISymbolicObject.class);
////			
////			ClassInfo typeClassInfo = ClassLoaderInfo.getCurrentResolvedClassInfo(typeOfLocalVar);			
////			/*SymbolicHeap symHeap = analysis.getSymbolicHeap(ti,this);
////			HeapNode[] heapNodes = symHeap.getNodesOfType(typeClassInfo);
////			//get symbolic heap object: array
////			SymbolicHeap symHeap;*/
//			
//			List<ElementInfo> alternativeObjects = getAllLiveObjectOfType(ti,typeOfLocalVar);			
//			
//			//create new symbolic object			
//			//analysis.getOrCreateAngelicSymbolicObject(this, ti, sf, symbObjRef, concObjRef);
//			
//			//evaluate symbolic
//			//Instruction alternativeInsn = analysis.executeAssignmentInstruction(ti,sf,this,operandAtt);
//			Instruction alternativeInsn = analysis.perturbVariable(ti,sf,this,varStaticInfo,perturbator);
//			
//			if (alternativeInsn!=null)
//				nextInsn = alternativeInsn;			
//		}
//		
//		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//		perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);		
//		return nextInsn;		
//	}
	
	private List<ElementInfo> getAllLiveObjectOfType(ThreadInfo ti, String typeClassInfo) {
		//get all possible
		List<ElementInfo> alternativeObjects = new ArrayList<>();
		for(ElementInfo eiAliveObj:ti.getHeap().liveObjects()){
			if(eiAliveObj.getClassInfo().isInstanceOf(typeClassInfo)){
				alternativeObjects.add(eiAliveObj);					
			}
		}
		return alternativeObjects;
	}

	private List<ElementInfo> getAllReachableObjects(ThreadInfo ti, String typeClassInfo) {
		//get all local variable, fields and Global
		List<ElementInfo> alternativeObjects = new ArrayList<>();
		for(ElementInfo eiAliveObj:ti.getHeap().liveObjects()){
			if(eiAliveObj.getClassInfo().isInstanceOf(typeClassInfo)){
				alternativeObjects.add(eiAliveObj);					
			}
		}
		return alternativeObjects;
	}
	

	public <T> List<T> getOperandAttribute(ThreadInfo ti, StackFrame sf, Class<T> attrClazz) {
		List<T> lst = new ArrayList();
		lst.add(sf.getOperandAttr(attrClazz));
		return lst;
	}

	@Override
	public VariableStaticInfo getVariableStaticInfor() {
		return VariableStaticInfo.getModifiableVariableStaticInfo(this);
	}
}
