package gov.nasa.jpf.jcfg.variable;
import gov.nasa.jpf.jfaults.perturb.FieldPerturbator;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.FieldInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public class MemoryPerturbatorFactory {
	public static <T> MemoryPerturbator<T> createPerturbator(VariableStaticInfo<T> varInfo,ThreadInfo ti, StackFrame sf){
		if (varInfo instanceof LocalVariableStaticInfo){
			return new StackLocalVariablePerturbator<T>(sf,  (LocalVariableStaticInfo<T>) varInfo);
		}
		
		if (varInfo instanceof StaticFieldVariableStaticInfo){			
			FieldInfo fi = ((StaticFieldVariableStaticInfo<T>) varInfo).getFieldInfo();
			ElementInfo ei = fi.getClassInfo().getStaticElementInfo();			
			return new FieldPerturbator<T>(ei,(StaticFieldVariableStaticInfo<T>) varInfo);
		}
		//TODO: throw exception
		return null;
	}
}
