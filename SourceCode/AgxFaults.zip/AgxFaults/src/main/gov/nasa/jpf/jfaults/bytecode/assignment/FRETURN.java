package gov.nasa.jpf.jfaults.bytecode.assignment;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.util.ExpressionUtil;
import gov.nasa.jpf.jcfg.utils.InstructionUtil;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public class FRETURN extends gov.nasa.jpf.jvm.bytecode.FRETURN {
	public Instruction execute(ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
			return super.execute(ti);
		
		StackFrame sf = ti.getModifiableTopFrame();
		analysis.analyzePrimaryReturnValue(ti, sf, this);
		return super.execute(ti);
	}
	
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return super.execute(ti);
//		
//		StackFrame sf = ti.getModifiableTopFrame();
//		//get value guard constraint of operands
//		LastModifiedLocationAttribute opDefAtt = sf.getOperandAttr(LastModifiedLocationAttribute.class);
//		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(this,analysis);
//		//LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getModifiableVariableStaticInfo(this);
//		
//		Pair val = ConcolicUtil.peek(sf, BuiltinTypes.FLOAT);	
//		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
//			String varUniqueId = InstructionUtil.getUniqueIdString(this);
//			varUniqueId = "@PHI@"+varUniqueId;
//			val = analysis.getOrCreateSummaryVariablePair(this, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);			
//		}
//		
//		Pair updatedAttr = val;
//		if (analysis.isSuspiciousScope(this)){			
//			String varUniqueId = InstructionUtil.getUniqueIdString(this);
//			updatedAttr = analysis.getOrCreateAngelicVariable(this,varUniqueId, ti, sf, val.symb, val.conc);
//			//perturb stack operand
//			ConcolicUtil.perturbOperand(sf, 0, updatedAttr);
//		}
//		
//		MemoryPerturbator<?> perturbator = null;
//		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, val.symb.getType(), defAtt, LastModifiedLocationAttribute.class);
//		
//		return super.execute(ti);
//	}
}
