package gov.nasa.jpf.jcfg.cfg.wrap;
import gov.nasa.jpf.jcfg.cfg.InstructionBlock;
import gov.nasa.jpf.jcfg.cfg.VerifyArgument;
import gov.nasa.jpf.vm.ExceptionHandler;

public class ExceptionHandlerWrapper {
	//static HashMap<ExceptionHandler, ExceptionHandlerWrapper> buffer = new HashMap<>();

	/*public static ExceptionHandlerWrapper getWrapper(ExceptionHandler handler) {
		if (handler == null)
			return null;
		ExceptionHandlerWrapper wrapper = buffer.get(handler);
		if (wrapper == null) {
			wrapper = new ExceptionHandlerWrapper(handler);
			buffer.put(handler, wrapper);
		}
		return wrapper;
	}*/

	//////////////////////////
	private final ExceptionHandler _wrappedHandler;
	private ExceptionHandlerType _handlerType;
	private InstructionBlock _tryBlock;
	private InstructionBlock _handlerBlock;
	private String _catchType;

//	public ExceptionHandlerWrapper(ExceptionHandler handler) {
//		this.handler = handler;
//		
//	}

	private ExceptionHandlerWrapper(
			final ExceptionHandler handler,
			final InstructionBlock tryBlock,
	        final InstructionBlock handlerBlock,
	        final ExceptionHandlerType handlerType,
	        final String catchType) {
			
			_wrappedHandler = handler; 
	        _tryBlock = tryBlock;
	        _handlerBlock = handlerBlock;
	        _handlerType = handlerType;
	        _catchType = catchType;
	    }
	
	public static ExceptionHandlerWrapper createCatch(
			final ExceptionHandler handler,
	        final InstructionBlock tryBlock,
	        final InstructionBlock handlerBlock,
	        final String catchType) {

	        VerifyArgument.notNull(tryBlock, "tryBlock");
	        VerifyArgument.notNull(handlerBlock, "handlerBlock");
	        VerifyArgument.notNull(catchType, "catchType");

	        return new ExceptionHandlerWrapper(
        		handler,
	            tryBlock,
	            handlerBlock,
	            ExceptionHandlerType.Catch,
	            catchType
	        );
	    }

	    public static ExceptionHandlerWrapper createFinally(
    		final ExceptionHandler handler,	        
	        final InstructionBlock tryBlock,
	        final InstructionBlock handlerBlock) {

	        VerifyArgument.notNull(tryBlock, "tryBlock");
	        VerifyArgument.notNull(handlerBlock, "handlerBlock");

	        return new ExceptionHandlerWrapper(
	            handler,
        		tryBlock,
	            handlerBlock,
	            ExceptionHandlerType.Finally,
	            null
	        );
	    }
	    
	
	public final boolean isFinally() {
		return _handlerType == ExceptionHandlerType.Finally;
	}

	public final boolean isCatch() {
		return _handlerType == ExceptionHandlerType.Catch;
	}

	public final InstructionBlock getTryBlock() {
		return _tryBlock;
	}

	public final InstructionBlock getHandlerBlock() {
		return _handlerBlock;
	}

	public final ExceptionHandlerType getHandlerType() {
		return _handlerType;
	}

	public ExceptionHandler getExceptionHandler() {
		return this._wrappedHandler;
	}

	public String getCatchType() {
		return this._catchType;
	}

//	public static List<ExceptionHandlerWrapper> getExceptionHandlerWrappers(MethodInfo mi) {
//		List<ExceptionHandlerWrapper> handlers = new ArrayList<>();
//		final Instruction lastInstruction = mi.getLastInsn();
//
//		for (ExceptionHandler entry : mi.getExceptions()) {
//			final InstructionBlock tryBlock;
//			if (entry.getEnd() == lastInstruction.getPosition() + lastInstruction.getLength()) {
//				tryBlock = new InstructionBlock(mi.getInstructionAt(entry.getBegin()), lastInstruction);
//			} else {
//				tryBlock = new InstructionBlock(mi.getInstructionAt(entry.getBegin()),
//						mi.getInstructionAt(entry.getEnd()).getPrev());
//			}
//			
//			handlerStart 
//			
//			if (entry.getName() == null) {
//                handlers.add(
//                    ExceptionHandlerWrapper.createFinally(entry,
//                        tryBlock,
//                        new InstructionBlock(handlerStart.getStart(), lastOrDefault(dominatedNodes).getEnd())
//                    )
//                );
//            }
//            else {
//                handlers.add(
//                    ExceptionHandler.createCatch(entry,
//                        tryBlock,
//                        new InstructionBlock(handlerStart.getStart(), lastOrDefault(dominatedNodes).getEnd()),
//                        entry.getCatchType()
//                    )
//                );
//            }
//			
//			// exceptionHandlers.add(ExceptionHandlerWrapper.getWrapper(handler));
//		}
//		return exceptionHandlers;
//	}
}
