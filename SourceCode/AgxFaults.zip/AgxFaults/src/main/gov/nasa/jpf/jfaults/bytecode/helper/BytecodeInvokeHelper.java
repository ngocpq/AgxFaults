package gov.nasa.jpf.jfaults.bytecode.helper;

import gov.nasa.jpf.jvm.bytecode.JVMInvokeInstruction;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.ThreadInfo;

public class BytecodeInvokeHelper {

	public static Instruction execute(JVMInvokeInstruction invokevirtual, ThreadInfo th) {
		// TODO Auto-generated method stub
		return null;
	}

	public static Instruction executeInstanceInvocation(int objRef, JVMInvokeInstruction invokevirtual, ThreadInfo th) {
		// TODO Auto-generated method stub
		return null;
	}

}
