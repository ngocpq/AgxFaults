package gov.nasa.jpf.jfaults.bytecode.branch.helper;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.LogicalOperator;
import gov.nasa.jpf.constraints.expressions.PropositionalCompound;
import gov.nasa.jpf.constraints.util.ExpressionUtil;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.bytecode.InstructionInterface;

public abstract class BranchVariableInfo<T> {
	final protected int DEFAULT_IDX = -1;
	InstructionInterface instruction;

	protected BranchVariableInfo(InstructionInterface insn) {
		this.instruction = insn;
	}

	public abstract Pair<T> popBranchConditionValue(StackFrame sf);

	public abstract boolean isSymbolicConditionValue(StackFrame sf);

	public abstract int getNumTargets();

	public abstract T getTargetValue(int branchIdx);

	public abstract Instruction getTargetPC(int branchIdx);
	// public abstract void setSelectedBranch(int branchIdx);

	public int getTargetBranchIndex(T value) {
		for (int i = 0; i < this.getNumTargets(); i++) {
			if (getTargetValue(i).equals(value))
				return i;
		}
		return this.getNumTargets();// return default target
	}

	@SuppressWarnings("unchecked")
	public Expression<Boolean>[] buildDecisions(Expression<T> symbExpr) {
		int numTargets = this.getNumTargets();
		Expression<Boolean>[] result = new Expression[this.getNumTargets() + 1];
		Expression<Boolean> defaultExpr = null;
		for (int i = 0; i < numTargets; i++) {
			T tgtVal = this.getTargetValue(i);
			Constant<T> c = Constant.create(symbExpr.getType(), tgtVal);
			Expression<Boolean> posExpr = ExpressionUtil.makeEqualityExpression(symbExpr, c);
			result[i] = posExpr;
			Expression<Boolean> negExpr = ExpressionUtil.makeNotEqualExpression(symbExpr, c);
			if (defaultExpr == null)
				defaultExpr = negExpr;
			else
				defaultExpr = new PropositionalCompound(defaultExpr, LogicalOperator.AND, negExpr);
		}
		result[numTargets] = defaultExpr;

		return result;
	}

}
