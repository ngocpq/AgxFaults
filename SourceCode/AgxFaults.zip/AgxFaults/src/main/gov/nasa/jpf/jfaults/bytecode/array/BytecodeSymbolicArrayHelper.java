package gov.nasa.jpf.jfaults.bytecode.array;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.array.ArrayExpression;
import gov.nasa.jpf.constraints.array.ArrayType;
import gov.nasa.jpf.constraints.array.SelectExpression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.LogicalOperator;
import gov.nasa.jpf.constraints.expressions.NumericBooleanExpression;
import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.constraints.expressions.PropositionalCompound;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.constraints.util.ExpressionUtil;
import gov.nasa.jpf.jcfg.utils.InstructionUtil;
import gov.nasa.jpf.jcfg.variable.InstanceFieldVariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.bytecode.ExecuteSuperInsntructionHelper;
import gov.nasa.jpf.jfaults.objects.SymbolicObject;
import gov.nasa.jpf.jfaults.perturb.FieldPerturbator;
import gov.nasa.jpf.jvm.bytecode.ArrayLoadInstruction;
import gov.nasa.jpf.jvm.bytecode.ArrayStoreInstruction;
import gov.nasa.jpf.jvm.bytecode.GETFIELD;
import gov.nasa.jpf.util.ObjectList;
import gov.nasa.jpf.vm.DynamicElementInfo;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.FieldInfo;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.MJIEnv;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;
import gov.nasa.jpf.vm.bytecode.InstructionInterface;

public class BytecodeSymbolicArrayHelper { 

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <GetFieldInsn extends GETFIELD & ExecuteSuperInsntructionHelper> Instruction executeGETFIELD(ThreadInfo ti,GetFieldInsn insn) {
		 ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
			if (analysis == null)
				return null;

			StackFrame frame = ti.getModifiableTopFrame();
			int objStackSlot = insn.getObjectSlot(frame);
			int objRef = frame.peek();
			
			Object objOperandAttr = frame.getOperandAttr();// peekArrayAttr(ti);
	    
	    Expression symHeapIdx=null; 
	    if (objOperandAttr!=null){
	    	symHeapIdx = ObjectList.getFirst(objOperandAttr, Expression.class);	    	
	    }
	    
	    //constraint decision for 'null value exception'
	    boolean objIsNull = (objRef == MJIEnv.NULL);
	    if(symHeapIdx!=null){
	    	//make constraint symThis!=0
	    	Expression<Boolean>[] constraints = null;
	      if(analysis.needsDecisions()) {      	
	        constraints = new Expression[2];
	        Constant<Integer> zero = Constant.create(BuiltinTypes.SINT32, MJIEnv.NULL);
	        constraints[0] = NumericBooleanExpression.create(symHeapIdx, NumericComparator.NE, zero);
	        constraints[1] = NumericBooleanExpression.create(symHeapIdx, NumericComparator.EQ, zero);
	      }
	      analysis.decisionException(ti, insn,NullPointerException.class.getName(), objIsNull ? 1 : 0, constraints);
	    }
	    
	    if (objIsNull)
	    	return ti.createAndThrowException("java.lang.NullPointerException", insn.getMnemonic()+" access field of a null object");
	    //=========	  
	    
	    ElementInfo objInfo = insn.getElementInfo(ti);    
	    SymbolicObject symbObj = objInfo.getObjectAttr(SymbolicObject.class);
	    if (symbObj!=null){
	    	//object is symbolic
	    	//TODO:?
	    	
	    }
	    FieldInfo fieldInfo = insn.getFieldInfo();
	    LastModifiedLocationAttribute defAtt = objInfo.getFieldAttr(fieldInfo, LastModifiedLocationAttribute.class);
	    InstanceFieldVariableStaticInfo varStaticInfo = new InstanceFieldVariableStaticInfo(fieldInfo,objInfo);				
			FieldPerturbator<?> perturbator = new FieldPerturbator(objInfo, varStaticInfo);
	    if (defAtt==null){
	    	defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
				perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);
	    }else{	    	
	    	Expression<Boolean> pathConstraint = defAtt.getModifiedGualdConstraints(analysis.getCurrentExecutingLocation());
	    	if (pathConstraint!=null && !ExpressionUtil.isBoolConst(pathConstraint, true)){
	    		StackFrame sf=ti.getModifiableTopFrame();
					//making PHI variable	    		
	    		Expression symVal = perturbator.getDynamicAttribute(ti, sf, Expression.class);
	  			if (symVal!=null && varStaticInfo.isUnknowType()){
	  				if (!symVal.getType().equals(varStaticInfo.getType())){
	  					varStaticInfo.setType(symVal.getType());
	  				}	
	  			}
	  			
	  			Object concVal = perturbator.getConcreteValue(ti,sf);
	  			if (concVal==null)
	  				concVal = MJIEnv.NULL;
	  			else if (concVal instanceof DynamicElementInfo){
	  				//TODO: fix me
	  				DynamicElementInfo valObjInfo = (DynamicElementInfo)concVal;
	  				concVal = valObjInfo.getObjectRef();
	  			}
	  			
	  			if (symVal==null){
	  				symVal = Constant.create(varStaticInfo.getType(), concVal);				
	  			}
	  			//String varUniqueId = "@PHI@"+varStaticInfo.getVarUniqueId();
	  			String varUniqueId = "@PHI@"+InstructionUtil.getUniqueIdString(insn);
	  			Variable newSymbVar = analysis.getOrCreateSummaryVariable(insn,varUniqueId,ti,sf,symVal,concVal,pathConstraint);		
	  			//update symbolic state
	  			perturbator.setDynamicAttribute(ti,sf,Expression.class,newSymbVar);
	  			
	  			//update context information
	  			defAtt.setDefinedLocation(analysis.getCurrentExecutingLocation());	  			
	    	}
	    	defAtt.setPerturbator(perturbator);
	    }
	    return insn.executeSuper(ti);			
				
	}
	
		public static <ArrLoadInsn extends ArrayLoadInstruction & ExecuteSuperInsntructionHelper> Instruction executeArrayLoad(ThreadInfo ti,ArrLoadInsn arrLoadInsn) {
			 ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
				if (analysis == null)
					return null;

				StackFrame frame = ti.getModifiableTopFrame();
				Object arrOperandAttr = arrLoadInsn.getArrayOperandAttr(ti);// peekArrayAttr(ti);
		    Object idxAttr = arrLoadInsn.getIndexOperandAttr(ti);// peekIndexAttr(ti);
		    int objRef = arrLoadInsn.getArrayRef(ti); // peekArrayRef(ti); // need to be polymorphic, could be LongArrayStore
		    
		    Expression symHeapIdx=null; 
		    ArrayExpression arrayExpr=null;
		    Expression<Integer> indexSymb = null;
		    if (arrOperandAttr!=null){
		    	symHeapIdx = ObjectList.getFirst(arrOperandAttr, Expression.class);	    	
		    }
		    if (idxAttr!=null)
		    	indexSymb = ObjectList.getFirst(idxAttr, Expression.class);

		    //constraint decision for 'null value exception'
		    boolean objIsNull = (objRef == MJIEnv.NULL);
		    if(symHeapIdx!=null){
		    //make constraint symThis!=0
		    	Expression<Boolean>[] constraints = null;
		      if(analysis.needsDecisions()) {      	
		        constraints = new Expression[2];
		        Constant<Integer> zero = Constant.create(BuiltinTypes.SINT32, MJIEnv.NULL);
		        constraints[0] = NumericBooleanExpression.create(symHeapIdx, NumericComparator.NE, zero);
		        constraints[1] = NumericBooleanExpression.create(symHeapIdx, NumericComparator.EQ, zero);
		      }
		      analysis.decisionException(ti, arrLoadInsn,NullPointerException.class.getName(), objIsNull ? 1 : 0, constraints);
		    }
		    
		    if (objIsNull)
		    	return ti.createAndThrowException("java.lang.NullPointerException", "IALOAD to null array object");
		    //=========	  
		    
		    ElementInfo eiArray = ti.getElementInfo(objRef);    
		    arrayExpr = eiArray.getObjectAttr(ArrayExpression.class);
		    	    	  	    
		    //at this point 'array' or 'index' is symbolic, we should make array expression    
		  	int indexValue = arrLoadInsn.getIndex(ti); 
		    int arrayLength = eiArray.arrayLength();
		    
		    if (indexSymb==null){ //concrete index    	
		    	indexSymb = Constant.create(BuiltinTypes.SINT32, indexValue);
		    }
		    
		    boolean isOutOfBound = (indexValue<0 || indexValue>=arrayLength);				
		    //make decision for 'index' value	    
		    if (ExpressionUtil.containsVars(indexSymb)){     		    		  	
			  	Constant<Integer> zero = Constant.create(BuiltinTypes.SINT32, 0);
			  	Constant<Integer> arrLength = Constant.create(BuiltinTypes.SINT32,arrayLength);
			  	NumericBooleanExpression leftBound = new NumericBooleanExpression(indexSymb,NumericComparator.GE,zero);
			  	NumericBooleanExpression righBound = new NumericBooleanExpression(indexSymb,NumericComparator.LT,arrLength);  				
					
					PropositionalCompound boundConstraint = new PropositionalCompound(leftBound, LogicalOperator.AND,righBound);
			  	Expression<Boolean> negateBoundConstraint = ExpressionUtil.not(boundConstraint);
			    Expression<Boolean>[] decisions = new Expression[]{boundConstraint,negateBoundConstraint};    
			    
			    //Decision about Index boundary
					analysis.decisionException(ti, arrLoadInsn,IndexOutOfBoundsException.class.getName(), isOutOfBound ? 1 : 0, decisions);
		    }
		    
		    if (isOutOfBound)
		    	return ti.createAndThrowException("java.lang.IndexOutOfBoundsException", "Storing value to array at index '"+indexValue+"' while valid value range is [0,"+(arrayLength-1)+"]");
		    //============
		    
		    if (arrayExpr==null && (indexSymb == null || !ExpressionUtil.containsVars(indexSymb))){
		    	//purely concolic, and not in analysis scope: nothing to do.
		    	return arrLoadInsn.executeSuper(ti);
		    }
		    
		    if (arrayExpr ==null ){ //the array is not symbolic    	
		    	//create a symbolic array from a concolic array
		    	ArrayType arrayType = ConcolicUtil.getArrayType(ti,objRef);		    	
		    	arrayExpr = analysis.getOrCreateSymbolicArray(arrLoadInsn,ti,eiArray,objRef);

		    	//update symbolic memory / symbolic attribute
		    	eiArray.defreeze();
		    	eiArray.addObjectAttr(arrayExpr);
		    	
		    	LastModifiedLocationAttribute defLocationAttr = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(),null);
		    	LastModifiedLocationAttribute prevDefLoc = eiArray.getObjectAttr(LastModifiedLocationAttribute.class);
		    	if (prevDefLoc==null)
		    		eiArray.addObjectAttr(defLocationAttr);
		    	else
		    		eiArray.replaceObjectAttr(prevDefLoc, defLocationAttr);
		    	
		    	//attach symbolic value of array elements
		    	for (int i=0;i<arrayType.getLength();i++){
		    		SelectExpression selectA_i = new SelectExpression(arrayExpr, i);
		    		Expression oldAttr = eiArray.getElementAttr(i, Expression.class);
		    		if (oldAttr==null)
		    			eiArray.addElementAttr(i, selectA_i);
		    		else
		    			eiArray.replaceElementAttr(i, oldAttr, selectA_i);
		    	}
		    	eiArray.freeze();
		    }	    
		  		  
		    Instruction next = arrLoadInsn.executeSuper(ti);
		    
		    LastModifiedLocationAttribute arrDefLoc = eiArray.getObjectAttr(LastModifiedLocationAttribute.class);
		    if (arrDefLoc==null)
		    	arrDefLoc = new LastModifiedLocationAttribute(analysis.getInternalConstraintsTree().getRootNode(), null);
		    
		    
		    SelectExpression elementAttr = new SelectExpression(arrayExpr, indexSymb);
		    int elementTypeSize = getElementTypeSize(eiArray);
	      if (elementTypeSize == 1) {
	      	LastModifiedLocationAttribute oldDefLocAttr = frame.getOperandAttr(LastModifiedLocationAttribute.class);
	      	if (oldDefLocAttr==null)
	      		frame.addOperandAttr(arrDefLoc);
	      	else 
	      		frame.replaceOperandAttr(oldDefLocAttr, arrDefLoc);
	      	
	      	Expression oldAttr = frame.getOperandAttr(Expression.class);
	      	if (oldAttr==null)
	      		frame.addOperandAttr(elementAttr);
	      	else 
	      		frame.replaceOperandAttr(oldAttr, elementAttr);      	
	      	
	      } else {
	      	Expression oldDefLocAttr = frame.getLongOperandAttr(Expression.class);
	      	if (oldDefLocAttr==null)
	      		frame.addLongOperandAttr(arrDefLoc);
	      	else 
	      		frame.replaceLongOperandAttr(oldDefLocAttr,arrDefLoc);   
	      	
	      	Expression oldAttr = frame.getLongOperandAttr(Expression.class);
	      	if (oldAttr==null)
	      		frame.addLongOperandAttr(elementAttr);
	      	else 
	      		frame.replaceLongOperandAttr(oldAttr,elementAttr);        
	      }    
		    return next;
		}
	 
	//TODO: update symbolic array object, currently only update array element
	public static <InsnType extends ArrayStoreInstruction & ExecuteSuperInsntructionHelper> Instruction executeArrayStore(ThreadInfo ti,InsnType arrStoreInsn) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis == null)
			return null;				

    Object arrOperandAttr = arrStoreInsn.getArrayOperandAttr(ti);// peekArrayAttr(ti);
    Object idxAttr = arrStoreInsn.getIndexOperandAttr(ti);// peekIndexAttr(ti);
    int objRef = arrStoreInsn.getArrayRef(ti); // peekArrayRef(ti); 
    
    Expression symHeapIdx=null; 
    ArrayExpression arrayExpr=null;
    Expression<Integer> indexSymb = null;
    if (arrOperandAttr!=null){
    	symHeapIdx = ObjectList.getFirst(arrOperandAttr, Expression.class);    	
    }
    if (idxAttr!=null && !(idxAttr instanceof Expression))
    	indexSymb = ObjectList.getFirst(idxAttr, Expression.class);
    
    //constraint decision for 'null value exception'
    boolean objIsNull = (objRef == MJIEnv.NULL);
    if(symHeapIdx!=null){
    //make constraint symThis!=0
    	Expression<Boolean>[] constraints = null;
      if(analysis.needsDecisions()) {      	
        constraints = new Expression[2];
        Constant<Integer> zero = Constant.create(BuiltinTypes.SINT32, MJIEnv.NULL);
        constraints[0] = NumericBooleanExpression.create(symHeapIdx, NumericComparator.NE, zero);
        constraints[1] = NumericBooleanExpression.create(symHeapIdx, NumericComparator.EQ, zero);
      }
      analysis.decisionException(ti, arrStoreInsn,NullPointerException.class.getName(), objIsNull ? 1 : 0, constraints);
    }
    
    if (objIsNull)
    	return ti.createAndThrowException("java.lang.NullPointerException", "Storing value to null array object");
    //=========    
    
    StackFrame frame = ti.getModifiableTopFrame();        
    ElementInfo eiArray = ti.getElementInfo(objRef);
    arrayExpr = eiArray.getObjectAttr(ArrayExpression.class);
    
    
    //at this point 'array' or 'index' is symbolic, we should make array expression    
    int indexValue = arrStoreInsn.getIndex(ti); 
    int arrayLength = eiArray.arrayLength();
   
    if (indexSymb==null){ //concrete index    	
    	indexSymb = Constant.create(BuiltinTypes.SINT32, indexValue);
    }
    
    //decisions
		//1: array is null
		//2: index out of bound
		//3: normal
		
    //constraint decision for 'index out of bound exception'
    boolean isOutOfBound = (indexValue<0 || indexValue>=arrayLength);				
    //make decision for 'index' value	    
    if (ExpressionUtil.containsVars(indexSymb)){     		    		  	
	  	Constant<Integer> zero = Constant.create(BuiltinTypes.SINT32, 0);
	  	Constant<Integer> arrLength = Constant.create(BuiltinTypes.SINT32,arrayLength);
	  	NumericBooleanExpression leftBound = new NumericBooleanExpression(indexSymb,NumericComparator.GE,zero);
	  	NumericBooleanExpression righBound = new NumericBooleanExpression(indexSymb,NumericComparator.LT,arrLength);  				
			
			PropositionalCompound boundConstraint = new PropositionalCompound(leftBound, LogicalOperator.AND,righBound);
	  	Expression<Boolean> negateBoundConstraint = ExpressionUtil.not(boundConstraint);
	    Expression<Boolean>[] decisions = new Expression[]{boundConstraint,negateBoundConstraint};    
	    
	    //Decision about Index boundary
			analysis.decisionException(ti, arrStoreInsn,IndexOutOfBoundsException.class.getName(), isOutOfBound ? 1 : 0, decisions);
    }
    
    if (isOutOfBound)
    	return ti.createAndThrowException("java.lang.IndexOutOfBoundsException", "Storing value to array at index '"+indexValue+"' while valid value range is [0,"+(arrayLength-1)+"]");
    //============
    
    if (analysis.isSuspiciousScope(arrStoreInsn)){
    	//perturb righ-hand side expression    	
    	ArrayType<?> arrType = ConcolicUtil.getArrayType(ti, objRef);    	
    	//TODO: check primary or reference data type
    	analysis.perturbAngelicStackOperandValue(ti, frame,arrStoreInsn,0, arrType.getElementType());
    }
    
    if (arrayExpr==null && (indexSymb == null || !ExpressionUtil.containsVars(indexSymb))){
    	//concrete array, and concrete index: nothing to do.
    	return arrStoreInsn.executeSuper(ti);
    }
    
    //symbolic array or symbolic index => create new array by a STORE(oldArray, index,value)
    
		eiArray.defreeze();
    Instruction nextInsn = arrStoreInsn.executeSuper(ti);  	
    
		if (arrayExpr ==null ){    	
    	//create a symbolic array from a concolic array    	
    	arrayExpr = analysis.getOrCreateSymbolicArray(arrStoreInsn,ti,eiArray,objRef);    	
    }else{
    	if (indexSymb==null){ //concrete index    	
      	indexSymb = Constant.create(BuiltinTypes.SINT32, indexValue);
      }
  						
  		Expression valueSymb = eiArray.getElementAttr(indexValue, Expression.class);
  		if (valueSymb==null){
  			Object elmConc = ConcolicUtil.getArrayElement(eiArray, indexValue, arrayExpr.getArrayType().getElementType());
  			valueSymb = Constant.create(arrayExpr.getArrayType().getElementType(), elmConc);
  		}
  		
  		//arrayExpr = new StoreExpression<>(arrayExpr, indexSymb, valueSymb);
  		arrayExpr = analysis.getOrCreateSymbolicArrayStore(arrStoreInsn,ti,eiArray,objRef,arrayExpr,indexSymb,valueSymb);  		
    }    
		
		//attach symbolic array to objRef
		ArrayExpression oldArrExpr = eiArray.getObjectAttr(ArrayExpression.class);
		if (oldArrExpr==null)		
			eiArray.addObjectAttr(arrayExpr);
		else
			eiArray.replaceObjectAttr(oldArrExpr, arrayExpr);		
		
  	LastModifiedLocationAttribute defLocationAttr = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(),null);
  	LastModifiedLocationAttribute prevDefLoc = eiArray.getObjectAttr(LastModifiedLocationAttribute.class);
  	if (prevDefLoc==null)
  		eiArray.addObjectAttr(defLocationAttr);
  	else
  		eiArray.replaceObjectAttr(prevDefLoc, defLocationAttr);  	
		
  	/*ArrayType arrayType = arrayExpr.getArrayType();
  	//attach symbolic value of array elements
  	for (int i=0;i<arrayType.getLength();i++){
  		SelectExpression selectA_i = new SelectExpression(arrayExpr, i);
  		Expression oldAttr = eiArray.getElementAttr(i, Expression.class);
  		if (oldAttr==null)
  			eiArray.addElementAttr(i, selectA_i);
  		else
  			eiArray.replaceElementAttr(i, oldAttr, selectA_i);
  		
  		LastModifiedLocationAttribute elmDefAttr = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(),null);
  		LastModifiedLocationAttribute oldDefLocAttr = eiArray.getElementAttr(i,LastModifiedLocationAttribute.class);
  		if (oldDefLocAttr==null)
  			eiArray.addElementAttr(i, elmDefAttr);
  		else
  			eiArray.replaceElementAttr(i, oldDefLocAttr, elmDefAttr);
  	}*/
  	eiArray.freeze();
    return nextInsn;
	}
	
	protected static <T> void perturbStackOperandValue(ThreadInfo ti, StackFrame sf,InstructionInterface arrStoreInsn,int stackOffset, Type<T> type){
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
			return;
		
    if (analysis.isSuspiciousScope(arrStoreInsn)){    	
    	Pair<T> pair = ConcolicUtil.peek(sf, stackOffset, type);  		
	    //Variable<T> agxVal = analysis.getOrCreateAngelicSymbolicVariable(arrStoreInsn, ti, sf, pair.symb, pair.conc);
    	//T agxValConc = analysis.getAngelicValueOfExpression(agxVal);
    	String varUniqueId = InstructionUtil.getUniqueIdString(arrStoreInsn);
    	Pair<T> updatedAttr = analysis.getOrCreateAngelicVariable(arrStoreInsn,varUniqueId, ti, sf, pair.symb, pair.conc);
    	//T agxValConc = pair.conc;
    	
    	//update symbolic/memory state    	
			//ConcolicUtil.setOperand(sf, stackOffset, type, agxValConc);
			//ConcolicUtil.setOrReplaceOperandAttr(sf, stackOffset, type, agxVal,Expression.class);
    	ConcolicUtil.perturbOperand(sf, 0, updatedAttr);
	  }
    
		LastModifiedLocationAttribute attr = new LastModifiedLocationAttribute( analysis.getCurrentExecutingLocation(),null);
		ConcolicUtil.setOrReplaceOperandAttr(sf, stackOffset,attr,LastModifiedLocationAttribute.class);
	}
		 
	static int getElementTypeSize(ElementInfo eiArray){		
		String elementType =eiArray.getArrayType();        
    return Types.getTypeSize(elementType);
	}
}
