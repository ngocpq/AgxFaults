package gov.nasa.jpf.jfaults.bytecode;

import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.constraints.InternalConstraintsTree;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public class ICONST extends gov.nasa.jpf.jvm.bytecode.ICONST{

	public ICONST(int value) {
		super(value);
	}
	
	@Override
	public Instruction execute(ThreadInfo ti) {
		Instruction nextInsn = super.execute(ti);
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis!=null){
			//add last modifiable location
			//LastModifiedInstructionMarker
			InternalConstraintsTree tree = analysis.getInternalConstraintsTree();
			//LastModifiedLocationAttribute attr = new LastModifiedLocationAttribute(tree.getCurrentOpenBranchNode(),tree.getCurrentOpenNodeBranchIndex());
			LastModifiedLocationAttribute attr = new LastModifiedLocationAttribute( analysis.getCurrentExecutingLocation(),null);
			StackFrame sf = ti.getTopFrame();
			if (attr!=null)
				sf.addOperandAttr(attr);
		}		
		return nextInsn;
	}
}
