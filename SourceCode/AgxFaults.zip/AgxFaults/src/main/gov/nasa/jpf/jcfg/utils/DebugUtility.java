package gov.nasa.jpf.jcfg.utils;

import java.util.HashMap;
import java.util.Map;

import gov.nasa.jpf.Config;

public class DebugUtility {
	private static DebugUtility INSTANCE;
	
	public boolean DEBUG_CFG; 
	
	private DebugUtility(Config conf){
		if (conf==null)
			this.DEBUG_CFG=false;
		else
			this.DEBUG_CFG = conf.getBoolean("debug.controlflowgraph", false);
	}	
	
	public static DebugUtility getInstance(){
		if (INSTANCE==null)
			INSTANCE = new DebugUtility(null);
		return INSTANCE;
	}
	public static void init(Config conf){
		INSTANCE = new DebugUtility(conf);
	}
	
	public static void setDebugCfg(boolean v){
		getInstance().DEBUG_CFG=v;
	}
	public static boolean isDebugCfgEnabled(){
		return getInstance().DEBUG_CFG;
	}

	static Map<String, Integer> uniqueIdMap = new HashMap<>();
	public static String getNextUniqueName(String key) {
		Integer lastId = uniqueIdMap.get(key);
		if (lastId ==null)
			lastId = -1;
		lastId = lastId+1;
		uniqueIdMap.put(key, lastId);
		return key+"_"+lastId;
	}


}
