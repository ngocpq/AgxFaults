package gov.nasa.jpf.jfaults.bytecode.field;

import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jcfg.variable.InstanceFieldVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.StaticFieldVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.bytecode.ExecuteSuperInsntructionHelper;
import gov.nasa.jpf.jfaults.bytecode.array.BytecodeSymbolicArrayHelper;
import gov.nasa.jpf.jfaults.perturb.FieldPerturbator;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public class GETFIELD extends gov.nasa.jpf.jvm.bytecode.GETFIELD implements ExecuteSuperInsntructionHelper {

	public GETFIELD (String fieldName, String classType, String fieldDescriptor){
    super(fieldName, classType, fieldDescriptor);
  }
	
	@Override
	public Instruction execute(ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis == null)
			return super.execute(ti);
		Instruction nextInsn = BytecodeSymbolicArrayHelper.executeGETFIELD(ti, this);
		if (nextInsn!=null)
			return nextInsn;
		return super.execute(ti);
	}

	@Override
	public Instruction executeSuper(ThreadInfo ti) {
		return super.execute(ti);
	}
	
//	@SuppressWarnings({ "rawtypes", "unchecked" })	
//	public Instruction execute1(ThreadInfo ti) {		
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis == null)
//			return super.execute(ti);		
//		
//		ElementInfo elementInfo = this.getElementInfo(ti);		
//		LastModifiedLocationAttribute defAtt = elementInfo.getFieldAttr(this.getFieldInfo(), LastModifiedLocationAttribute.class);
//				
//		InstanceFieldVariableStaticInfo varStaticInfo = new InstanceFieldVariableStaticInfo(fi,elementInfo);				
//		FieldPerturbator<?> perturbator = new FieldPerturbator(elementInfo, varStaticInfo);			
//		if (defAtt==null){								
//			defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//			perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);
//		}else{
//			/*if (defAtt.getPerturbator()!=null){				
//				FieldPerturbator per = (FieldPerturbator) defAtt.getPerturbator();
//				if (per.getFieldInfo().equals(perturbator.getFieldInfo())&& per.getElementInfo().equals(perturbator.getElementInfo())){
//					ContractUtils.unreachable("GETFIELD: not consistance FieldPerturbator");
//				}
//			}*/
//			defAtt.setPerturbator(perturbator);
//		}
//		
//		/*Instruction nextInsn = analysis.executeLoadInstruction(ti,perturbator.getVariableStaticInfo(),defAtt, this);
//		if (nextInsn!=null)
//			return nextInsn;
//		else*/
//			return super.execute(ti);		
//	}
	
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	@Override
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis == null)
//			return super.execute(ti);		
//		
//		StackFrame sf = ti.getModifiableTopFrame();
//		int objSlot = this.getObjectSlot(sf);
//		
//		//object.field: object
//		ElementInfo elementInfo = this.getElementInfo(ti);
//		
//		LastModifiedLocationAttribute defAtt = elementInfo.getFieldAttr(this.getFieldInfo(), LastModifiedLocationAttribute.class);
//		MemoryPerturbator<?> perturbator;
//		if (defAtt==null){
//			InstanceFieldVariableStaticInfo varStaticInfo = new InstanceFieldVariableStaticInfo(fi,elementInfo);
//			//VariableStaticInfo<?> varStaticInfo = VariableStaticInfo.getVariableStaticInfo(this);
//			perturbator = new FieldPerturbator(elementInfo, varStaticInfo);
//			defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//			perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);
//		}else{
//			perturbator =defAtt.getPerturbator();
//			if (perturbator==null){
//				System.out.println("Debug: warning perturbator is null");
//				InstanceFieldVariableStaticInfo varStaticInfo = new InstanceFieldVariableStaticInfo(fi,elementInfo);
//				//VariableStaticInfo<?> varStaticInfo = VariableStaticInfo.getVariableStaticInfo(this);
//				perturbator = new FieldPerturbator(elementInfo, varStaticInfo);
//				defAtt.setPerturbator(perturbator);
//			}
//		}
//		
//		Instruction nextInsn = analysis.executeLoadInstruction(ti,perturbator.getVariableStaticInfo(),defAtt, this);			
//	
//		return super.execute(ti);
//	}

}
