package gov.nasa.jpf.jcfg.utils;

import java.util.HashMap;
import java.util.Map;

import gov.nasa.jpf.JPFException;
import gov.nasa.jpf.jcfg.cfg.OpCode;
import gov.nasa.jpf.jcfg.cfg.StackBehavior;
import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jvm.bytecode.ACONST_NULL;
import gov.nasa.jpf.jvm.bytecode.ALOAD;
import gov.nasa.jpf.jvm.bytecode.ASTORE;
import gov.nasa.jpf.jvm.bytecode.ATHROW;
import gov.nasa.jpf.jvm.bytecode.DCONST;
import gov.nasa.jpf.jvm.bytecode.DIRECTCALLRETURN;
import gov.nasa.jpf.jvm.bytecode.DLOAD;
import gov.nasa.jpf.jvm.bytecode.DSTORE;
import gov.nasa.jpf.jvm.bytecode.DUP;
import gov.nasa.jpf.jvm.bytecode.DUP2;
import gov.nasa.jpf.jvm.bytecode.FCONST;
import gov.nasa.jpf.jvm.bytecode.FLOAD;
import gov.nasa.jpf.jvm.bytecode.FSTORE;
import gov.nasa.jpf.jvm.bytecode.GETFIELD;
import gov.nasa.jpf.jvm.bytecode.GETSTATIC;
import gov.nasa.jpf.jvm.bytecode.ICONST;
import gov.nasa.jpf.jvm.bytecode.ILOAD;
import gov.nasa.jpf.jvm.bytecode.ISTORE;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMFieldInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMInstanceFieldInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMLocalVariableInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMReturnInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMStaticFieldInstruction;
import gov.nasa.jpf.jvm.bytecode.LCONST;
import gov.nasa.jpf.jvm.bytecode.LDC2_W;
import gov.nasa.jpf.jvm.bytecode.LLOAD;
import gov.nasa.jpf.jvm.bytecode.LSTORE;
import gov.nasa.jpf.jvm.bytecode.LDC2_W.Type;
import gov.nasa.jpf.jvm.bytecode.NewArrayInstruction;
import gov.nasa.jpf.jvm.bytecode.PUTFIELD;
import gov.nasa.jpf.jvm.bytecode.PUTSTATIC;
import gov.nasa.jpf.jvm.bytecode.SwitchInstruction;
import gov.nasa.jpf.jvm.bytecode.TABLESWITCH;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.LocalVarInfo;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;
import gov.nasa.jpf.vm.bytecode.InstructionInterface;
import gov.nasa.jpf.vm.bytecode.InvokeInstruction;
import gov.nasa.jpf.vm.bytecode.ReturnInstruction;
import gov.nasa.jpf.vm.bytecode.ReturnValueInstruction;
import gov.nasa.jpf.vm.bytecode.StoreInstruction;

public class InstructionUtil {

	public static byte getLocalVariableTypeCode(JVMLocalVariableInstruction insn) {
		if (insn instanceof ALOAD || insn instanceof ASTORE)
			return Types.T_REFERENCE;
		if (insn instanceof DLOAD || insn instanceof DSTORE)
			return Types.T_DOUBLE;
		if (insn instanceof FLOAD || insn instanceof FSTORE)
			return Types.T_FLOAT;
		if (insn instanceof ILOAD || insn instanceof ISTORE)
			return Types.T_INT;
		if (insn instanceof LLOAD || insn instanceof LSTORE)
			return Types.T_LONG;
		
		throw new JPFException("unsupported instruction type: " + insn);
	}	
	
	public static boolean isConstantLoad(Instruction insn) {
		if (insn instanceof ICONST)			
			return true;
		if (insn instanceof DCONST)
			return true;
		if (insn instanceof ACONST_NULL)
			return true;
		if (insn instanceof FCONST)
			return true;
		if (insn instanceof LCONST)
			return true;
		return false;
	}

	public static boolean isConditionalBranch(Instruction insn) {
		if (insn instanceof IfInstruction)			
			return true;
		if (insn instanceof SwitchInstruction)
			return true;
		return false;
	}

	public static String getDisplayStringLong(InstructionInterface expInsn) {
		String source = expInsn.getSourceLine();
		if (source==null)
			source="No source";
		else
			source = source.trim();
		return "["+expInsn.getLineNumber()+"_"+expInsn.getPosition()+"_"+expInsn.getMnemonic()+"] "+source;
	}
	
	public static String getDisplayString(InstructionInterface expInsn) {
		return "["+expInsn.getLineNumber()+"_"+expInsn.getPosition()+"_"+expInsn.getMnemonic()+"]";
	}

	public static String getInstructionLocationString(Instruction insn) {
		MethodInfo mi = insn.getMethodInfo();
		String str = mi.getFullName()+":"+insn.getFilePos()+":"+insn.getPosition();
		return str;
	}

	static Map<String, String> map_insn_uniq_id_short=new HashMap<>();
	static Map<String, String> map_insn_uniq_id_long=new HashMap<>();
	static int insn_id_count=0;
//	public static String getUniqueIdString(InstructionInterface insn) {
//		MethodInfo mi = insn.getMethodInfo();
//		String insnCode = insn.getMnemonic().replace(" ", "");
//		String insnId = mi.getClassInfo().getName() + '_' + mi.getUniqueName() + "_"+insnCode+"_L"+insn.getLineNumber()+"_"+insn.getPosition();
//		//return insnId;
//		String returnId = map_insn_uniq_id_short.get(insnId);
//		if (returnId==null){
//			//make new variable
//			insn_id_count++;
//			String varName = "i"+insn_id_count+"."+"L"+insn.getLineNumber()+"_"+insn.getPosition()+"_"+insnCode;
//			if (insn instanceof JVMLocalVariableInstruction){
//				LocalVarInfo varInfo = ((JVMLocalVariableInstruction) insn).getLocalVarInfo();				
//				if (varInfo!=null)
//					varName+="_"+varInfo.getName();				
//			}else if (insn instanceof JVMReturnInstruction){
//				//varName=insn.getMethodInfo().getName()+""+insnCode;
//			}else if (insn instanceof JVMFieldInstruction){				
//				varName+="_"+((JVMFieldInstruction) insn).getFieldName();
//			}else{
//				//varName=insn.getMethodInfo().getName()+"_"+insnCode;
//			}
//			String methodName= mi.getClassName().replace(".", "_")+"_"+mi.getName();
//			varName = methodName+"."+varName;
//			
//			returnId = varName;
//			map_insn_uniq_id_short.put(insnId, returnId);			
//			map_insn_uniq_id_long.put(returnId,insnId);
//		}		
//		return returnId;
//	}

	public static String getUniqueIdString(InstructionInterface insn) {
		MethodInfo mi = insn.getMethodInfo();
		String insnCode = insn.getMnemonic().replace(" ", "");
		if (mi==null)
			return insnCode;		
		String insnId = mi.getClassInfo().getName() + '_' + mi.getUniqueName() + "_"+insnCode+"_L"+insn.getLineNumber()+"_"+insn.getPosition();
		return insnId;
//		String returnId = map_insn_uniq_id_short.get(insnId);
//		if (returnId==null){
//			//make new variable
//			insn_id_count++;
//			String varName = "i"+insn_id_count;
//			if (insn instanceof JVMLocalVariableInstruction){
//				LocalVarInfo varInfo = ((JVMLocalVariableInstruction) insn).getLocalVarInfo();		
//				if (varInfo!=null)
//					varName+="_"+varInfo.getName();				
//			}else if (insn instanceof JVMReturnInstruction){
//				//varName=insn.getMethodInfo().getName()+""+insnCode;
//			}else if (insn instanceof JVMFieldInstruction){				
//				varName+="_"+((JVMFieldInstruction) insn).getFieldName();
//			}else{
//				//varName=insn.getMethodInfo().getName()+"_"+insnCode;
//			}
//			returnId = varName;
//			map_insn_uniq_id_short.put(insnId, returnId);			
//			map_insn_uniq_id_long.put(returnId,insnId);
//		}		
//		return returnId;
	}
	
	public static byte[] getStackOperandTypeCode(Instruction insn,ThreadInfo ti, StackFrame sf) {
		if (insn instanceof InvokeInstruction){
			byte[] arr = ((InvokeInstruction) insn).getInvokedMethod().getArgumentTypes();
			byte[] arrResult = new byte[arr.length];
			for(int i=0;i<arr.length;i++)
				arrResult[i] = arr[arr.length-i-1];
			return arrResult;
		}
		
		if (insn instanceof PUTSTATIC){
			byte opType = ((PUTSTATIC) insn).getFieldInfo().getTypeCode();			
			return new byte[]{opType};
		}
		
		if (insn instanceof PUTFIELD){
			byte opType = ((PUTFIELD) insn).getFieldInfo().getTypeCode();
			JVMInstanceFieldInstruction fieldInsn = (JVMInstanceFieldInstruction) insn;			
			return new byte[]{opType,Types.T_REFERENCE};
		}
		
		if (insn instanceof ReturnInstruction){
			byte opType = insn.getMethodInfo().getReturnTypeCode();
			if (opType== Types.T_VOID)				
				return new byte[0];
			return new byte[]{opType};
		}
		
		if (insn instanceof NewArrayInstruction){
			//operator is length of the new array
			return new byte[]{Types.T_INT};
		}
		if (insn instanceof StoreInstruction){
			if (insn instanceof JVMLocalVariableInstruction){
				LocalVarInfo varInfo = ((JVMLocalVariableInstruction) insn).getLocalVarInfo();
				if (varInfo!=null)
					return new byte[]{Types.getTypeCode(varInfo.getSignature())};
			}
		}
		if (insn instanceof DUP){
			//return new byte[]{};
			byte opType = 0;
		}
		
		OpCode code = OpCode.get(insn.getByteCode());
		StackBehavior stackPopBehavior = code.getStackBehaviorPop();
		int size=stackPopBehavior.getOperandCount(); 
		byte[] opsTypeCode = new byte[size];
		for(int i=0;i<stackPopBehavior.getOperandCount();i++){
			byte typeCode = stackPopBehavior.getOperandTypeCode(i);
			if (typeCode ==Types.T_VOID){
				//TODO: fix me
				opsTypeCode[i] = stackPopBehavior.getOperandTypeCode(i);
			}else if (typeCode == Types.T_INT){ //int/byte/char/short???
				//TODO: fix me
				int debug = 0;
			}
			opsTypeCode[i] = stackPopBehavior.getOperandTypeCode(i);
		}
		return opsTypeCode;
	}

	/*public static int[] getStackPushOperandTypeSize(Instruction insn,ThreadInfo ti, StackFrame sf) {
		if (insn instanceof JVMReturnInstruction){
			byte returnCode = insn.getMethodInfo().getReturnTypeCode();
			if(returnCode==Types.T_VOID)
				return new int[0];
			return new int[]{Types.getTypeSize(returnCode)};
		}
		
		if (insn instanceof GETFIELD || insn instanceof GETSTATIC){
			byte opType = ((JVMFieldInstruction) insn).getFieldInfo().getTypeCode();			
			return new int[]{Types.getTypeSize(opType)};
		}
		
		if (insn instanceof LDC2_W){
			byte opType = ((LDC2_W) insn).getType()== Type.DOUBLE?Types.T_DOUBLE:Types.T_LONG;	
			return new int[]{Types.getTypeSize(opType)};
		}		
		
		OpCode code = OpCode.get(insn.getByteCode());
		StackBehavior push = code.getStackBehaviorPush();
		int size=push.getOperandCount(); 
		byte[] opsTypeCode = new byte[size];
		for(int i=0;i<push.getOperandCount();i++){
			byte typeCode = push.getOperandTypeCode(i);
			if (typeCode ==Types.T_VOID){
				//TODO: fix me
				opsTypeCode[i] = push.getOperandTypeCode(i);
			}
			opsTypeCode[i] = push.getOperandTypeCode(i);
		}
		return opsTypeCode;
	}*/
	
	public static byte[] getStackPushOperandTypeCode(Instruction insn,ThreadInfo ti, StackFrame sf) {
		if (insn instanceof JVMReturnInstruction){
			byte returnCode = insn.getMethodInfo().getReturnTypeCode();
			if(returnCode==Types.T_VOID)
				return new byte[0];
			return new byte[]{returnCode};
		}
		
		if (insn instanceof GETFIELD || insn instanceof GETSTATIC){
			byte opType = ((JVMFieldInstruction) insn).getFieldInfo().getTypeCode();			
			return new byte[]{opType};
		}
		
		if (insn instanceof LDC2_W){
			byte opType = ((LDC2_W) insn).getType()== Type.DOUBLE?Types.T_DOUBLE:Types.T_LONG;	
			return new byte[]{opType};
		}		
		
		OpCode code = OpCode.get(insn.getByteCode());
		StackBehavior push = code.getStackBehaviorPush();
		int size=push.getOperandCount(); 
		byte[] opsTypeCode = new byte[size];
		for(int i=0;i<push.getOperandCount();i++){
			byte typeCode = push.getOperandTypeCode(i);
			if (typeCode ==Types.T_VOID){
				//TODO: fix me
				opsTypeCode[i] = push.getOperandTypeCode(i);
			}
			opsTypeCode[i] = push.getOperandTypeCode(i);
		}
		return opsTypeCode;
	}
	
	/*public static int getStackOperandCount(Instruction insn) {
		OpCode opCode = OpCode.get(insn.getByteCode());
		return opCode.getStackBehaviorPop().count();		
	}*/


//	private String getUniqueNameOfInsntruction(InstructionInterface insn){
//		MethodInfo mi = insn.getMethodInfo();
//		String insnCode = insn.getMnemonic().replace(" ", "");
//		return mi.getClassInfo().getName() + '_' + mi.getUniqueName() + "_"+insnCode+"_L"+insn.getLineNumber()+"_"+insn.getPosition();
//	}


//	public static int getStackPushCount(Instruction insn) {
//		OpCode code = OpCode.get(insn.getByteCode());
//		StackBehavior push = code.getStackBehaviorPush();
//		
//		
//		return 0;
//	}

	static final ErrorTerminatedInstruction ERROR_INSTRUCTION = new  ErrorTerminatedInstruction();
	static final SucceedTerminatedInstruction SUCCESS_INSTRUCTION = new  SucceedTerminatedInstruction();
	
	public static Instruction getErrorTerminalInstruction(){
		return ERROR_INSTRUCTION;
	}
	
	public static Instruction getSucceedTerminalInstruction(){
		return ERROR_INSTRUCTION;
	}
	
	static class VirtualTerminatedInstruction extends Instruction{
		@Override
		public String getFilePos() {
			return "-1";
		}
		@Override
		public String getSourceLine() {
			return null;
		}
		@Override
		public int getLineNumber() {
			return -1;
		}
		
		@Override
		public int getByteCode() {
			return 0;
		}

		@Override
		public Instruction execute(ThreadInfo ti) {
			throw new UnsupportedOperationException("Cannot invoke executing this instruction");
		}
		
		@Override
		public boolean isExtendedInstruction() {
			return true;
		}
	}
	
	static class ErrorTerminatedInstruction extends VirtualTerminatedInstruction{}
	static class SucceedTerminatedInstruction extends VirtualTerminatedInstruction{}
	
	public static boolean isSameInstruction(InstructionInterface a, InstructionInterface b){
		if (a == b)
			return true;
		if (a.getByteCode()!=b.getByteCode())
			return false;
		if (a.getInstructionIndex()!=b.getInstructionIndex())
			return false;
		if (a.getPosition()!=b.getPosition())
			return false;
		if (!a.getMnemonic().equals(b.getMnemonic()))
			return false;
		if (!a.getMethodInfo().getFullName().equals(b.getMethodInfo().getFullName()))
			return false;		
		return true;
	}
}
