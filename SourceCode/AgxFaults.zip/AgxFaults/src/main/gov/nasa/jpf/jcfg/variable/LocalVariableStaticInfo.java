package gov.nasa.jpf.jcfg.variable;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.vm.LocalVarInfo;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;

public class LocalVariableStaticInfo<T> implements VariableStaticInfo<T>{		
	private final String varName;
	private final int slotIndex;
	private byte typeCode;
	private Type<T> type;
	private boolean isUnknowType;
	private final MethodInfo methodInfo;
	private final String varUniqueId;
	
	@SuppressWarnings("unchecked")
	public LocalVariableStaticInfo(MethodInfo methodInfo,String name,int slotIdx, byte typeCode,boolean knowType) {
		this.methodInfo = methodInfo;
		this.varName = name;
		this.slotIndex = slotIdx;
		this.typeCode = typeCode;
		this.type = (Type<T>) ConcolicUtil.forTypeCode(this.typeCode);	
		this.varUniqueId = this.methodInfo.getUniqueName()+"_"+this.varName;
		this.isUnknowType=!knowType;
	}
	
	public int getStackSlotIndex(){
		return this.slotIndex;
	}
	
	public LocalVariableStaticInfo(MethodInfo methodInfo,LocalVarInfo varInfo) {
		this(methodInfo,varInfo.getName(),varInfo.getSlotIndex(),Types.getBuiltinType(varInfo.getType()),true);		
	}
	
	@Override
	public String getVarUniqueId() {
		return this.varUniqueId;
	}

	@Override
	public byte getTypeCode() {
		return typeCode;
	}
	
	@Override
	public Type<T> getType() {
		return type;
	}
	
	@Override
	public void setType(Type<T> type) {
		typeCode = ConcolicUtil.typeCodeforType(type);
		this.type = type;
		this.isUnknowType=false;
		
	}
	
	@Override
	public boolean isUnknowType() {
		return this.isUnknowType;
	}
	
	public <E> void setDynamicAttribute(ThreadInfo ti, StackFrame sf,Class<E> attrType,E newAttr){
		@SuppressWarnings("unchecked")
		E oldAtt = sf.getLocalAttr(this.slotIndex, attrType);
		if (oldAtt==null)
			sf.addLocalAttr(this.slotIndex, newAttr);
		else
			sf.replaceLocalAttr(this.slotIndex, oldAtt, newAttr);
	}
	
//	@Override
//	public <E> E getDynamicAttribute(ThreadInfo ti, StackFrame sf, Class<E> attrType) {
//		return sf.getLocalAttr(this.slotIndex, attrType);
//	}	
	
//	public MemoryPerturbator<T> getPerturbator(ThreadInfo ti, StackFrame sf){
//		return new StackLocalVariablePerturbator<T>(sf, this.slotIndex,this.typeCode);
//	}
	
	
	public void setSymbolicValue(ThreadInfo ti, StackFrame sf, Expression<T> expr){
		this.setDynamicAttribute(ti, sf, Expression.class, expr);
	}
	
	@SuppressWarnings("unchecked")
	public T getConcreteValue(ThreadInfo ti, StackFrame sf){		
		if (typeCode == Types.T_FLOAT) {
      return (T) (Object) sf.getFloatLocalVariable(slotIndex);
    }

    if (typeCode == Types.T_LONG) {
      return (T) (Object) sf.getLongLocalVariable(slotIndex);
    }

    if (typeCode == Types.T_DOUBLE) {
      return (T) (Object) sf.getDoubleLocalVariable(slotIndex);
    }
    
    if (typeCode == Types.T_BOOLEAN) {
      int i = sf.getLocalVariable(slotIndex);
      return (T) (Object)(i!=0);
    }
    // default behavior
    return (T) (Object) sf.getLocalVariable(slotIndex);
	}
	
	public void setConcreteValue(ThreadInfo ti, StackFrame sf,T value){
		if (BuiltinTypes.FLOAT.equals(type)) {
      sf.setFloatLocalVariable(slotIndex, Types.floatToInt( (Float) value));
    }
    else if (BuiltinTypes.SINT64.equals(type)) {
      long l = (Long) value;
      sf.setLongLocalVariable(slotIndex, l);      
    }
    else if (BuiltinTypes.DOUBLE.equals(type)) {
      double l = (Double) value;
      sf.setDoubleLocalVariable(slotIndex, l);
    }
    else if (BuiltinTypes.BOOL.equals(type)) {
      sf.setLocalVariable(slotIndex, (Boolean) value ? 1 : 0 ,false);
    }
    else if (BuiltinTypes.SINT16.equals(type)) {
      sf.setLocalVariable(slotIndex, (Short)value, false);
    }
    else if (BuiltinTypes.SINT8.equals(type)) {
      sf.setLocalVariable(slotIndex, (Byte)value, false);
    }
    else if (BuiltinTypes.UINT16.equals(type)) {
      sf.setLocalVariable(slotIndex, (Character)value, false);
    }
    // default behavior
    else {
      sf.setLocalVariable(slotIndex, (Integer) value ,false);
    }
	}
	
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof LocalVariableStaticInfo))
			return false;
		@SuppressWarnings("unchecked")
		LocalVariableStaticInfo<T> other = (LocalVariableStaticInfo<T>) obj;
		if (!this.getVarUniqueId().equals(other.getVarUniqueId()))
			return false;
		if (this.getTypeCode() != other.getTypeCode())
			return false;
		return true;
	}
	
	@Override
	public int hashCode() {
		return (this.getVarUniqueId()+"_"+this.getTypeCode()).hashCode();
	}
	@Override
	public String toString() {			
		return this.getVarUniqueId()+"_"+this.getTypeCode();
	}

}
