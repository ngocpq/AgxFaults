package gov.nasa.jpf.jfaults.bytecode.branch.helper;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jvm.bytecode.SwitchInstruction;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.StackFrame;
public class SwitchInfo extends BranchVariableInfo<Integer>{
	
	SwitchInstruction instruction;
	private int[] matches;
	public SwitchInfo(SwitchInstruction insn) {
		super(insn);
		this.instruction = insn;
		matches = insn.getMatches();
	}	

	@Override
	public int getNumTargets() {
		return matches.length;
	}

	@Override
	public Integer getTargetValue(int targetIdx) {
		if (this.instruction instanceof gov.nasa.jpf.jfaults.bytecode.SwitchHelper.SwitchInstruction)		
			return ((gov.nasa.jpf.jfaults.bytecode.SwitchHelper.SwitchInstruction)this.instruction).getTargetValue(targetIdx);		
		return matches[targetIdx];
	}

	@Override
	public Pair<Integer> popBranchConditionValue(StackFrame sf) {
//		Expression<?> exp = (Expression<?>) sf.getOperandAttr(Expression.class);
//		if (exp == null){
//			int condVal = sf.pop();
//			Constant symVal = Constant.create(BuiltinTypes.SINT32, condVal);
//			return new Pair<Integer>(condVal,symVal); //concolic value
//			//return new Pair<Integer>(, null); // concolic
//		}
		return ConcolicUtil.popInt(sf);		
	}

	@Override
	public Instruction getTargetPC(int branchIdx) {
		int pc;
		if (branchIdx==this.DEFAULT_IDX || branchIdx==this.getNumTargets())
			pc= instruction.getTarget();
		else
			pc = instruction.getTargets()[branchIdx];
		return this.instruction.getMethodInfo().getInstructionAt(pc);
	}

	@Override
	public boolean isSymbolicConditionValue(StackFrame sf) {
		Expression<?> sym= sf.getOperandAttr(0, Expression.class);
		if (sym==null){
			return false;
		}
		//TODO: check constant formula		
		if (sym!=null && sym instanceof Constant)
			return false;
		return true;
	}

}
