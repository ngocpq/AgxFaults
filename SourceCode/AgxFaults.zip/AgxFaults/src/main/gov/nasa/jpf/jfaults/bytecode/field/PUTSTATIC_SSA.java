package gov.nasa.jpf.jfaults.bytecode.field;

import java.util.List;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.NumericBooleanExpression;
import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.jcfg.variable.InstanceFieldVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.MemoryModifiableInstruction;
import gov.nasa.jpf.jcfg.variable.StaticFieldVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.constraints.InternalConstraintsTree;
import gov.nasa.jpf.jfaults.perturb.FieldPerturbator;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jvm.bytecode.PUTSTATIC;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.FieldInfo;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.LoadOnJPFRequired;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

import gov.nasa.jpf.util.InstructionState;
import gov.nasa.jpf.vm.ClassInfo;
import gov.nasa.jpf.vm.MJIEnv;
import gov.nasa.jpf.vm.Scheduler;

public class PUTSTATIC_SSA extends PUTSTATIC implements MemoryModifiableInstruction{

	public PUTSTATIC_SSA(String fieldName, String clsDescriptor, String fieldDescriptor) {
		super(fieldName, clsDescriptor, fieldDescriptor);
	}
	
	/**
	* Set field in object
	* ..., objectref, value => ...
	* 
	*/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Instruction execute (ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
			return super.execute(ti);
		StackFrame sf = ti.getModifiableTopFrame();
		
		//perturb right-hand-side value		
		byte typeCode = this.getFieldInfo().getTypeCode();
		Type type = ConcolicUtil.forTypeCode(typeCode);
		
		if (!this.getFieldInfo().isReference() && !this.getFieldInfo().isArrayField()){
			analysis.perturbAngelicStackOperandValue(ti, sf, this, 0, type);
		}else
			analysis.perturbAngelicStackOperandReferenceValue(ti, sf, this, 0, type);
	
		return super.execute(ti);
	}
	
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return super.execute(ti);
//		StackFrame sf = ti.getModifiableTopFrame();
//		ElementInfo elementInfo = this.getElementInfo(ti);
//		StaticFieldVariableStaticInfo varStaticInfo = new StaticFieldVariableStaticInfo<>(fi);
//		//InstanceFieldVariableStaticInfo varStaticInfo = new InstanceFieldVariableStaticInfo(fi,elementInfo);
//		MemoryPerturbator<?> perturbator = new FieldPerturbator(elementInfo, varStaticInfo);
//		
//		//get value guard constraint of operands
//		//List<LastModifiedLocationAttribute> operandAtt = this.getOperandAttribute(ti,sf,LastModifiedLocationAttribute.class);
//		//evaluate concrete
//		Instruction nextInsn = super.execute(ti);
//		
//		//evaluate symbolic
//		//Instruction alternativeInsn = analysis.executeAssignmentInstruction(ti,sf,this,operandAtt);
//		Instruction alternativeInsn = analysis.perturbVariable(ti,sf,this,varStaticInfo,perturbator);
//		
//		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//		perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);
//		
//		if (alternativeInsn!=null)
//			return alternativeInsn;
//		else
//			return nextInsn;
//	}

	@Override
	public VariableStaticInfo getVariableStaticInfor() {
		return new StaticFieldVariableStaticInfo<>(this.getFieldInfo()); 
	}

	@Override
	public <T> List<T> getOperandAttribute(ThreadInfo ti, StackFrame sf, Class<T> attrClazz) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/*@Override
	public Instruction execute(ThreadInfo ti) {
		Instruction nextInst = super.execute(ti);		
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis!=null && analysis.isSuspiciousScope(this)){
			StackFrame sf = ti.getModifiableTopFrame();
			ElementInfo elementInfo = this.getElementInfo(ti);
			FieldInfo fieldInfo = this.getFieldInfo();			
			//peek value		
			Object concVal=elementInfo.getFieldValueObject(this.getFieldName());
			Expression symVal =elementInfo.getFieldAttr(fieldInfo,Expression.class);
			if (symVal==null){
				Type type = ConcolicUtil.forTypeCode(fieldInfo.getTypeCode());
				symVal = Constant.createCasted(type, concVal);
			}
			
			//make new angelic symbolic variable
			Variable<?> agxVal = analysis.getOrCreateAngelicSymbolicVariable(this, ti, sf,symVal,concVal);
			Object agxValConc = analysis.getAngelicValueOfExpression(agxVal);

			//perturb symbolic/memory angelic value
			
		}
		return nextInst;
	}*/

//	private void perturbStack(ThreadInfo ti, StackFrame sf, ElementInfo elementInfo) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return;
//		FieldInfo fieldInfo = this.getFieldInfo();		
//		Type type = ConcolicUtil.forTypeCode(fieldInfo.getTypeCode());		
//		
//		if (analysis.isSuspiciousScope(this)){				
//			//peek value
//			Pair pair = ConcolicUtil.peek(sf, type);			
//			
//			//perturb symbolic/memory angelic value
//			Variable<?> agxVal = analysis.getOrCreateAngelicSymbolicVariable(this, ti, sf,pair.symb,pair.conc);
//			Object agxValConc = analysis.getAngelicValueOfExpression(agxVal);
//			
//			//update symbolic/memory state
//			ConcolicUtil.setOperand(sf, 0, type, agxValConc);
//			ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, agxVal,Expression.class);
//		}
//		
//		LastModifiedLocationAttribute attr = new LastModifiedLocationAttribute( analysis.getCurrentExecutingLocation(),null);
//		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, attr,LastModifiedLocationAttribute.class);			
//	}
//	
//	/**
//	 * @param frame
//	 * @param eiFieldOwner
//	 */
//	private void updateMemoryValue(StackFrame frame, ElementInfo eiFieldOwner) {
//		int fieldSize = fi.getStorageSize();	        
//	  if (fieldSize == 1){
//	    Object valAttr = frame.getOperandAttr();
//	    int val = frame.peek();
//	    eiFieldOwner.set1SlotField(fi, val);
//	    eiFieldOwner.setFieldAttr(fi, valAttr);
//	    lastValue= val;
//	    
//	  } else {
//	    Object valAttr = frame.getLongOperandAttr();
//	    long val = frame.peekLong();
//	    eiFieldOwner.set2SlotField(fi, val);
//	    eiFieldOwner.setFieldAttr(fi, valAttr);
//	    lastValue= val;
//	  }
//	}
//	@Override
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis == null)
//			return super.execute(ti);
//		
//		StackFrame frame = ti.getModifiableTopFrame();
//	    FieldInfo fieldInfo;
//	    
//	    //--- check if this causes a class load by a user defined classloader
//	    try {
//	      fieldInfo = getFieldInfo();
//	    } catch (LoadOnJPFRequired lre) {
//	      return ti.getPC();
//	    }
//	    
//	    if (fieldInfo == null) {
//	      return ti.createAndThrowException("java.lang.NoSuchFieldError", (className + '.' + fname));
//	    }
//
//	    //--- check if this has to trigger class initialization
//	    ClassInfo ciField = fieldInfo.getClassInfo();
//	    if (!mi.isClinit(ciField) && ciField.initializeClass(ti)) {
//	      return ti.getPC(); // this returns the next insn in the topmost clinit that just got pushed
//	    }
//	    ElementInfo eiFieldOwner = ciField.getModifiableStaticElementInfo();
//
//	    //--- check scheduling point due to shared class access
//	    Scheduler scheduler = ti.getScheduler();
//	    if (scheduler.canHaveSharedClassCG( ti, this, eiFieldOwner, fieldInfo)){
//	      eiFieldOwner = scheduler.updateClassSharedness(ti, eiFieldOwner, fi);
//	      if (scheduler.setsSharedClassCG( ti, this, eiFieldOwner, fieldInfo)){
//	        return this; // re-execute
//	      }
//	    }
//	    
//	    // check if this gets re-executed from a exposure CG (which already did the assignment
//	    if (frame.getAndResetFrameAttr(InstructionState.class) == null){
//	    	perturbStack(ti,frame,eiFieldOwner);
//	    	updateMemoryValue(frame, eiFieldOwner);
//	    }
//	      
//	    //--- check scheduling point due to exposure through shared class
//	    if (isReferenceField()){
//	      int refValue = frame.peek();
//	      if (refValue != MJIEnv.NULL){
//	        ElementInfo eiExposed = ti.getElementInfo(refValue);
//	        if (scheduler.setsSharedClassExposureCG(ti,this,eiFieldOwner,fieldInfo,eiExposed)){
//	          frame.addFrameAttr( InstructionState.processed);
//	          return this; // re-execute AFTER assignment
//	        }
//	      }        
//	    }
//	    
//	    popOperands(frame);      
//	    return getNext();
//	}

}
