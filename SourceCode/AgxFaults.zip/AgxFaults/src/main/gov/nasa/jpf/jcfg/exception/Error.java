package gov.nasa.jpf.jcfg.exception;


import static java.lang.String.format;

/**
 * @author Mike Strobel
 */
public final class Error {
    private Error() {}

    public static IllegalStateException unmodifiableCollection() {
        return new IllegalStateException("Collection is read only.");
    }

    public static IllegalArgumentException sequenceHasNoElements() {
        return new IllegalArgumentException("Sequence has no elements.");
    }

    public static IllegalArgumentException sequenceHasMultipleElements() {
        return new IllegalArgumentException("Sequence contains more than one element.");
    }

    public static IllegalArgumentException couldNotConvertFromNull() {
        return new IllegalArgumentException("Could not convert from 'null'.");
    }

    public static IllegalArgumentException couldNotConvertFromType(final Class<?> sourceType) {
        return new IllegalArgumentException(
            format("Could not convert from type '%s'.", sourceType.getName())
        );
    }

    public static IllegalArgumentException couldNotConvertNullValue(final Class<?> targetType) {
        return new IllegalArgumentException(
            format(
                "Could not convert 'null' to an instance of '%s'.",
                targetType.getName()
            )
        );
    }

    public static IllegalArgumentException couldNotConvertValue(final Class<?> sourceType, final Class<?> targetType) {
        return new IllegalArgumentException(
            format(
                "Could not convert a value of type '%s' to an instance of '%s'.",
                sourceType.getName(),
                targetType.getName()
            )
        );
    }

    public static IndexOutOfBoundsException indexOutOfRange(final int index) {
        return new IndexOutOfBoundsException(
            format("Index is out of range: %d", index)
        );
    }
}
