package gov.nasa.jpf.jcfg.exception;

import java.lang.reflect.UndeclaredThrowableException;

public class ExceptionUtilities {
	public static RuntimeException asRuntimeException(final Throwable t) {
        if (t instanceof RuntimeException) {
        return (RuntimeException) t;
    }

    return new UndeclaredThrowableException(t, "An unhandled checked exception occurred.");
}
}
