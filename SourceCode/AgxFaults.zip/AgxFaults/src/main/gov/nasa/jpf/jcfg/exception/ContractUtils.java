package gov.nasa.jpf.jcfg.exception;

public class ContractUtils {
	private ContractUtils() {
	}

	public static IllegalStateException unreachable() {
		return new IllegalStateException("Code supposed to be unreachable");
	}

	public static UnsupportedOperationException unsupported() {
		return new UnsupportedOperationException("The requested operation is not supported.");
	}

	public static UnsupportedOperationException unsupported(String msg) {
		return new UnsupportedOperationException(msg);
	}

	public static IllegalStateException unreachable(String msg) {
		return new IllegalStateException(msg);
	}
}
