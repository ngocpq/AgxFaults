package gov.nasa.jpf.jcfg.utils;
/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 * 
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */


import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * 
 */
public class SimpleProfiler {

  public static final boolean PROFILE = true;
  
  public static final Map<String,Long> cumulatedCount = new HashMap<String, Long>();
  public static final Map<String,Long> maximum = new HashMap<String, Long>();
  public static final Map<String,Long> cumulated = new HashMap<String, Long>();
  public static final Map<String,Long> pending = new HashMap<String, Long>();
  
  public static final Map<String,Long> counter = new HashMap<String, Long>();

  public static final String ERROR_TRACE_SIZE_INST_COUNTER = "ERROR_TRACE_SIZE_INST_COUNTER";
	public static final String ERROR_TRACE_SIZE_LINE_COUNTER = "ERROR_TRACE_SIZE_LINE_COUNTER";	
	public static final String ERROR_TRACE_METHOD_COUNTER = "ERROR_TRACE_METHOD_COUNTER";
	public static final String ERROR_TRACE_LINE_DISTINCT_COUNTER = "ERROR_TRACE_LINE_DISTINCT_COUNTER";
	public static final String ERROR_TRACE_INST_DISTINC_COUNTER = "ERROR_TRACE_INST_DISTINC_COUNTER";
	
  public static final void incrCounter(String name){
  	if (!PROFILE) {
      return;
    }
    long count =0;
    if (counter.containsKey(name))
    	count = counter.get(name);
    count++;
    counter.put(name, count);
  }
  
  public static void start(String name) {
    if (!PROFILE) {
      return;
    }
    long start = System.currentTimeMillis();
  
    pending.put(name,start);
    
  }
  
  public static long stop(String name) {
    if (!PROFILE) {
      return -1;
    }
    Long start = pending.remove(name);
    if (start == null) {
      return -1;
    }
    long duration = System.currentTimeMillis() - start;
    
    Long sum = cumulated.get(name);
    if (sum == null) {
      sum = (long)0;
    }
    cumulated.put(name, sum + duration);
    
    Long max = maximum.get(name);
    if (max==null|| max<duration){
    	max=duration;
    	maximum.put(name, max);
    }
    
    Long c = cumulatedCount.get(name);
    if (c == null) {
      c = (long)0;
    }
    cumulatedCount.put(name, c + 1);
    return duration;
  }  
  
  public static String getResults() {
    StringBuilder sb = new StringBuilder();
    for (Entry<String, Long> e : cumulated.entrySet()) {
      sb.append(e.getKey()).append(": ").append(e.getValue()).append(" ms [").append(e.getValue()/1000).append(" s]\n");
    }
    for (Entry<String, Long> e : counter.entrySet()) {
      sb.append(e.getKey()).append(": ").append(e.getValue()+"\n");
    }
    for (Entry<String, Long> e : cumulatedCount.entrySet()) {
      sb.append("Count_").append(e.getKey()).append(": ").append(e.getValue()+"\n");
    }
    return sb.toString();
  }
  
  public static long getMaximum(String name){
  	if (maximum.containsKey(name))
  		return maximum.get(name);
  	return -1;
  }
  public static long getCumulatedCount(String name){
  	if (cumulatedCount.containsKey(name))
  		return cumulatedCount.get(name);
  	return -1;
  }
  
  public static long getTime(String name){
  	if (cumulated.containsKey(name))
  		return cumulated.get(name);
  	return -1;
  }
  
  public static long getCounter(String name){
  	if (counter.containsKey(name))
  		return counter.get(name);
  	return 0;
  }
  
}
