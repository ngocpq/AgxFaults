/*
 * Copyright (C) 2014, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 *
 * The Java Pathfinder core (jpf-core) platform is licensed under the
 * Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 *        http://www.apache.org/licenses/LICENSE-2.0. 
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 */
package gov.nasa.jpf.jfaults.bytecode.load;

import gov.nasa.jpf.jcfg.variable.LocalVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.LocalVarInfo;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;

/**
 * Load int from local variable
 * ... => ..., value
 */
public class ILOAD extends gov.nasa.jpf.jvm.bytecode.ILOAD {

  public ILOAD(int localVarIndex){
    super(localVarIndex);
  }

  @SuppressWarnings("rawtypes")
	@Override
  public Instruction execute (ThreadInfo ti) {
  	ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
  		return super.execute(ti);
		
		StackFrame sf = ti.getTopFrame();
		LastModifiedLocationAttribute defAtt = sf.getLocalAttr(this.getLocalVariableSlot(),LastModifiedLocationAttribute.class);
		MemoryPerturbator<?> perturbator;
		LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getVariableStaticInfo(this);				
		perturbator = new StackLocalVariablePerturbator(sf, varStaticInfo);			
		if (defAtt==null){								
			defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
			perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);
		}else{				
				defAtt.setPerturbator(perturbator);				
		}
		Instruction nextInsn = analysis.executeLoadInstruction(ti,perturbator.getVariableStaticInfo(),defAtt, this);
		if (nextInsn!=null)
			return nextInsn;
		else
			return super.execute(ti);
  }

}
