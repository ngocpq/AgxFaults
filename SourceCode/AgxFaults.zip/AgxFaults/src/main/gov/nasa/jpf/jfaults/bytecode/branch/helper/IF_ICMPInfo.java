package gov.nasa.jpf.jfaults.bytecode.branch.helper;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.expressions.CastExpression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.Negation;
import gov.nasa.jpf.constraints.expressions.NumericBooleanExpression;
import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.vm.StackFrame;

public class IF_ICMPInfo extends IfBranchInfo{
	public IF_ICMPInfo(IfInstruction insn, NumericComparator cmp) {
		super(insn, cmp);
	}

	@Override
	public Pair<Boolean> popBranchConditionValue(StackFrame sf) {
		Expression<?> rsym = sf.getOperandAttr(0, Expression.class);
		Expression<?> lsym = sf.getOperandAttr(1, Expression.class);		
		if (rsym==null && lsym==null){
			boolean condVal = this.instruction.popConditionValue(sf);
			Constant<Boolean> symVal = Constant.create(BuiltinTypes.BOOL, condVal);
			return new Pair<Boolean>(condVal,symVal); //concolic value
			//return new Pair<Boolean>(this.instruction.popConditionValue(sf),null); //concolic value
		}
		
		Type<?> type;
		if (rsym!=null && lsym!=null){
			if (!rsym.getType().equals(lsym.getType())){
				if (rsym.getType() instanceof BuiltinTypes.BoolType || lsym.getType() instanceof BuiltinTypes.BoolType)
					type= BuiltinTypes.BOOL;
				else if (rsym.getType() instanceof BuiltinTypes.UInt16Type || lsym.getType() instanceof BuiltinTypes.UInt16Type)
					type= BuiltinTypes.UINT16;
				else if (rsym.getType() instanceof BuiltinTypes.SInt64Type || lsym.getType() instanceof BuiltinTypes.SInt64Type)
					type= BuiltinTypes.SINT64;
				else if (rsym.getType() instanceof BuiltinTypes.SInt32Type || lsym.getType() instanceof BuiltinTypes.SInt32Type)
					type= BuiltinTypes.SINT32;
				else if (rsym.getType() instanceof BuiltinTypes.SInt16Type || lsym.getType() instanceof BuiltinTypes.SInt16Type)
					type= BuiltinTypes.SINT16;
				else if (rsym.getType() instanceof BuiltinTypes.SInt8Type || lsym.getType() instanceof BuiltinTypes.SInt8Type)
					type= BuiltinTypes.SINT8;
				else{
					throw new IllegalStateException("Type miss match: lsym["+lsym+", "+lsym.getType()+"]; rsym["+lsym+", "+lsym.getType()+"]");
				}
				lsym = CastExpression.create(lsym, type);
				rsym = CastExpression.create(rsym, type);
			}
			type = lsym.getType();
		}else if (lsym!=null)
			type = lsym.getType();
		else
			type = rsym.getType();
				
		int cRight= sf.peek(0);
		int cLeft = sf.peek(1);
		int cmpRes = 0;
		if (cLeft < cRight)
			cmpRes = -1;
		else if (cLeft > cRight)
			cmpRes = 1;

		
		ConcolicUtil.Pair<?> right = ConcolicUtil.pop(sf,type);
		ConcolicUtil.Pair<?> left = ConcolicUtil.pop(sf,type);
		/*ConcolicUtil.Pair right = ConcolicUtil.popInt(sf);
		ConcolicUtil.Pair left = ConcolicUtil.popInt(sf);*/

		Expression<Boolean> symCondition;
		if ((cmp == NumericComparator.EQ || cmp == NumericComparator.NE)
				&& ((lsym == null || lsym.getType().equals(BuiltinTypes.BOOL))
					&& (rsym == null || rsym.getType().equals(BuiltinTypes.BOOL)))){
			
			if (lsym != null && rsym != null) { // symbolic / symbolic
				symCondition = NumericBooleanExpression.create(lsym, cmp, rsym);
			} else { // symbolic / concrete
				boolean cmpVal;
				if (lsym == null) {
					symCondition = rsym.requireAs(BuiltinTypes.BOOL);
					cmpVal = (cLeft != 0);
				} else {
					symCondition = lsym.requireAs(BuiltinTypes.BOOL);;
					cmpVal = (cRight != 0);
				}				
				int neg = (cmpVal ^ (cmp == NumericComparator.EQ)) ? 0 : 1;
				//constraints[neg] = new Negation(constraints[neg]);
				if (neg==0) //cmpVal != cmpResult
					symCondition = new Negation(symCondition);
				
			}
		} else {
			symCondition = NumericBooleanExpression.create(left.symb, cmp, right.symb);
			//constraints[0] = NumericBooleanExpression.create(left.symb, cmp, right.symb);
			//constraints[1] = NumericBooleanExpression.create(left.symb, cmp.not(), right.symb);
		}
		Pair<Boolean> result = new Pair<Boolean>(cmp.eval(cmpRes), symCondition);
		return result;
	}

	@Override
	public boolean isSymbolicConditionValue(StackFrame sf) {
		Expression<?> rsym = sf.getOperandAttr(0, Expression.class);
		Expression<?> lsym = sf.getOperandAttr(1, Expression.class);		
		if (rsym==null && lsym==null){
			return false;
		}
		//TODO: check constant formula		
		if (rsym!=null && rsym instanceof Constant && lsym !=null && lsym instanceof Constant)
			return false;
		return true;
	}
}
