package gov.nasa.jpf.jcfg.cfg;

import gov.nasa.jpf.jcfg.core.Comparer;
import gov.nasa.jpf.util.Predicate;
import gov.nasa.jpf.vm.Instruction;

public final class InstructionBlock {
    private final Instruction _firstInstruction;
    private final Instruction _lastInstruction;

    public InstructionBlock(final Instruction firstInstruction, final Instruction lastInstruction) {
        _firstInstruction = VerifyArgument.notNull(firstInstruction, "firstInstruction");
        _lastInstruction = lastInstruction;
    }

    public final Instruction getFirstInstruction() {
        return _firstInstruction;
    }

    public final Instruction getLastInstruction() {
        return _lastInstruction;
    }

    public final boolean contains(final Instruction instruction) {
        return instruction != null &&
               instruction.getPosition() >= getFirstInstruction().getPosition() &&
               instruction.getPosition() <= getLastInstruction().getPosition();
    }

    public final boolean contains(final InstructionBlock block) {
        return block != null &&
               block.getFirstInstruction().getPosition() >= getFirstInstruction().getPosition() &&
               block.getLastInstruction().getPosition() <= getLastInstruction().getPosition();
    }

//    public final boolean contains(final Range range) {
//        return range != null &&
//               range.getStart() >= getFirstInstruction().getPosition() &&
//               range.getEnd() <= getLastInstruction().getEndOffset();
//    }

    public final boolean intersects(final InstructionBlock block) {
        return block != null &&
               block.getFirstInstruction().getPosition() <= getLastInstruction().getPosition() &&
               block.getLastInstruction().getPosition() >= getFirstInstruction().getPosition();
    }

//    public final boolean intersects(final Range range) {
//        return range != null &&
//               range.getStart() <= getLastInstruction().getPosition() &&
//               range.getEnd() >= getFirstInstruction().getPosition();
//    }

    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }

        if (o instanceof InstructionBlock) {
            final InstructionBlock block = (InstructionBlock) o;

            return Comparer.equals(_firstInstruction, block._firstInstruction) &&
                   Comparer.equals(_lastInstruction, block._lastInstruction);
        }

        return false;
    }

    @Override
    public final int hashCode() {
        int result = _firstInstruction != null ? _firstInstruction.hashCode() : 0;
        result = 31 * result + (_lastInstruction != null ? _lastInstruction.hashCode() : 0);
        return result;
    }

    public final static Predicate<InstructionBlock> containsInstructionPredicate(final Instruction instruction) {
        return new Predicate<InstructionBlock>() {
            @Override
            public boolean isTrue(final InstructionBlock b) {
                return b.contains(instruction);
            }
        };
    }

    public final static Predicate<InstructionBlock> containsBlockPredicate(final InstructionBlock block) {
        return new Predicate<InstructionBlock>() {
            @Override
            public boolean isTrue(final InstructionBlock b) {
                return b.contains(block);
            }
        };
    }
}
