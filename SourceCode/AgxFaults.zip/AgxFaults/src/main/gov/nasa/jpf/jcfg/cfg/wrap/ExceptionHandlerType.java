package gov.nasa.jpf.jcfg.cfg.wrap;

public enum ExceptionHandlerType {
	Finally, Catch
}
