//package gov.nasa.jpf.jfaults.bytecode.branch.helper;
//
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Map.Entry;
//
//import gov.nasa.jpf.constraints.api.Expression;
//import gov.nasa.jpf.constraints.expressions.Constant;
//import gov.nasa.jpf.constraints.expressions.LogicalOperator;
//import gov.nasa.jpf.constraints.expressions.NumericBooleanExpression;
//import gov.nasa.jpf.constraints.expressions.NumericComparator;
//import gov.nasa.jpf.constraints.expressions.PropositionalCompound;
//import gov.nasa.jpf.jfaults.bytecode.TABLESWITCH;
//import gov.nasa.jpf.vm.Instruction;
//
//public class SwitchInfo_TableSwitch extends SwitchInfo {
//	
//	final TABLESWITCH instruction;
//	public SwitchInfo_TableSwitch(TABLESWITCH insn) {
//		super(insn);
//		this.instruction = insn;
//	}
//	/*@Override
//	public Expression<Boolean>[] buildDecisions(Expression<Integer> symbExpr) {
//		Map<Instruction, Expression<Boolean>> map = new HashMap<Instruction, Expression<Boolean>>();
//		
//		int numTargets = this.getNumTargets();	    
//	    Expression<Boolean> defaultExpr = null;
//	    for(int i = 0; i < numTargets; i++) {	    	
//	      int tgtVal = this.getTargetValue(i);
//	      Constant<Integer> c = Constant.create(symbExpr.getType(), tgtVal);
//	      Expression<Boolean> posExpr = NumericBooleanExpression.create(symbExpr, NumericComparator.EQ, c);
//	      Instruction targetPC = this.getTargetPC(i);
//	      Expression<Boolean> exp = map.get(targetPC);
//	      if (exp==null)
//	    	  exp = posExpr;
//	      else
//	    	  exp = new PropositionalCompound(exp, LogicalOperator.OR, posExpr);
//	      map.put(targetPC, exp);
//	      
//	      //result[i] = posExpr;
//	      Expression<Boolean> negExpr = NumericBooleanExpression.create(symbExpr, NumericComparator.NE, c);
//	      if(defaultExpr == null)
//	        defaultExpr = negExpr;
//	      else
//	        defaultExpr = new PropositionalCompound(defaultExpr, LogicalOperator.AND, negExpr);
//	    }
//	  
//	    Expression<Boolean>[] result = new Expression[map.size() + 1];
//	    for(Entry<Instruction, Expression<Boolean>> item:map.entrySet()){
//	    	
//	    }
//	    result[numTargets] = defaultExpr;
//	    
//	    return result;
//	}*/
//}
