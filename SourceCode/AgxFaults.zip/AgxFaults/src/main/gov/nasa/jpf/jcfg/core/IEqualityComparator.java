package gov.nasa.jpf.jcfg.core;

public interface IEqualityComparator<T> {
    boolean equals(final T o1, final T o2);
    int hash(final T o);
}