package gov.nasa.jpf.jfaults.bytecode.helper;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public interface VariableInfo<T>{
	Type<T> getVariableType();
	byte getTypeCode();
	
	T getConcreteValue(ThreadInfo ti, StackFrame sf);
	void setConcreteValue(ThreadInfo ti, StackFrame sf, T value);
	
	/*<E> E getAttribute(ThreadInfo ti, StackFrame sf,Class<E> clazz);
	void setAttribute(ThreadInfo ti, StackFrame sf, Object attr);*/
	Expression<T> getSymbolicValue(ThreadInfo ti, StackFrame sf);
	void setSymbolicValue(ThreadInfo ti, StackFrame sf, Expression<T> expr);	
}
