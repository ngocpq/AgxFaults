package gov.nasa.jpf.jcfg.cfg;

public interface Function<T, R> {
  public R apply(final T input);
}