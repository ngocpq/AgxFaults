package gov.nasa.jpf.jcfg;

import gov.nasa.jpf.Config;
import gov.nasa.jpf.ListenerAdapter;
import gov.nasa.jpf.jcfg.utils.DebugUtility;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.VM;

public class TestCFGListener extends ListenerAdapter{
	private Config conf;

	public TestCFGListener(Config conf) {
		//System.out.println("TestCFGListener constructor ");
		this.conf=conf;
		DebugUtility.setDebugCfg(true);
	}
	
	@Override
	public void methodEntered(VM vm, ThreadInfo currentThread, MethodInfo enteredMethod) {
		// TODO Auto-generated method stub
		boolean skip=false;
		if (enteredMethod.getClassInfo().isPrimitive())
			skip=true;
		String s=enteredMethod.getClassName();
		if (s.startsWith("java."))
			skip=true;
		if (s.startsWith("sun."))
			skip=true;
		
		if (!skip)
			StaticAnalysisUtility.getControlFlowGraph(enteredMethod);
		super.methodEntered(vm, currentThread, enteredMethod);
	}
}
