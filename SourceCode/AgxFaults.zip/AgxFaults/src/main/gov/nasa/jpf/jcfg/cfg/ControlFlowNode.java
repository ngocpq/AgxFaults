package gov.nasa.jpf.jcfg.cfg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import gov.nasa.jpf.jcfg.cfg.wrap.ExceptionHandlerWrapper;
import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jcfg.variable.MemoryModifiableInstruction;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jvm.bytecode.ArrayStoreInstruction;
import gov.nasa.jpf.jvm.bytecode.IINC;
import gov.nasa.jpf.jvm.bytecode.INVOKEVIRTUAL;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMInvokeInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMLocalVariableInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMReturnInstruction;
import gov.nasa.jpf.jvm.bytecode.SwitchInstruction;
import gov.nasa.jpf.util.Predicate;
import gov.nasa.jpf.vm.FieldInfo;
//import gov.nasa.jpf.vm.InfoObject;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.LocalVarInfo;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.Types;
import gov.nasa.jpf.vm.bytecode.FieldInstruction;
import gov.nasa.jpf.vm.bytecode.InstanceFieldInstruction;
import gov.nasa.jpf.vm.bytecode.InvokeInstruction;
import gov.nasa.jpf.vm.bytecode.ReturnInstruction;
import gov.nasa.jpf.vm.bytecode.StoreInstruction;
import gov.nasa.jpf.vm.bytecode.WriteInstruction;

public final class ControlFlowNode implements Comparable<ControlFlowNode> {
  private final int _blockIndex;
  private final int _offset;
  private final ControlFlowNodeType _nodeType;
  private final ControlFlowNode _endFinallyNode;
  private final List<ControlFlowNode> _dominatorTreeChildren = new ArrayList<>();
  private final List<ControlFlowNode> _postDominatorTreeChildren = new ArrayList<>();  
  private final List<ControlFlowNode> _postDominatorExceptionalExitTreeChildren = new ArrayList<>();
  private final Set<ControlFlowNode> _dominanceFrontier = new LinkedHashSet<>();
  private final Set<ControlFlowNode> _postDominanceFrontier = new LinkedHashSet<>();
  private final List<ControlFlowEdge> _incoming = new ArrayList<>();
  private final List<ControlFlowEdge> _outgoing = new ArrayList<>();

  private boolean _visited;
  private ControlFlowNode _copyFrom;
  private ControlFlowNode _immediateDominator;
  private ControlFlowNode _immediatePostDominator;
  private ControlFlowNode _immediatePostDominatorExceptionalExit;
  private Instruction _start;
  private Instruction _end;
  private ExceptionHandlerWrapper _exceptionHandler;
  private Object _userData;

  public ControlFlowNode(final int blockIndex, final int offset, final ControlFlowNodeType nodeType) {
      _blockIndex = blockIndex;
      _offset = offset;
      _nodeType = VerifyArgument.notNull(nodeType, "nodeType");
      _endFinallyNode = null;
      _start = null;
      _end = null;
  }

  public ControlFlowNode(final int blockIndex, final Instruction start, final Instruction end) {
      _blockIndex = blockIndex;
      _start =start;
      _end = end;
      _offset = start.getPosition();
      _nodeType = ControlFlowNodeType.Normal;
      _endFinallyNode = null;
  }

  public ControlFlowNode(final int blockIndex, final ExceptionHandlerWrapper exceptionHandler, final ControlFlowNode endFinallyNode) {
      _blockIndex = blockIndex;
      _exceptionHandler = exceptionHandler;
      _nodeType = exceptionHandler.isFinally() ? ControlFlowNodeType.FinallyHandler : ControlFlowNodeType.CatchHandler;
      _endFinallyNode = endFinallyNode;

      final InstructionBlock handlerBlock = exceptionHandler.getHandlerBlock();

//      _start = handlerBlock.getFirstInstruction();
//      _end = handlerBlock.getLastInstruction();
      _start = null;
      _end = null;
      _offset = handlerBlock.getFirstInstruction().getPosition(); //_start.getOffset();
  }

  public final int getBlockIndex() {
      return _blockIndex;
  }

  public final int getOffset() {
      return _offset;
  }

  public final ControlFlowNodeType getNodeType() {
      return _nodeType;
  }

  public final ControlFlowNode getEndFinallyNode() {
      return _endFinallyNode;
  }

  public final List<ControlFlowNode> getDominatorTreeChildren() {
      return _dominatorTreeChildren;
  }
  
  public final List<ControlFlowNode> getPostDominatorTreeChildren() {
      return _postDominatorTreeChildren;
  }

  public final List<ControlFlowNode> getPostDominatorExceptionalExitTreeChildren() {
    return _postDominatorExceptionalExitTreeChildren;
  }
  
  public final Set<ControlFlowNode> getDominanceFrontier() {
      return _dominanceFrontier;
  }

  public final Set<ControlFlowNode> getPostDominanceFrontier() {
      return _postDominanceFrontier;
  }
  
  public final List<ControlFlowEdge> getIncoming() {
      return _incoming;
  }

  public final List<ControlFlowEdge> getOutgoing() {
      return _outgoing;
  }

  public final boolean isVisited() {
      return _visited;
  }

  public final boolean isReachable() {
      return _immediateDominator != null || _nodeType == ControlFlowNodeType.EntryPoint;
  }

  public final ControlFlowNode getCopyFrom() {
      return _copyFrom;
  }

  public final ControlFlowNode getImmediateDominator() {
      return _immediateDominator;
  }
  
  public final ControlFlowNode getImmediatePostDominator() {
      return _immediatePostDominator;
  }

  public final Instruction getStart() {
      return _start;
  }

  public final Instruction getEnd() {
      return _end;
  }

  public final ExceptionHandlerWrapper getExceptionHandler() {
      return _exceptionHandler;
  }

  public final Object getUserData() {
      return _userData;
  }

  public final void setVisited(final boolean visited) {
      _visited = visited;
  }

  public final void setCopyFrom(final ControlFlowNode copyFrom) {
      _copyFrom = copyFrom;
  }

  public final void setImmediateDominator(final ControlFlowNode immediateDominator) {
      _immediateDominator = immediateDominator;
  }
  
  public final void setImmediatePostDominator(final ControlFlowNode immediatePostDominator) {
      _immediatePostDominator = immediatePostDominator;
  }

  public final void setStart(final Instruction start) {
      _start = start;
  }

  public final void setEnd(final Instruction end) {
      _end = end;
  }

  public final void setExceptionHandler(final ExceptionHandlerWrapper exceptionHandler) {
      _exceptionHandler = exceptionHandler;
  }

  public final void setUserData(final Object userData) {
      _userData = userData;
  }

  public final boolean succeeds(final ControlFlowNode other) {
      if (other == null) {
          return false;
      }

      for (int i = 0; i < _incoming.size(); i++) {
          if (_incoming.get(i).getSource() == other) {
              return true;
          }
      }

      return false;
  }

  public final boolean precedes(final ControlFlowNode other) {
      if (other == null) {
          return false;
      }

      for (int i = 0; i < _outgoing.size(); i++) {
          if (_outgoing.get(i).getTarget() == other) {
              return true;
          }
      }

      return false;
  }

  public final Iterable<ControlFlowNode> getPredecessors() {
      return new Iterable<ControlFlowNode>() {
          @Override
          public final Iterator<ControlFlowNode> iterator() {
              return new PredecessorIterator();
          }
      };
  }

  public final Iterable<ControlFlowNode> getSuccessors() {
      return new Iterable<ControlFlowNode>() {
          @Override
          public final Iterator<ControlFlowNode> iterator() {
              return new SuccessorIterator();
          }
      };
  }

  public final Iterable<Instruction> getInstructions() {
      return new Iterable<Instruction>() {
          @Override
          public final Iterator<Instruction> iterator() {
              return new InstructionIterator();
          }
      };
  }

  public final void traversePreOrder(
      final Function<ControlFlowNode, Iterable<ControlFlowNode>> children,
      final Block<ControlFlowNode> visitAction) {

      if (_visited) {
          return;
      }

      _visited = true;
      visitAction.accept(this);

      for (final ControlFlowNode child : children.apply(this)) {
          child.traversePreOrder(children, visitAction);
      }
  }

  public final void traversePostOrder(
      final Function<ControlFlowNode, Iterable<ControlFlowNode>> children,
      final Block<ControlFlowNode> visitAction) {

      if (_visited) {
          return;
      }

      _visited = true;

      for (final ControlFlowNode child : children.apply(this)) {
          child.traversePostOrder(children, visitAction);
      }

      visitAction.accept(this);
  }

  public final boolean dominates(final ControlFlowNode node) {
      ControlFlowNode current = node;

      while (current != null) {
          if (current == this) {
              return true;
          }
          current = current._immediateDominator;
      }

      return false;
  }

  @Override
  public final String toString() {
      final PlainTextOutput output = new PlainTextOutput();

      switch (_nodeType) {
          case Normal: {
              output.write("Block #%d", _blockIndex);

              if (_start != null) {
                  output.write(": %d to %d", _start.getPosition(), _end.getPosition()+_end.getLength());
              }

              break;
          }

          case CatchHandler:
          case FinallyHandler: {
              output.write("Block #%d: %s: ", _blockIndex, _nodeType);
              DecompilerHelpers.writeExceptionHandler(output, _exceptionHandler);
              break;
          }

          default: {
              output.write("Block #%d: %s", _blockIndex, _nodeType);
              break;
          }
      }

      output.indent();      
      if (!_dominanceFrontier.isEmpty()) {
          output.writeLine();
          output.write("DominanceFrontier: ");

          final int[] blockIndexes = new int[_dominanceFrontier.size()];

          int i = 0;

          for (final ControlFlowNode node : _dominanceFrontier) {
              blockIndexes[i++] = node._blockIndex;
          }

          Arrays.sort(blockIndexes);

          output.write(
              StringUtilities.join(
                  ", ",
                  new Iterable<String>() {
                      @Override
                      public Iterator<String> iterator() {
                          return new Iterator<String>() {
                              private int _position = 0;

                              @Override
                              public boolean hasNext() {
                                  return _position < blockIndexes.length;
                              }

                              @Override
                              public String next() {
                                  if (!hasNext()) {
                                      throw new NoSuchElementException();
                                  }
                                  return String.valueOf(blockIndexes[_position++]);
                              }

                              @Override
                              public void remove() {
                                  throw ContractUtils.unreachable();
                              }
                          };
                      }
                  }
              )
          );
      }
      
    //write dominance:
      if (this.getDominatorTreeChildren().size()>0){
    	  output.writeLine();
    	  output.write("Dominances: ");
    	  
    	  final int[] blockIndexes = new int[_dominatorTreeChildren.size()];

          int i = 0;

          for (final ControlFlowNode node : _dominatorTreeChildren) {
              blockIndexes[i++] = node._blockIndex;
          }

          Arrays.sort(blockIndexes);

          output.write(
              StringUtilities.join(
                  ", ",
                  new Iterable<String>() {
                      @Override
                      public Iterator<String> iterator() {
                          return new Iterator<String>() {
                              private int _position = 0;

                              @Override
                              public boolean hasNext() {
                                  return _position < blockIndexes.length;
                              }

                              @Override
                              public String next() {
                                  if (!hasNext()) {
                                      throw new NoSuchElementException();
                                  }
                                  return String.valueOf(blockIndexes[_position++]);
                              }

                              @Override
                              public void remove() {
                                  throw ContractUtils.unreachable();
                              }
                          };
                      }
                  }
              )
          );          
      }
      
      //immediate dominator node
      if (this.getImmediateDominator()!=null){	 
    	  output.writeLine();
	      output.writeLine("ImmediateDominator: "+this.getImmediateDominator().getBlockIndex());
      }else{
    	  output.writeLine();
    	  output.writeLine("ImmediateDominator: NONE");
      }
      
      if (!_postDominanceFrontier.isEmpty()) {
          output.writeLine();
          output.write("PostDominanceFrontier: ");

          final int[] blockIndexes = new int[_postDominanceFrontier.size()];

          int i = 0;

          for (final ControlFlowNode node : _postDominanceFrontier) {
              blockIndexes[i++] = node._blockIndex;
          }

          Arrays.sort(blockIndexes);

          output.write(
              StringUtilities.join(
                  ", ",
                  new Iterable<String>() {
                      @Override
                      public Iterator<String> iterator() {
                          return new Iterator<String>() {
                              private int _position = 0;

                              @Override
                              public boolean hasNext() {
                                  return _position < blockIndexes.length;
                              }

                              @Override
                              public String next() {
                                  if (!hasNext()) {
                                      throw new NoSuchElementException();
                                  }
                                  return String.valueOf(blockIndexes[_position++]);
                              }

                              @Override
                              public void remove() {
                                  throw ContractUtils.unreachable();
                              }
                          };
                      }
                  }
              )
          );
      }
      
      //write post dominance:
      if (this.getDominatorTreeChildren().size()>0){
    	  output.writeLine();
    	  output.write("PostDominances: ");
    	  
    	  final int[] blockIndexes = new int[_postDominatorTreeChildren.size()];

          int i = 0;

          for (final ControlFlowNode node : _postDominatorTreeChildren) {
              blockIndexes[i++] = node._blockIndex;
          }

          Arrays.sort(blockIndexes);

          output.write(
              StringUtilities.join(
                  ", ",
                  new Iterable<String>() {
                      @Override
                      public Iterator<String> iterator() {
                          return new Iterator<String>() {
                              private int _position = 0;

                              @Override
                              public boolean hasNext() {
                                  return _position < blockIndexes.length;
                              }

                              @Override
                              public String next() {
                                  if (!hasNext()) {
                                      throw new NoSuchElementException();
                                  }
                                  return String.valueOf(blockIndexes[_position++]);
                              }

                              @Override
                              public void remove() {
                                  throw ContractUtils.unreachable();
                              }
                          };
                      }
                  }
              )
          );          
      }
      
      //write post dominance exceptional exit:
      if (this.getDominatorTreeChildren().size()>0){
    	  output.writeLine();
    	  output.write("PostDominancesExcepExit: ");
    	  
    	  final int[] blockIndexes = new int[_postDominatorExceptionalExitTreeChildren.size()];

          int i = 0;

          for (final ControlFlowNode node : _postDominatorExceptionalExitTreeChildren) {
              blockIndexes[i++] = node._blockIndex;
          }

          Arrays.sort(blockIndexes);

          output.write(
              StringUtilities.join(
                  ", ",
                  new Iterable<String>() {
                      @Override
                      public Iterator<String> iterator() {
                          return new Iterator<String>() {
                              private int _position = 0;

                              @Override
                              public boolean hasNext() {
                                  return _position < blockIndexes.length;
                              }

                              @Override
                              public String next() {
                                  if (!hasNext()) {
                                      throw new NoSuchElementException();
                                  }
                                  return String.valueOf(blockIndexes[_position++]);
                              }

                              @Override
                              public void remove() {
                                  throw ContractUtils.unreachable();
                              }
                          };
                      }
                  }
              )
          );          
      }
      
      //join variables
      if (this.getJoinVariablesInfo().size()>0){
    	  output.writeLine();
    	  output.writeLine("Join variables: ");
    	  output.indent();    	
	      for (VariableStaticInfo v: this.getJoinVariablesInfo()){
	    	  output.writeLine(getVariableInfoString(v));	    	  
	      }
	      output.unindent();
      }
      
      //modifiable variables
      if (this.getModifiedVariablesInfo().size()>0){
    	  output.writeLine();
    	  output.writeLine("ModifiedVariables: ");
    	  output.indent();    	
	      for (VariableStaticInfo v: this.getModifiedVariablesInfo()){
	    	  output.writeLine(getVariableInfoString(v));
	      }
	      output.unindent();
      }
      
      //immediate node
      if (this.getImmediatePostDominator()!=null){	 
    	  output.writeLine();
	      output.writeLine("ImmediatePostDorminator: "+this.getImmediatePostDominator().getBlockIndex());
      }else{
    	  output.writeLine();
    	  output.writeLine("ImmediatePostDorminator: NONE");
      }
      
      //immediate post dominator exceptional exit node
      if (this.getImmediatePostDominatorExceptionalExit()!=null){	 
    	  output.writeLine();
	      output.writeLine("ImmPostDormExcepExit: "+this.getImmediatePostDominatorExceptionalExit().getBlockIndex());
      }else{
    	  output.writeLine();
    	  output.writeLine("ImmPostDormExcepExit: NONE");
      }
      
      for (final Instruction instruction : getInstructions()) {
          output.writeLine();
          DecompilerHelpers.writeInstruction(output, instruction);
      }

      final Object userData = _userData;

      if (userData != null) {
          output.writeLine();
          output.write(String.valueOf(userData));
      }

      output.unindent();

      return output.toString();
  }

  private String getVariableInfoString(VariableStaticInfo v) {
	  if (v instanceof LocalVarInfo){	    		
		  LocalVarInfo lcVar = (LocalVarInfo)v;
		  return lcVar.getName();
	  }
	  if (v instanceof MethodInfo){
		  return "return "+ ((MethodInfo)v).getName();
	  }
	  if (v instanceof FieldInfo)
		  return ((FieldInfo)v).getName();
	  return v.toString();
}

@Override
  public int compareTo(final ControlFlowNode o) {
      return Integer.compare(_blockIndex, o._blockIndex);
  }

  // <editor-fold defaultstate="collapsed" desc="Iterators">

  private final class PredecessorIterator implements Iterator<ControlFlowNode> {
      private Iterator<ControlFlowEdge> _innerIterator;

      @Override
      public final boolean hasNext() {
          if (_innerIterator == null) {
              _innerIterator = _incoming.listIterator();
          }

          return _innerIterator.hasNext();
      }

      @Override
      public final ControlFlowNode next() {
          if (_innerIterator == null) {
              _innerIterator = _incoming.listIterator();
          }

          return _innerIterator.next().getSource();
      }

      @Override
      public final void remove() {
          throw new UnsupportedOperationException("Unsupported operation");
      }
  }

  private final class SuccessorIterator implements Iterator<ControlFlowNode> {
      private Iterator<ControlFlowEdge> _innerIterator;

      @Override
      public final boolean hasNext() {
          if (_innerIterator == null) {
              _innerIterator = _outgoing.listIterator();
          }

          return _innerIterator.hasNext();
      }

      @Override
      public final ControlFlowNode next() {
          if (_innerIterator == null) {
              _innerIterator = _outgoing.listIterator();
          }

          return _innerIterator.next().getTarget();
      }

      @Override
      public final void remove() {
      	throw new UnsupportedOperationException("Unsupported operation");
      }
  }

  private final class InstructionIterator implements Iterator<Instruction> {
      private Instruction _next = _start;

      @Override
      public final boolean hasNext() {
          return _next != null &&
                 _next.getPosition() <= _end.getPosition();
      }

      @Override
      public final Instruction next() {
          final Instruction next = _next;

          if (next == null ||
              next.getPosition() > _end.getPosition()) {

              throw new NoSuchElementException();
          }

          _next = next.getNext();

          return next;
      }

      @Override
      public final void remove() {
      	throw new UnsupportedOperationException("Unsupported operation");
      }
  }

  // </editor-fold>

  public final static Predicate<ControlFlowNode> REACHABLE_PREDICATE = new Predicate<ControlFlowNode>() {
      @Override
      public boolean isTrue(final ControlFlowNode node) {
          return node.isReachable();
      }
  };

 //	private void addModifiedVariablesInfo(VariableStaticInfo varInfo) {
//		if (modifiedVariables1.contains(varInfo))
//			return;
//		modifiedVariables1.add(varInfo);
//	}
	
	List<VariableStaticInfo> modifiedVariables;
	private void addModifiedVariablesInfo(VariableStaticInfo varInfo) {
		if (modifiedVariables.contains(varInfo))
			return;
		modifiedVariables.add(varInfo);
	}
	
//	public void initModifiedVariableInfoList(){
//		modifiedVariables1=new ArrayList<>();
//		for(Instruction insn:this.getInstructions()){
//			//determine modified variable in block
//			VariableStaticInfo varInfo=null;
//			if (insn instanceof IINC){
//				IINC inc = (IINC)insn;
//				varInfo = inc.getMethodInfo().getLocalVar(inc.getIndex(), inc.getPosition());
//			}else if (insn instanceof StoreInstruction){						
//				if (insn instanceof JVMLocalVariableInstruction){
//					varInfo = ((JVMLocalVariableInstruction) insn).getLocalVarInfo();
//				}else if (insn instanceof ArrayStoreInstruction){					
//					//TODO: get Local Variable Info
//					ArrayStoreInstruction arrInsn = (ArrayStoreInstruction) insn;					
//					//logger.warning("Un);
//					//throw ContractUtils.unsupported("not finished implement to support ArrayStoreInstruction");
//					
//				}
//			}else if(insn instanceof WriteInstruction){									
//				varInfo = ((WriteInstruction) insn).getFieldInfo();				
//				/*if (insn instanceof FieldInstruction){					
//					FieldInstruction fiInsn = (FieldInstruction)insn;
//					fiInsn.getVariableId();				
//					
//					if (fiInsn instanceof InstanceFieldInstruction){
//						//TODO: get local variable name of instance object	
//					}
//				}*/
//			}else if (insn instanceof JVMReturnInstruction){
//				MethodInfo mi = insn.getMethodInfo();
//				if (mi.getReturnTypeCode()!=Types.T_VOID)
//					varInfo=mi;
//			}else if (insn instanceof JVMInvokeInstruction){
//				JVMInvokeInstruction invInsn = (JVMInvokeInstruction)insn;
//				MethodInfo mi = invInsn.getInvokedMethod();
//				//TODO: get possible slide effect
//			}
//			
//			if (varInfo!=null){
//				this.addModifiedVariablesInfo(varInfo);						
//			}
//		}		
//	}
	
	public void initModifiedVariableInfoList(){
		modifiedVariables=new ArrayList<>();
		for(Instruction insn:this.getInstructions()){
			//determine modified variable in block
			VariableStaticInfo varInfo=null;
			if (insn instanceof MemoryModifiableInstruction){
				MemoryModifiableInstruction vInsn = (MemoryModifiableInstruction) insn;
				varInfo = vInsn.getVariableStaticInfor();											
			}else {
				varInfo = VariableStaticInfo.getModifiableVariableStaticInfo(insn);
			}
			if (varInfo!=null){
				this.addModifiedVariablesInfo(varInfo);						
			}	
		}		
		
	}
	public List<VariableStaticInfo> getModifiedVariablesInfo(){
		if (modifiedVariables==null)
			initModifiedVariableInfoList();
		return this.modifiedVariables;
	}

	List<VariableStaticInfo> joinVariablesInfo = new ArrayList<>();
	public void addJoinVariableInfo(VariableStaticInfo v) {
		if (joinVariablesInfo.contains(v))
			return;
		joinVariablesInfo.add(v);
	}
	public List<VariableStaticInfo> getJoinVariablesInfo(){
		return this.joinVariablesInfo;
	}

	public boolean hasJoinVariables() {
		return this.joinVariablesInfo.size()>0;
	}

	/*List<VariableStaticInfo> _allModifiableVariables=new ArrayList<>();
	public List<VariableStaticInfo> getAllModifiableVariables() {
		return this._allModifiableVariables;
	}*/

	
	public void addRedefinableVariableForBranch(ControlFlowNode succNode, List<VariableStaticInfo> varsInfo) {
		for(VariableStaticInfo vInfo:varsInfo){//TODO: if varsInfo is null than init an empty list?!
			addRedefinableVariableForBranch(succNode, vInfo);
		}		
	}

	HashMap<ControlFlowNode, List<VariableStaticInfo>> branchRedefiableVarInfo=new HashMap<>();
	
	void addRedefinableVariableForBranch(ControlFlowNode succNode, VariableStaticInfo vInfo) {
		List<VariableStaticInfo> vars = branchRedefiableVarInfo.get(succNode);
		if (vars==null){
			if (!this.precedes(succNode))
				ContractUtils.unreachable("addRedefinableVariableForBranch: not precedes"); 
			vars = new ArrayList<>();
			branchRedefiableVarInfo.put(succNode, vars);
		}
		if (!vars.contains(vInfo))
			vars.add(vInfo);
	}

	public List<VariableStaticInfo> getRedefinableVariableOfBranch(ControlFlowNode succNode) {
		List<VariableStaticInfo> vars = branchRedefiableVarInfo.get(succNode);
		if (vars==null){
			return null;
		}
		return vars;
	}

	public ControlFlowNode getImmediatePostDominatorExceptionalExit(){
		return this._immediatePostDominatorExceptionalExit;
	}
	public void setImmediatePostDominatorExceptionalExit(ControlFlowNode node) {
		this._immediatePostDominatorExceptionalExit = node;
	}

	/*private boolean isBeginBranch=false;
	public void setIsBeginBranch(boolean value) {
		this.isBeginBranch=value;
	}

	public boolean isBeginBranch() {
		return this.isBeginBranch;
	}	*/

}
