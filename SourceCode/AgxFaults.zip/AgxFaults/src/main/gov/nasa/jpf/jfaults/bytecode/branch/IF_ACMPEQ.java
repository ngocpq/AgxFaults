package gov.nasa.jpf.jfaults.bytecode.branch;
import gov.nasa.jpf.jfaults.bytecode.helper.DecisionConstraint_Helper;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.ThreadInfo;

public class IF_ACMPEQ extends gov.nasa.jpf.jvm.bytecode.IF_ACMPEQ {

	public IF_ACMPEQ(int targetPc) {
		super(targetPc);		
	}

	@Override
	public Instruction execute(ThreadInfo ti) {
		Instruction res = DecisionConstraint_Helper.executeBranch(ti, this);
		if (res != null) {
			conditionValue = (res == this.target);
			return res;
		}
		return super.execute(ti);
	}
}
