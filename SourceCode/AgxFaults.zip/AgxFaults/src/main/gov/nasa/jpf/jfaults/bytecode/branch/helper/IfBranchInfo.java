package gov.nasa.jpf.jfaults.bytecode.branch.helper;

import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.vm.Instruction;

public abstract class IfBranchInfo extends BranchVariableInfo<Boolean>{	
	IfInstruction instruction;
	NumericComparator cmp;
	public IfBranchInfo(IfInstruction insn,NumericComparator cmp) {
		super(insn);
		this.instruction = insn;
		this.cmp = cmp;
	}
	
	@Override
	public int getNumTargets() {		
		return 1;
	}

	@Override
	public Boolean getTargetValue(int targetIdx) {		
		if (targetIdx==0)
			return true;
		else
			return false;
	}


	@Override
	public Instruction getTargetPC(int branchIdx) {
		if (branchIdx==0)
			return instruction.getTarget();
		return instruction.getNext();
	}
	
}
