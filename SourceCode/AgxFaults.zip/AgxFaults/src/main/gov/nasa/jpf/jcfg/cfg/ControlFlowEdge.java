package gov.nasa.jpf.jcfg.cfg;

public final class ControlFlowEdge {
  private final ControlFlowNode _source;
  private final ControlFlowNode _target;
  private final JumpType _type;

  public ControlFlowEdge(final ControlFlowNode source, final ControlFlowNode target, final JumpType type) {
      _source = VerifyArgument.notNull(source, "source");
      _target = VerifyArgument.notNull(target, "target");
      _type = VerifyArgument.notNull(type, "type");
  }

  public final ControlFlowNode getSource() {
      return _source;
  }

  public final ControlFlowNode getTarget() {
      return _target;
  }

  public final JumpType getType() {
      return _type;
  }

  @Override
  public boolean equals(final Object obj) {
      if (obj instanceof ControlFlowEdge) {
          final ControlFlowEdge other = (ControlFlowEdge) obj;

          return other._source == _source &&
                 other._target == _target;
      }

      return false;
  }

  @Override
  public final String toString() {
      switch (_type) {
          case Normal:
              return "#" + _target.getBlockIndex();

          case JumpToExceptionHandler:
              return "e:#" + _target.getBlockIndex();

          default:
              return _type + ":#" + _target.getBlockIndex();
      }
  }
}
