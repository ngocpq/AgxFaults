package gov.nasa.jpf.jcfg.cfg;

public enum OpCodeType {
  Annotation,
  Macro,
  Internal,
  ObjectModel,
  Prefix,
  Primitive,
}
