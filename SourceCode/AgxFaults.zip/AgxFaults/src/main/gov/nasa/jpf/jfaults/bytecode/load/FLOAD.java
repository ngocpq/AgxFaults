package gov.nasa.jpf.jfaults.bytecode.load;

import gov.nasa.jpf.jcfg.variable.LocalVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.perturb.FieldPerturbator;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.LocalVarInfo;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;

public class FLOAD extends gov.nasa.jpf.jvm.bytecode.FLOAD{

	public FLOAD(int localVarIndex) {
		super(localVarIndex);
	}

	@SuppressWarnings("rawtypes")
	@Override
  public Instruction execute (ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
  		return super.execute(ti);
		
		StackFrame sf = ti.getTopFrame();
		LastModifiedLocationAttribute defAtt = sf.getLocalAttr(this.getLocalVariableSlot(),LastModifiedLocationAttribute.class);
		MemoryPerturbator<?> perturbator;
		LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getVariableStaticInfo(this);				
		perturbator = new StackLocalVariablePerturbator(sf, varStaticInfo);
		if (defAtt==null){								
			defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
			perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);
		}else{				
				defAtt.setPerturbator(perturbator);				
		}
		Instruction nextInsn = analysis.executeLoadInstruction(ti,perturbator.getVariableStaticInfo(),defAtt, this);
		if (nextInsn!=null)
			return nextInsn;
		else
			return super.execute(ti);
  }

//  @SuppressWarnings("rawtypes")
//	private VariableStaticInfo getVariableStaticInfor() {
//		MethodInfo mInfo = this.getMethodInfo();
//		LocalVarInfo varInfo = mInfo.getLocalVar(this.index, this.getPosition());
//		if (varInfo!=null)
//			return new LocalVariableStaticInfo(mInfo, varInfo);
//		String varName = this.getVariableId();			
//		byte typeCode = Types.T_FLOAT;
//		int slot = this.getLocalVariableIndex();
//		return new LocalVariableStaticInfo<Integer>(mInfo,varName,slot,typeCode,false);	
//	}
}
