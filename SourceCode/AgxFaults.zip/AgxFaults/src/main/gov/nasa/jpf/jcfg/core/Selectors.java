package gov.nasa.jpf.jcfg.core;

import gov.nasa.jpf.jcfg.cfg.VerifyArgument;
import gov.nasa.jpf.jcfg.exception.ContractUtils;

public final class Selectors {
  private final static Selector<?, ?> IDENTITY_SELECTOR = new Selector<Object, Object>() {
      @Override
      public Object select(final Object source) {
          return source;
      }
  };

  private final static Selector<String, String> TO_UPPERCASE = new Selector<String, String>() {
      @Override
      public String select(final String source) {
          if (source == null) {
              return null;
          }
          return source.toUpperCase();
      }
  };

  private final static Selector<String, String> TO_LOWERCASE = new Selector<String, String>() {
      @Override
      public String select(final String source) {
          if (source == null) {
              return null;
          }
          return source.toUpperCase();
      }
  };

  private final static Selector<?, String> TO_STRING = new Selector<Object, String>() {
      @Override
      public String select(final Object source) {
          if (source == null) {
              return null;
          }
          return source.toString();
      }
  };

  private Selectors() {
      throw ContractUtils.unreachable();
  }

  public static <T> Selector<T, T> identity() {
      return (Selector<T, T>)IDENTITY_SELECTOR;
  }

  public static Selector<String, String> toUpperCase() {
      return TO_UPPERCASE;
  }

  public static Selector<String, String> toLowerCase() {
      return TO_LOWERCASE;
  }

  public static <T> Selector<T, String> asString() {
      return (Selector<T, String>)TO_STRING;
  }

  public static <T, R> Selector<T, R> cast(final Class<R> destinationType) {
      return new Selector<T, R>() {
          @Override
          public R select(final T source) {
              return destinationType.cast(source);
          }
      };
  }

  public static <T, U, R> Selector<T, R> combine(
      final Selector<? super T, ? extends U> first,
      final Selector<? super U, ? extends R> second) {

      VerifyArgument.notNull(first, "first");
      VerifyArgument.notNull(second, "second");

      return new Selector<T, R>() {
          @Override
          public R select(final T source) {
              return second.select(first.select(source));
          }
      };
  }
}
