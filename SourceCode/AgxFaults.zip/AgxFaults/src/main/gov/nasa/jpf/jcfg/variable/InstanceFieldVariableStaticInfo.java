package gov.nasa.jpf.jcfg.variable;

import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.FieldInfo;

public class InstanceFieldVariableStaticInfo<T> extends StaticFieldVariableStaticInfo<T>{
	final ElementInfo elementInfo;
	public InstanceFieldVariableStaticInfo(FieldInfo fInfo,ElementInfo elementInfo) {
		super(fInfo);
		this.elementInfo = elementInfo; 
	}
	@Override
	public String getVarUniqueId() {
		return "__Heap"+elementInfo.getObjectRef()+"." + fieldInfo.getClassInfo().getName()+"."+ fieldInfo.getName();
	}
}
