package gov.nasa.jpf.jfaults.bytecode.assignment;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.constraints.util.ExpressionUtil;
import gov.nasa.jpf.jcfg.utils.InstructionUtil;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public class IRETURN_SSA extends gov.nasa.jpf.jvm.bytecode.IRETURN{
	
	public Instruction execute(ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
			return super.execute(ti);
		
		StackFrame sf = ti.getModifiableTopFrame();
		analysis.analyzePrimaryReturnValue(ti, sf, this);
		return super.execute(ti);
	}
	
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return super.execute(ti);
//		
//		StackFrame sf = ti.getModifiableTopFrame();
//		//get value guard constraint of operands
//		LastModifiedLocationAttribute opDefAtt = sf.getOperandAttr(LastModifiedLocationAttribute.class);
//		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(this,analysis);
//		
//		byte typeCode = this.getMethodInfo().getReturnTypeCode();
//		Type type = ConcolicUtil.forTypeCode(typeCode);
//		Pair val = ConcolicUtil.peek(sf, type);
//			
//		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
//			String varUniqueId = InstructionUtil.getUniqueIdString(this);
//			varUniqueId = "@PHI@"+varUniqueId;
//			val = analysis.getOrCreateSummaryVariablePair(this, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);			
//		}
//		
//		Pair updatedAttr = val;
//		if (analysis.isSuspiciousScope(this)){			
//			String varUniqueId = InstructionUtil.getUniqueIdString(this);
//			updatedAttr = analysis.getOrCreateAngelicVariable(this,varUniqueId, ti, sf, val.symb, val.conc);
//			//perturb stack operand
//			ConcolicUtil.perturbOperand(sf, 0, updatedAttr);
//		}
//		
//		MemoryPerturbator<?> perturbator = null;
//		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, val.symb.getType(), defAtt, LastModifiedLocationAttribute.class);
//		
//		return super.execute(ti);
//	}
	
//	//private static final JPFLogger logger = JPF.getLogger("jdart");
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);		
//		if (analysis!=null && analysis.isSuspiciousScope(this)){			
//			StackFrame sf = ti.getModifiableTopFrame();
//			
//			byte typeCode = this.getMethodInfo().getReturnTypeCode();
//			Type type = ConcolicUtil.forTypeCode(typeCode);
//			Pair val = ConcolicUtil.peek(sf, type);
//					
//			Variable agxVal = analysis.getOrCreateAngelicSymbolicVariable(this, ti, sf,val.symb,val.conc);
//
//			//perturb
//			Object agelicValue = analysis.getAngelicValueOfExpression(agxVal);				
//			ConcolicUtil.setOperand(sf, 0, type, agelicValue);
//			ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, agxVal,Expression.class);
//			
//			LastModifiedLocationAttribute attr = new LastModifiedLocationAttribute( analysis.getCurrentExecutingLocation(),null);
//			ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, attr,LastModifiedLocationAttribute.class);
//		}
//		return super.execute(ti);
//	}
	
	
//	@Override
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti); 
//		if (analysis==null)
//			return super.execute(ti);
//		
//		StackFrame sf = ti.getTopFrame();
//		LastModifiedInstructionMarker lastDefine = sf.getOperandAttr(LastModifiedInstructionMarker.class);		
//		
//		SymbolicReturnVariableSSA ssaVar = analysis.createSymbolicReturnVariable(ti,(JVMReturnInstruction) this);
//		if (ssaVar!=null){
//			Expression<Boolean> pathConstraint=null;
//			if (lastDefine!=null)
//				pathConstraint = lastDefine.getModifiedGualdConstraints(this,analysis);		
//				
//			if (pathConstraint!=null && !ExpressionUtil.isBoolConst(pathConstraint, true)){
//				//return value is a result of expression that contain IF instruction
//				if (ssaVar.getSymbolValue().getType()==BuiltinTypes.BOOL){
//					if (ssaVar.getConcreteValue()==Boolean.TRUE){
//						ssaVar.setSymbolicValue(pathConstraint);
//					}else{
//						ssaVar.setSymbolicValue(new Negation(pathConstraint));
//					}
//				}else
//					logger.warning("IRETURN_SSA pathConstraint may not be handled correctly for non Bool type variable: "+ssaVar.getVariableName());
//			}
//			
//			analysis.perturbVariableValue(ssaVar,this,ti);
//			Expression<Boolean> constraint = ExpressionUtil.makeEqualityExpression(ssaVar.getVariable(),ssaVar.getSymbolValue());
//			SymbolicExecutionTraceItem traceItem = new ReturnExecutionTraceItem((ReturnInstruction) this,ti.getTopFrame(),ssaVar);	  				
//			analysis.addConstraint(traceItem,constraint);
//			
//			lastDefine = new LastModifiedInstructionMarker(this,analysis.getInternalConstraintsTree().getCurrentOpenBranchNode()); //.getCurrentNode());
//			VariableInfo varInfo = new MethodReturnVariableInfo(this.getMethodInfo());
//			varInfo.markLastModified(lastDefine, ti, sf);
//			
//			//check for Phi value
//			/*ControlFlowNode cfn = ControlFlowUtils.getControlFlowNode(this);
//			boolean needPhi = false;
//			for(ControlFlowNode df:cfn.getDominanceFrontier()){
//				if (df.getNodeType()== ControlFlowNodeType.RegularExit){
//					//return statement is inside a if => there are another path to another return
//					needPhi=true;
//					break;
//				}
//			}
//			//TODO
//			if (needPhi){
//				lastDefine = new LastModifiedInstructionMarker(cfn,analysis.getInternalConstraintsTree().getCurrentOpenBranchNode()); //.getCurrentNode());
//				VariableInfo varInfo = new MethodReturnVariableInfo(this.getMethodInfo());
//				varInfo.markLastModified(lastDefine, ti, sf);
//				analysis.processJoin(this, this, ti);				
//			}*/
//		}
//		
//		Instruction rs = super.execute(ti);
//		return rs;
//	}

	
}
