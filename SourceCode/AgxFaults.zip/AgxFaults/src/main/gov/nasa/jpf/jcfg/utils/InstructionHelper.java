package gov.nasa.jpf.jcfg.utils;

import gov.nasa.jpf.jvm.bytecode.ATHROW;
import gov.nasa.jpf.jvm.bytecode.GOTO;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.jvm.bytecode.JSR;
import gov.nasa.jpf.jvm.bytecode.JSR_W;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.bytecode.ReturnInstruction;

public class InstructionHelper {

	public static boolean isBranch(Instruction insn) {
		if (insn instanceof IfInstruction)
			return true;
		if (insn instanceof GOTO)
			return true;
		if (insn instanceof ReturnInstruction)
			return true;
		if (insn instanceof ATHROW)
			return true;		
		return false;
	}

	public static boolean isUnconditionalBranch(Instruction insn) {
		if (insn instanceof GOTO)
			return true;
		if (insn instanceof ReturnInstruction)
			return true;
		if (insn instanceof ATHROW)
			return true;		
		return false;
	}

	public static boolean isJumpToSubroutine(Instruction insn) {
		if (insn instanceof JSR)
			return true;
		if (insn instanceof JSR_W)
			return true;
		return false;
	}

}
