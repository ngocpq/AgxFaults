package gov.nasa.jpf.jcfg.variable;

import java.util.List;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.bytecode.InstructionInterface;

public interface MemoryModifiableInstruction extends InstructionInterface {

	VariableStaticInfo getVariableStaticInfor();
	<T> List<T> getOperandAttribute(ThreadInfo ti, StackFrame sf, Class<T> attrClazz);
}
