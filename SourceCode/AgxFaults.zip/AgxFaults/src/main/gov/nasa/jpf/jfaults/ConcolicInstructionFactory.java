/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 * 
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */
package gov.nasa.jpf.jfaults;

import gov.nasa.jpf.JPF;
import gov.nasa.jpf.jfaults.bytecode.ATHROW;
import gov.nasa.jpf.jfaults.bytecode.D2F;
import gov.nasa.jpf.jfaults.bytecode.D2I;
import gov.nasa.jpf.jfaults.bytecode.D2L;
import gov.nasa.jpf.jfaults.bytecode.DADD;
import gov.nasa.jpf.jfaults.bytecode.DCMPG;
import gov.nasa.jpf.jfaults.bytecode.DCMPL;
import gov.nasa.jpf.jfaults.bytecode.DDIV;
import gov.nasa.jpf.jfaults.bytecode.DMUL;
import gov.nasa.jpf.jfaults.bytecode.DNEG;
import gov.nasa.jpf.jfaults.bytecode.DREM;
import gov.nasa.jpf.jfaults.bytecode.DSUB;
import gov.nasa.jpf.jfaults.bytecode.F2D;
import gov.nasa.jpf.jfaults.bytecode.F2I;
import gov.nasa.jpf.jfaults.bytecode.F2L;
import gov.nasa.jpf.jfaults.bytecode.FADD;
import gov.nasa.jpf.jfaults.bytecode.FCMPG;
import gov.nasa.jpf.jfaults.bytecode.FCMPL;
import gov.nasa.jpf.jfaults.bytecode.FDIV;
import gov.nasa.jpf.jfaults.bytecode.FMUL;
import gov.nasa.jpf.jfaults.bytecode.FNEG;
import gov.nasa.jpf.jfaults.bytecode.FREM;
import gov.nasa.jpf.jfaults.bytecode.FSUB;
import gov.nasa.jpf.jfaults.bytecode.I2B;
import gov.nasa.jpf.jfaults.bytecode.I2C;
import gov.nasa.jpf.jfaults.bytecode.I2D;
import gov.nasa.jpf.jfaults.bytecode.I2F;
import gov.nasa.jpf.jfaults.bytecode.I2L;
import gov.nasa.jpf.jfaults.bytecode.I2S;
import gov.nasa.jpf.jfaults.bytecode.IADD;
import gov.nasa.jpf.jfaults.bytecode.IAND;
import gov.nasa.jpf.jfaults.bytecode.IDIV;
import gov.nasa.jpf.jfaults.bytecode.IMUL;
import gov.nasa.jpf.jfaults.bytecode.INEG;
import gov.nasa.jpf.jfaults.bytecode.IOR;
import gov.nasa.jpf.jfaults.bytecode.IREM;
import gov.nasa.jpf.jfaults.bytecode.ISHL;
import gov.nasa.jpf.jfaults.bytecode.ISHR;
import gov.nasa.jpf.jfaults.bytecode.ISUB;
import gov.nasa.jpf.jfaults.bytecode.IUSHR;
import gov.nasa.jpf.jfaults.bytecode.IXOR;
import gov.nasa.jpf.jfaults.bytecode.L2D;
import gov.nasa.jpf.jfaults.bytecode.L2F;
import gov.nasa.jpf.jfaults.bytecode.L2I;
import gov.nasa.jpf.jfaults.bytecode.LADD;
import gov.nasa.jpf.jfaults.bytecode.LAND;
import gov.nasa.jpf.jfaults.bytecode.LCMP;
import gov.nasa.jpf.jfaults.bytecode.LDIV;
import gov.nasa.jpf.jfaults.bytecode.LMUL;
import gov.nasa.jpf.jfaults.bytecode.LNEG;
import gov.nasa.jpf.jfaults.bytecode.LOR;
import gov.nasa.jpf.jfaults.bytecode.LREM;
import gov.nasa.jpf.jfaults.bytecode.LSHL;
import gov.nasa.jpf.jfaults.bytecode.LSHR;
import gov.nasa.jpf.jfaults.bytecode.LSUB;
import gov.nasa.jpf.jfaults.bytecode.LUSHR;
import gov.nasa.jpf.jfaults.bytecode.LXOR;
import gov.nasa.jpf.jfaults.bytecode.TABLESWITCH;
import gov.nasa.jpf.jfaults.bytecode.array.AALOAD;
import gov.nasa.jpf.jfaults.bytecode.array.AASTORE;
import gov.nasa.jpf.jfaults.bytecode.array.BALOAD;
import gov.nasa.jpf.jfaults.bytecode.array.BASTORE;
import gov.nasa.jpf.jfaults.bytecode.array.CALOAD;
import gov.nasa.jpf.jfaults.bytecode.array.CASTORE;
import gov.nasa.jpf.jfaults.bytecode.array.DALOAD;
import gov.nasa.jpf.jfaults.bytecode.array.DASTORE;
import gov.nasa.jpf.jfaults.bytecode.array.FALOAD;
import gov.nasa.jpf.jfaults.bytecode.array.FASTORE;
import gov.nasa.jpf.jfaults.bytecode.array.IALOAD;
import gov.nasa.jpf.jfaults.bytecode.array.IASTORE;
import gov.nasa.jpf.jfaults.bytecode.array.LASTORE;
import gov.nasa.jpf.jfaults.bytecode.assignment.ARETURN;
import gov.nasa.jpf.jfaults.bytecode.assignment.ASTORE_SSA;
import gov.nasa.jpf.jfaults.bytecode.assignment.DRETURN;
import gov.nasa.jpf.jfaults.bytecode.assignment.DSTORE_SSA;
import gov.nasa.jpf.jfaults.bytecode.assignment.FRETURN;
import gov.nasa.jpf.jfaults.bytecode.assignment.FSTORE;
import gov.nasa.jpf.jfaults.bytecode.assignment.IINC_SSA;
import gov.nasa.jpf.jfaults.bytecode.assignment.IRETURN_SSA;
import gov.nasa.jpf.jfaults.bytecode.assignment.ISTORE_SSA;
import gov.nasa.jpf.jfaults.bytecode.assignment.LRETURN;
import gov.nasa.jpf.jfaults.bytecode.assignment.LSTORE_SSA;
import gov.nasa.jpf.jfaults.bytecode.field.GETFIELD;
import gov.nasa.jpf.jfaults.bytecode.field.PUTFIELD_SSA;
import gov.nasa.jpf.jfaults.bytecode.field.PUTSTATIC_SSA;
import gov.nasa.jpf.jfaults.bytecode.invoke.EXECUTENATIVE;
import gov.nasa.jpf.jfaults.bytecode.invoke.INVOKEVIRTUAL;
import gov.nasa.jpf.jfaults.bytecode.invoke.NATIVERETURN;
import gov.nasa.jpf.jfaults.bytecode.load.FLOAD;
import gov.nasa.jpf.jfaults.bytecode.load.ILOAD;
import gov.nasa.jpf.jfaults.bytecode.invoke.INVOKEINTERFACE;
import gov.nasa.jpf.jfaults.bytecode.field.GETSTATIC;
import gov.nasa.jpf.jfaults.bytecode.load.ALOAD;
import gov.nasa.jpf.jfaults.bytecode.branch.IFEQ;
import gov.nasa.jpf.jfaults.bytecode.branch.IFGE;
import gov.nasa.jpf.jfaults.bytecode.branch.IFGT;
import gov.nasa.jpf.jfaults.bytecode.branch.IFLE;
import gov.nasa.jpf.jfaults.bytecode.branch.IFLT;
import gov.nasa.jpf.jfaults.bytecode.branch.IFNE;
import gov.nasa.jpf.jfaults.bytecode.branch.IFNONNULL;
import gov.nasa.jpf.jfaults.bytecode.branch.IFNULL;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPEQ;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPGE;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPGT;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPLE;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPLT;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPNE;
import gov.nasa.jpf.jfaults.bytecode.branch.LOOKUPSWITCH;
import gov.nasa.jpf.jfaults.bytecode.ICONST;
import gov.nasa.jpf.util.JPFLogger;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.NativeMethodInfo;

/**
 * Contains jdart (concrete and symbolic) bytecodes.
 */

/*
 * Refactored version to use the DefaultInstructionFactory -- re-written corina
 */
public class ConcolicInstructionFactory extends gov.nasa.jpf.jvm.bytecode.InstructionFactory {
	
  public static final boolean DEBUG = false;
  public static JPFLogger logger = JPF.getLogger("jdart");
  

  /* (non-Javadoc)
   * @see gov.nasa.jpf.jvm.bytecode.InstructionFactory#executenative(gov.nasa.jpf.vm.NativeMethodInfo)
   */
  @Override
  public Instruction executenative(NativeMethodInfo mi) {
    return new EXECUTENATIVE(mi);
  }

  /* (non-Javadoc)
   * @see gov.nasa.jpf.jvm.bytecode.InstructionFactory#nativereturn()
   */
  @Override
  public Instruction nativereturn() {
    return new NATIVERETURN();
  }
  
  @Override
  public gov.nasa.jpf.jvm.bytecode.ATHROW athrow() {
    return new ATHROW();
  }

	@Override
	public gov.nasa.jpf.jvm.bytecode.IADD iadd() {
	  return new IADD();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IAND iand() {
		return new IAND();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IINC iinc(int localVarIndex, int incConstant) {
		//return new IINC(localVarIndex, incConstant);
		return new IINC_SSA(localVarIndex, incConstant);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.ISUB isub() {
		return new ISUB();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IMUL imul() {
		return new IMUL();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.INEG ineg() {
		return new INEG();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IFLE ifle(int targetPc) {
		return new IFLE(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IFLT iflt(int targetPc) {
		return new IFLT(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IFGE ifge(int targetPc) {
		return new IFGE(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IFGT ifgt(int targetPc) {
		return new IFGT(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IFEQ ifeq(int targetPc) {
		return new IFEQ(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IFNE ifne(int targetPc) {
		return new IFNE(targetPc);
	}
	
	@Override
	public gov.nasa.jpf.jvm.bytecode.IF_ICMPGE if_icmpge(int targetPc) {
		return new IF_ICMPGE(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IF_ICMPGT if_icmpgt(int targetPc) {
		return new IF_ICMPGT(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IF_ICMPLE if_icmple(int targetPc) {
		return new IF_ICMPLE(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IF_ICMPLT if_icmplt(int targetPc) {
		return new IF_ICMPLT(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IDIV idiv() {
		return new IDIV();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.ISHL ishl() {
		return new ISHL();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.ISHR ishr() {
		return new ISHR();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IUSHR iushr() {
		return new IUSHR();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IXOR ixor() {
		return new IXOR();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IOR ior() {
		return new IOR();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IREM irem() {
		return new IREM();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IF_ICMPEQ if_icmpeq(int targetPc) {
		return new IF_ICMPEQ(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.IF_ICMPNE if_icmpne(int targetPc) {
		return new IF_ICMPNE(targetPc);
	}

	@Override
	public Instruction ifnull(int targetPc) {
		return new IFNULL(targetPc);
	}
	@Override
	public Instruction ifnonnull(int targetPc) {
		return new IFNONNULL(targetPc);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.FADD fadd() {
		return new FADD();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.FDIV fdiv() {
		return new FDIV();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.FMUL fmul() {
		return new FMUL();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.FNEG fneg() {
		return new FNEG();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.FREM frem() {
		return new FREM();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.FSUB fsub() {
		return new FSUB();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.FCMPG fcmpg() {
		return new FCMPG();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.FCMPL fcmpl() {
		return new FCMPL();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.DADD dadd() {
		return new DADD();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.DCMPG dcmpg() {
		return new DCMPG();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.DCMPL dcmpl() {
		return new DCMPL();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.DDIV ddiv() {
		return new DDIV();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.DMUL dmul() {
		return new DMUL();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.DNEG dneg() {
		return new DNEG();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.DREM drem() {
		return new DREM();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.DSUB dsub() {
		return new DSUB();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LADD ladd() {
		return new LADD();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LAND land() {
		return new LAND();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LCMP lcmp() {
		return new LCMP();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LDIV ldiv() {
		return new LDIV();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LMUL lmul() {
		return new LMUL();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LNEG lneg() {
		return new LNEG();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LOR lor() {
		return new LOR();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LREM lrem() {
		return new LREM();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LSHL lshl() {
		return new LSHL();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LSHR lshr() {
		return new LSHR();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LSUB lsub() {
		return new LSUB();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LUSHR lushr() {
		return new LUSHR();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.LXOR lxor() {
		return new LXOR();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.I2D i2d() {
		return new I2D();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.D2I d2i() {
		return new D2I();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.D2L d2l() {
		return  new D2L();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.I2F i2f() {
		return  new I2F();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.L2D l2d() {
		return  new L2D();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.L2F l2f() {
		return  new L2F();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.F2L f2l() {
		return  new F2L();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.F2I f2i() {
		return  new F2I();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.SwitchInstruction lookupswitch(int defaultTargetPc, int nEntries) {
		return  new LOOKUPSWITCH(defaultTargetPc, nEntries);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.SwitchInstruction tableswitch(int defaultTargetPc, int low, int high) {
		return  new TABLESWITCH(defaultTargetPc, low, high);
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.D2F d2f() {
		return  new D2F();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.F2D f2d() {
		return  new F2D();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.I2B i2b() {
		return  new I2B();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.I2C i2c() {
		return  new I2C();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.I2S i2s() {
		return  new I2S();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.I2L i2l() {
		return  new I2L();
	}

	@Override
	public gov.nasa.jpf.jvm.bytecode.L2I l2i() {
		return  new L2I();
	}
  
	
	@Override
	public Instruction fstore(int localVarIndex) {
		return new FSTORE(localVarIndex);
	}
	
	@Override
	public Instruction fstore_0() {
		return new FSTORE(0);
	}
	
	@Override
	public Instruction fstore_1() {
		return new FSTORE(1);
	}
	
	@Override
	public Instruction fstore_2() {
		return new FSTORE(2);
	}
	
	@Override
	public Instruction fstore_3() {
		return new FSTORE(3);
	}
	
	@Override
	public Instruction dstore(int localVarIndex) {
		return new DSTORE_SSA(localVarIndex);
	}
	
	@Override
	public Instruction dstore_0() {
		return new DSTORE_SSA(0);
	}
	
	@Override
	public Instruction dstore_1() {
		return new DSTORE_SSA(1);
	}
	
	@Override
	public Instruction dstore_2() {
		return new DSTORE_SSA(2);
	}
	
	@Override
	public Instruction dstore_3() {
		return new DSTORE_SSA(3);
	}	
	
	@Override
	public Instruction istore(int localVarIndex) {
		return new ISTORE_SSA(localVarIndex);
	}

	@Override
	public Instruction istore_0() {
		return new ISTORE_SSA(0);
	}

	@Override
	public Instruction istore_1() {
		return new ISTORE_SSA(1);
	}

	@Override
	public Instruction istore_2() {
		return new ISTORE_SSA(2);
	}

	@Override
	public Instruction istore_3() {		
		return new ISTORE_SSA(3);
	}
	
	@Override
	public Instruction lstore(int localVarIndex) {
		return new LSTORE_SSA(localVarIndex);
	}

	@Override
	public Instruction lstore_0() {
		return new LSTORE_SSA(0);
	}

	@Override
	public Instruction lstore_1() {
		return new LSTORE_SSA(1);
	}

	@Override
	public Instruction lstore_2() {
		return new LSTORE_SSA(2);
	}

	@Override
	public Instruction lstore_3() {
		return new LSTORE_SSA(3);
	}
	
	@Override
	public Instruction ireturn() {
		return new IRETURN_SSA();
	}
	
	@Override
	public Instruction freturn() {
		return new FRETURN();
	}
	@Override
	public Instruction dreturn() {
		return new DRETURN();
	}
	
	@Override
	public Instruction areturn() {
		return new ARETURN();
	}
	
	@Override
	public Instruction lreturn() {
		return new LRETURN();
	}	
	
	@Override
  public Instruction iconst_m1() {
    return new ICONST(-1);
  }

  @Override
  public Instruction iconst_0() {
    return new ICONST(0);
  }

  @Override
  public Instruction iconst_1() {
    return new ICONST(1);
  }

  @Override
  public Instruction iconst_2() {
    return new ICONST(2);
  }

  @Override
  public Instruction iconst_3() {
    return new ICONST(3);
  }

  @Override
  public Instruction iconst_4() {
    return new ICONST(4);
  }

  @Override
  public Instruction iconst_5() {
    return new ICONST(5);
  }
  
  @Override
  public Instruction aload(int localVarIndex) {
  	return new ALOAD(localVarIndex);
  }
  @Override
  public Instruction aload_0() {
    return new ALOAD(0);
  }

  @Override
  public Instruction aload_1() {
    return new ALOAD(1);
  }

  @Override
  public Instruction aload_2() {
    return new ALOAD(2);
  }

  @Override
  public Instruction aload_3() {
    return new ALOAD(3);
  }
  
  @Override
  public Instruction astore(int localVarIndex) {  	
  	return new ASTORE_SSA(localVarIndex);
  }
  
  @Override
  public Instruction astore_0() {
  	return astore(0);
  }
  
  @Override
  public Instruction astore_1() {
  	return astore(1);
  }
  
  @Override
  public Instruction astore_2() {
  	return astore(2);
  }
  
  @Override
  public Instruction astore_3() {
  	return astore(3);
  }
  
  @Override
	public Instruction putfield(String fieldName, String clsName, String fieldDescriptor) {		
		return new PUTFIELD_SSA(fieldName, clsName, fieldDescriptor);
	}
	@Override
	public Instruction putstatic(String fieldName, String clsName, String fieldDescriptor) {
		return new PUTSTATIC_SSA(fieldName, clsName, fieldDescriptor);
	}

	@Override
	public Instruction getfield(String fieldName, String clsName, String fieldDescriptor) {
		return new GETFIELD(fieldName, clsName, fieldDescriptor);
	}
	
	@Override
	public Instruction getstatic(String fieldName, String clsName, String fieldDescriptor) {
		return new GETSTATIC(fieldName, clsName, fieldDescriptor);
	}
	
	@Override
	public Instruction invokevirtual(String clsName, String methodName, String methodSignature) {
		return new INVOKEVIRTUAL(clsName, methodName, methodSignature);
	}
	
	@Override
	public Instruction invokeinterface(String clsName, String methodName, String methodSignature) {
		return new INVOKEINTERFACE(clsName, methodName, methodSignature);
	}
	
	@Override
	public Instruction aaload() {		
		return new AALOAD();
	}
	
	@Override
	public Instruction aastore() {
		return new AASTORE();
	}
	
	@Override
	public Instruction faload() {		
		return new FALOAD();
	}
	
	@Override
	public Instruction fastore() {
		return new FASTORE();
	}
	
	@Override
	public Instruction baload() {		
		return new BALOAD();
	}
	
	@Override
	public Instruction bastore() {
		return new BASTORE();
	}
	
	@Override
	public Instruction daload() {		
		return new DALOAD();
	}
	
	@Override
	public Instruction dastore() {
		return new DASTORE();
	}
	
	@Override
	public Instruction laload() {		
		return new DALOAD();
	}
	
	@Override
	public Instruction lastore() {
		return new LASTORE();
	}
	
	@Override
	public Instruction castore() {
		return new CASTORE();
	}
	
	@Override
	public Instruction caload() {
		return new CALOAD();
	}
	
	@Override
	public Instruction iaload() {
		return new IALOAD();
	}
	
	@Override
	public Instruction iastore() {
		return new IASTORE();
	}
	
	//Load instructions
	@Override
  public Instruction iload(int localVarIndex) {
    return new ILOAD(localVarIndex);
  }

  @Override
  public Instruction iload_0() {
    return new ILOAD(0);
  }

  @Override
  public Instruction iload_1() {
    return new ILOAD(1);
  }

  @Override
  public Instruction iload_2() {
    return new ILOAD(2);
  }

  @Override
  public Instruction iload_3() {
    return new ILOAD(3);
  }
  
  @Override
  public Instruction fload(int localVarIndex) {
    return new FLOAD(localVarIndex);
  }

  @Override
  public Instruction fload_0() {
    return new FLOAD(0);
  }

  @Override
  public Instruction fload_1() {
    return new FLOAD(1);
  }

  @Override
  public Instruction fload_2() {
    return new FLOAD(2);
  }

  @Override
  public Instruction fload_3() {
    return new FLOAD(3);
  }
}
