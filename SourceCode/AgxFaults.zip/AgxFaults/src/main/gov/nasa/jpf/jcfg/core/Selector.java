package gov.nasa.jpf.jcfg.core;

public interface Selector<TSource, TResult> {
  TResult select(final TSource source);
}