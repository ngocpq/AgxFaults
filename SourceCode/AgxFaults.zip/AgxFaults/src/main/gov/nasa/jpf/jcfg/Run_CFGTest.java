package gov.nasa.jpf.jcfg;
import gov.nasa.jpf.tool.RunJPF;

public class Run_CFGTest {
	public static void main(String[] args) {
		//String[] paras = new String[]{"E:\\Workspace\\AutomatedDebugging\\jpf-staticanalysis\\src\\examples\\ffl\\tritype\\test_checkTriangle.jpf"};
		String[] paras = new String[]{"E:\\Workspace\\AutomatedDebugging\\jpf-staticanalysis\\src\\examples\\ffl\\tritype\\test_throw.jpf"};
		RunJPF.main(paras);
	}
}
