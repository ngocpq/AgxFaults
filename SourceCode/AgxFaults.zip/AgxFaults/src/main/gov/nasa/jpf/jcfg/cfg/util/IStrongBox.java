package gov.nasa.jpf.jcfg.cfg.util;

public interface IStrongBox {
    Object get();
    void set(final Object value);
}
