package gov.nasa.jpf.jfaults.bytecode.assignment;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.jcfg.variable.LocalVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public class FSTORE extends gov.nasa.jpf.jvm.bytecode.FSTORE {

	public FSTORE(int localVarIndex) {
		super(localVarIndex);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Instruction execute (ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
			return super.execute(ti);
		StackFrame sf = ti.getModifiableTopFrame();
		LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getModifiableVariableStaticInfo(this);
		
		Expression symbVal = ConcolicUtil.peekAttr(sf, 0, varStaticInfo.getType(), Expression.class);
		if (varStaticInfo.isUnknowType()&&symbVal!=null)
			varStaticInfo.setType(symbVal.getType());
		
		Type<?> type = varStaticInfo.getType();
		
		analysis.analyzePrimaryLocalVarAssignmentExpr(ti, sf, this, type);
		
		MemoryPerturbator<?> perturbator = new StackLocalVariablePerturbator(sf, varStaticInfo);				
		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, defAtt, LastModifiedLocationAttribute.class);
		
		return super.execute(ti);
	}
	
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public Instruction execute (ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return super.execute(ti);
//		StackFrame sf = ti.getModifiableTopFrame();
//		
//		//get value guard constraint of operands
//		LastModifiedLocationAttribute opDefAtt = sf.getOperandAttr(LastModifiedLocationAttribute.class);
//		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(this,analysis);
//		LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getModifiableVariableStaticInfo(this);
//		
//		Expression symbVal = sf.getOperandAttr(Expression.class);
//		if (varStaticInfo.isUnknowType()&&symbVal!=null)
//			varStaticInfo.setType(symbVal.getType());
//		
//		Pair val = ConcolicUtil.peek(sf, varStaticInfo.getType());		
//		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
//			String varUniqueId = "@PHI@"+varStaticInfo.getVarUniqueId();
//			val = analysis.getOrCreateSummaryVariablePair(this, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);			
//		}
//		
//		Pair updatedAttr = val;
//		if (analysis.isSuspiciousScope(this)){			
//			String varUniqueId = varStaticInfo.getVarUniqueId();
//			updatedAttr = analysis.getOrCreateAngelicVariable(this,varUniqueId, ti, sf, val.symb, val.conc);
//			//perturb stack operand
//			ConcolicUtil.perturbOperand(sf, 0, updatedAttr);
//		}
//		
//		MemoryPerturbator<?> perturbator = new StackLocalVariablePerturbator(sf, varStaticInfo);				
//		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, val.symb.getType(), defAtt, LastModifiedLocationAttribute.class);
//		
//		return super.execute(ti);
//	}
}
