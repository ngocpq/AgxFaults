package gov.nasa.jpf.jcfg.cfg;

public enum ControlFlowNodeType {
  Normal,
  EntryPoint,
  RegularExit,
  ExceptionalExit,
  CatchHandler,
  FinallyHandler,
  EndFinally
}
