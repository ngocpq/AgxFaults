/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 * 
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */
package gov.nasa.jpf.jfaults.bytecode.assignment;

import java.util.ArrayList;
import java.util.List;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.expressions.CastExpression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.NumericCompound;
import gov.nasa.jpf.constraints.expressions.NumericOperator;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.util.ExpressionUtil;
import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jcfg.utils.InstructionUtil;
import gov.nasa.jpf.jcfg.variable.LocalVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.MemoryModifiableInstruction;
import gov.nasa.jpf.jcfg.variable.MemoryPerturbatorFactory;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicInstructionFactory;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.LocalVarInfo;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;

public class IINC_SSA extends gov.nasa.jpf.jvm.bytecode.IINC implements MemoryModifiableInstruction{
	private final Constant<Integer> symbolicInc;

	public IINC_SSA(int localVarIndex, int incConstant) {
		super(localVarIndex, incConstant);
		this.symbolicInc = Constant.create(BuiltinTypes.SINT32, incConstant);
	}
	
	/*StackFrame frame = ti.getModifiableTopFrame();

    int v = frame.getLocalVariable(index);
    v += increment;

    frame.setLocalVariable(index, v, false);

    return getNext(ti);
	 */
	@SuppressWarnings("unchecked")
	@Override
  public Instruction execute(ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
			return super.execute(ti);
		
		StackFrame sf = ti.getModifiableTopFrame();
		
		Pair<Integer> val = ConcolicUtil.getLocalSymbolicAttrInt(sf, index);
		
		LastModifiedLocationAttribute defAtt = sf.getLocalAttr(index,LastModifiedLocationAttribute.class);
		Expression<Boolean> guardConstraint = defAtt.getModifiedGualdConstraints(this,analysis);		
		LocalVariableStaticInfo<?> varStaticInfo = (LocalVariableStaticInfo<?>) VariableStaticInfo.getVariableStaticInfo(this);
		
		Expression<Integer> symbVal = val.symb;
		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
			String varUniqueId = "@PHI@"+InstructionUtil.getUniqueIdString(this);
			symbVal = analysis.getOrCreateSummaryVariable(this, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);
		}
		
		int concVal = val.conc+increment;	
		if (symbVal == null || !ExpressionUtil.containsVars(symbVal))
			symbVal = Constant.create(BuiltinTypes.SINT32, concVal);
    else 
    	symbVal = NumericCompound.create(symbVal.requireAs(BuiltinTypes.SINT32),NumericOperator.PLUS,symbolicInc);				
		
		if (analysis.isSuspiciousScope(this)){
			//make angelic symbolic variable
			String varUniqueId = varStaticInfo.getVarUniqueId();
			Pair<Integer> updatedAttr = analysis.getOrCreateAngelicVariable(this,varUniqueId, ti, sf, symbVal, concVal);
			concVal = updatedAttr.conc;
			symbVal = updatedAttr.symb;
		}
		
		//verify
		Integer expectedValue = analysis.getAngelicValueOfExpression(symbVal);
		if (expectedValue.equals(concVal)){
			ConcolicInstructionFactory.logger.info("Warning: IINC evaluated value of symbVal is different to actual concrete value");
			//ContractUtils.unreachable("expectedValue value is different to actual concrete value");
		}
		
		sf.setLocalVariable(index, concVal);
		if (symbVal!=null && !ExpressionUtil.containsVars(symbVal))
			symbVal = null; //concrete value		
		ConcolicUtil.setOrReplaceLocalAttrInt(sf, index, symbVal, Expression.class);
		
		StackLocalVariablePerturbator<?> perturbator = new StackLocalVariablePerturbator<>(sf, varStaticInfo);		
    LastModifiedLocationAttribute attr = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(),perturbator);
    ConcolicUtil.setOrReplaceLocalAttrInt(sf, index, attr, LastModifiedLocationAttribute.class);
    
    if (ConcolicInstructionFactory.DEBUG) {
      ConcolicInstructionFactory.logger.finest("IINC " + sf.getLocalAttr(index));
    }

    return getNext(ti);
  }

	public VariableStaticInfo getVariableStaticInfor() {
		MethodInfo mInfo = this.getMethodInfo();
		LocalVarInfo varInfo = mInfo.getLocalVar(this.index, this.getPosition());
		if (varInfo!=null)
			return new LocalVariableStaticInfo(mInfo, varInfo);				
		String varName = "null_"+this.index;			
		byte typeCode = Types.T_INT;
		return new LocalVariableStaticInfo<Integer>(mInfo,varName,this.index,typeCode,false);	
	}	
	
	public <T> List<T> getOperandAttribute(ThreadInfo ti, StackFrame sf, Class<T> attrClazz) {
		List<T> lst = new ArrayList();
		lst.add(sf.getOperandAttr(attrClazz));
		return lst;
	}
}
