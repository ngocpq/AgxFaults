package gov.nasa.jpf.jcfg;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import gov.nasa.jpf.JPF;
import gov.nasa.jpf.jcfg.cfg.ControlFlowGraph;
import gov.nasa.jpf.jcfg.cfg.ControlFlowGraphBuilder;
import gov.nasa.jpf.jcfg.cfg.ControlFlowNode;
import gov.nasa.jpf.jcfg.cfg.OpCode;
import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jcfg.utils.DebugUtility;
import gov.nasa.jpf.jcfg.utils.LoggerUtil;
import gov.nasa.jpf.jcfg.utils.SimpleProfiler;
import gov.nasa.jpf.jvm.bytecode.ArrayStoreInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMLocalVariableInstruction;
import gov.nasa.jpf.util.FileUtility;
import gov.nasa.jpf.util.JPFLogger;
import gov.nasa.jpf.vm.InfoObject;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.bytecode.StoreInstruction;
import gov.nasa.jpf.vm.bytecode.WriteInstruction;

public class StaticAnalysisUtility {
	public static JPFLogger logger = LoggerUtil.getCFGLogger();
	
	public static ControlFlowGraph getControlFlowGraph(MethodInfo mi){
		ControlFlowGraph cfg = mi.getAttr(ControlFlowGraph.class);
		if (cfg==null){
			
			SimpleProfiler.start("build-cfg");
			if (DebugUtility.isDebugCfgEnabled())
				logger.finer("cfg of method: "+mi);
			cfg = ControlFlowGraphBuilder.build(mi);
			cfg.computeDominance();
			cfg.computeDominanceFrontier();
			
			cfg.computePostDominance();
			cfg.computePostDominanceFrontier();
			
			cfg.computePostDominanceExceptionalExit();
			
			cfg.computeModifiableVariable();
			
			cfg.computeModifiableVariableInBranches();						
			
			cfg.computeJoinVariable();
			
			
			//add cfg into MethodInfo attribute
			mi.addAttr(cfg);			
			
			//analysis modified variables in nodes:
			for(ControlFlowNode node:cfg.getNodes()){
				for(Instruction insn:node.getInstructions()){
					// add ControlFlowNode attribute for instruction
					if (insn.hasAttr(ControlFlowNode.class))
						throw ContractUtils.unreachable("Instruction already had attribute ControlFlowNode");
					insn.addAttr(node);					
				}
			}
			if (DebugUtility.isDebugCfgEnabled()){				
				String dir = System.getProperty("java.io.tmpdir")+"agxFaults"+File.separator+"cfg";
				FileUtility.assureDirExist(dir);
				String fileName = mi.getFullName().replace("/",".").replace("<", "_").replace(">", "_");
				String filePath = dir+File.separator+fileName+"_dominanceFrontier.dot";
				File file = new File(filePath);
				cfg.export(file );
			}
			
			SimpleProfiler.stop("build-cfg");
	    }		
		return cfg;
	}
		
	
	
	public static void determinePhiPlacementLocations(ControlFlowGraph cfg){
		//cfg.getEntryPoint().getD
		//find domination front
//		cfg.com
//		for(ControlFlowNode node:cfg.getNodes()){
//			node.getDominanceFrontier().
//		}
	}
}
