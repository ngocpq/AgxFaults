/*
 * ControlFlowGraphBuilder.java
 *
 * Copyright (c) 2013 Mike Strobel
 *
 * This source code is based on Mono.Cecil from Jb Evain, Copyright (c) Jb Evain;
 * and ILSpy/ICSharpCode from SharpDevelop, Copyright (c) AlphaSierraPapa.
 *
 * This source code is subject to terms and conditions of the Apache License, Version 2.0.
 * A copy of the license can be found in the License.html file at the root of this distribution.
 * By using this source code in any fashion, you are agreeing to be bound by the terms of the
 * Apache License, Version 2.0.
 *
 * You must not remove this notice, or any other, from this software.
 */

package gov.nasa.jpf.jcfg.cfg;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import gov.nasa.jpf.jcfg.cfg.util.ArrayUtilities;
import gov.nasa.jpf.jcfg.cfg.wrap.ExceptionHandlerMapper;
import gov.nasa.jpf.jcfg.cfg.wrap.ExceptionHandlerType;
import gov.nasa.jpf.jcfg.cfg.wrap.ExceptionHandlerWrapper;
import gov.nasa.jpf.jcfg.core.Comparer;
import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jcfg.utils.CollectionUtilities;
import gov.nasa.jpf.jvm.bytecode.GOTO;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.jvm.bytecode.JSR;
import gov.nasa.jpf.jvm.bytecode.JSR_W;
import gov.nasa.jpf.jvm.bytecode.SwitchInstruction;
import gov.nasa.jpf.util.Predicate;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.MethodInfo;

public final class ControlFlowGraphBuilder{
	
	public static ControlFlowGraph build(final MethodInfo methodBody) {
		List<Instruction> insntructions = ArrayUtilities.toList(methodBody.getInstructions()); 
		
		List<ExceptionHandlerWrapper> exceptionHandlers = ExceptionHandlerMapper.getExceptionHandlerWrappers(methodBody);
		final ControlFlowGraphBuilder builder = new ControlFlowGraphBuilder(insntructions,exceptionHandlers);
		return builder.build();
	}

	public static ControlFlowGraph build(final List<Instruction> instructions, final List<ExceptionHandlerWrapper> exceptionHandlers) {
		final ControlFlowGraphBuilder builder = new ControlFlowGraphBuilder(instructions, exceptionHandlers);

		return builder.build();
	}

	private final List<Instruction> _instructions;
	private final List<ExceptionHandlerWrapper> _exceptionHandlers;
	private final List<ControlFlowNode> _nodes = new ArrayList<>();
	private final int[] _offsets;
	private final boolean[] _hasIncomingJumps;
	private final ControlFlowNode _entryPoint;
	private final ControlFlowNode _regularExit;
	private final ControlFlowNode _exceptionalExit;

	private int _nextBlockId;
	boolean copyFinallyBlocks = false;

	private ControlFlowGraphBuilder(final List<Instruction> instructions, final List<ExceptionHandlerWrapper> exceptionHandlers) {
		_instructions = VerifyArgument.notNull(instructions, "instructions");
		_exceptionHandlers = coalesceExceptionHandlers(VerifyArgument.notNull(exceptionHandlers, "exceptionHandlers"));

		_offsets = new int[instructions.size()];
		_hasIncomingJumps = new boolean[_offsets.length];

		for (int i = 0; i < instructions.size(); i++) {
			_offsets[i] = instructions.get(i).getPosition();
		}

		_entryPoint = new ControlFlowNode(_nextBlockId++, 0, ControlFlowNodeType.EntryPoint);
		_regularExit = new ControlFlowNode(_nextBlockId++, -1, ControlFlowNodeType.RegularExit);
		_exceptionalExit = new ControlFlowNode(_nextBlockId++, -1, ControlFlowNodeType.ExceptionalExit);

		_nodes.add(_entryPoint);
		_nodes.add(_regularExit);
		_nodes.add(_exceptionalExit);
	}

	public final ControlFlowGraph build() {
		calculateIncomingJumps();
		createNodes();
		createRegularControlFlow();
		createExceptionalControlFlow();

		if (copyFinallyBlocks) {
			copyFinallyBlocksIntoLeaveEdges();
		} else {
			transformLeaveEdges();
		}

		return new ControlFlowGraph(_nodes.toArray(new ControlFlowNode[_nodes.size()]));
	}

	private void calculateIncomingJumps() {
		//
		// Step 1: Determine which instructions are jump targets.
		//

		for (final Instruction instruction : _instructions) {
			final OpCode opCode = OpCode.get(instruction.getByteCode());

			if (opCode.getOperandType() == OperandType.BranchTarget
					|| opCode.getOperandType() == OperandType.BranchTargetWide) {
				if (instruction instanceof IfInstruction)
					_hasIncomingJumps[getInstructionIndex(((IfInstruction) instruction).getTarget())] = true;
				else if (instruction instanceof GOTO)
					_hasIncomingJumps[getInstructionIndex(((GOTO) instruction).getTarget())] = true;				
			} else if (opCode.getOperandType() == OperandType.Switch) {
				if (instruction instanceof SwitchInstruction) {
					SwitchInstruction switchInfo = (SwitchInstruction) instruction;
					// final SwitchInfo switchInfo = instruction.getOperand(0);

					_hasIncomingJumps[getInstructionIndex(switchInfo.getTarget())] = true;

					for (final int targetPos : switchInfo.getTargets()) {
						_hasIncomingJumps[getInstructionIndex(targetPos)] = true;
					}
				}
			}
		}

		for (final ExceptionHandlerWrapper handler : _exceptionHandlers) {
			_hasIncomingJumps[getInstructionIndex(handler.getHandlerBlock().getFirstInstruction())] = true;
		}
	}

	private void createNodes() {
		//
		// Step 2a: Find basic blocks and create nodes for them.
		//

		final List<Instruction> instructions = _instructions;

		for (int i = 0, n = instructions.size(); i < n; i++) {
			final Instruction blockStart = instructions.get(i);
			final ExceptionHandlerWrapper blockStartExceptionHandler = findInnermostExceptionHandler(blockStart.getPosition());

			//
			// See how big we can make that block...
			//
			for (; i + 1 < n; i++) {
				final Instruction instruction = instructions.get(i);
				final OpCode opCode = OpCode.get(instruction.getByteCode());

				if (opCode.isBranch() || opCode.canThrow() || _hasIncomingJumps[i + 1]) {
					break;
				}

				final Instruction next = instruction.getNext();

				if (next != null) {
					//
					// Ensure that blocks never contain instructions from
					// different try blocks.
					//
					final ExceptionHandlerWrapper innermostExceptionHandler = findInnermostExceptionHandler(next.getPosition());

					if (innermostExceptionHandler != blockStartExceptionHandler) {
						break;
					}
				}
			}

			_nodes.add(new ControlFlowNode(_nodes.size(), blockStart, instructions.get(i)));
		}

		//
		// Step 2b: Create special nodes for exception handling constructs.
		//

		for (final ExceptionHandlerWrapper handler : _exceptionHandlers) {
			final int index = _nodes.size();
            final ControlFlowNode endFinallyNode;

            if (handler.getHandlerType() == ExceptionHandlerType.Finally) {
                endFinallyNode = new ControlFlowNode(
                    index,
                    //handler.getHandlerBlock().getLastInstruction().getEndOffset(),
                    handler.getHandlerBlock().getLastInstruction().getPosition()+handler.getHandlerBlock().getLastInstruction().getLength(),
                    ControlFlowNodeType.EndFinally
                );
            }
            else {
                endFinallyNode = null;
            }

            _nodes.add(new ControlFlowNode(index, handler, endFinallyNode));
        }
	}

	private void createRegularControlFlow() {
		//
		// Step 3: Create edges for the normal control flow (assuming no
		// exceptions thrown).
		//

		final List<Instruction> instructions = _instructions;

		createEdge(_entryPoint, instructions.get(0), JumpType.Normal);

		for (final ControlFlowNode node : _nodes) {
			final Instruction end = node.getEnd();
			Instruction lastInsn = _instructions.get(_instructions.size() - 1);
			int lastOfset = lastInsn.getPosition() + lastInsn.getLength();
			if (end == null || end.getPosition() >= lastOfset) {
				continue;
			}

			final OpCode endOpCode = OpCode.get(end.getByteCode());
			//
			// Create normal edges from one instruction to the next.
			//
			if (!endOpCode.isUnconditionalBranch() || endOpCode.isJumpToSubroutine()) {
				final Instruction next = end.getNext();						
				if (next != null) {
					final boolean isHandlerStart = CollectionUtilities.any(
	                        _exceptionHandlers,
	                        new Predicate<ExceptionHandlerWrapper>() {
	                            @Override
	                            public boolean isTrue(final ExceptionHandlerWrapper handler) {
	                                return handler.getHandlerBlock().getFirstInstruction() == next;
	                            }
	                        }
	                    );
					
					if (!isHandlerStart) {
						createEdge(node, next, JumpType.Normal);
					}
				}
			}

			//
			// Create edges for branch instructions.
			//
			for (Instruction instruction = node.getStart(); instruction != null
					&& instruction.getPosition() <= end.getPosition(); instruction = instruction.getNext()) {

				final OpCode opCode = OpCode.get(instruction.getByteCode());

				if (opCode.getOperandType() == OperandType.BranchTarget
						|| opCode.getOperandType() == OperandType.BranchTargetWide) {
					Instruction target = getTargetInstruction(instruction);
					createBranchControlFlow(node, instruction, target);
				} else if (opCode.getOperandType() == OperandType.Switch) {
					final SwitchInstruction switchInfo = (SwitchInstruction) instruction;
					createEdge(node, getInstruction(switchInfo.getTarget()), JumpType.Normal);

					for (final int target : switchInfo.getTargets()) {
						createEdge(node, getInstruction(target), JumpType.Normal);
					}
				}
			}

			//
			// Create edges for return and leave instructions.
			//
			if (endOpCode == OpCode.ENDFINALLY) {
				final ControlFlowNode handlerBlock = findInnermostFinallyBlock(end.getPosition());

				if (handlerBlock.getEndFinallyNode() != null) {
					createEdge(node, handlerBlock.getEndFinallyNode(), JumpType.Normal);
				}
			} else if (endOpCode == OpCode.LEAVE) {
				ControlFlowNode handlerBlock = findInnermostHandlerBlock(end.getPosition());

				if (handlerBlock != _exceptionalExit) {
					if (handlerBlock.getEndFinallyNode() == null) {
                        handlerBlock = findInnermostFinallyHandlerNode(
                            handlerBlock.getExceptionHandler().getTryBlock().getLastInstruction().getPosition()
                        );
                    }

                    if (handlerBlock.getEndFinallyNode() != null) {
                        createEdge(node, handlerBlock.getEndFinallyNode(), JumpType.LeaveTry);
                    }
				}
			} else if (endOpCode.isReturn()) {
				createReturnControlFlow(node, end);
			}
		}
	}

	private Instruction getTargetInstruction(Instruction instruction) {
		if (instruction instanceof IfInstruction)
			return ((IfInstruction) instruction).getTarget();
		if (instruction instanceof GOTO)
			return ((GOTO) instruction).getTarget();		
		if (instruction instanceof JSR)
			return getInstruction( ((JSR) instruction).getTarget());
		if (instruction instanceof JSR_W)
			return getInstruction( ((JSR_W) instruction).getTarget());
		
		throw ContractUtils.unreachable();
	}

	private void createExceptionalControlFlow() {
		//
		// Step 4: Create edges for the exceptional control flow.
		//

		for (final ControlFlowNode node : _nodes) {
			final Instruction end = node.getEnd();

			if (end != null && end.getPosition() < (_instructions.get(_instructions.size() - 1).getPosition()+_instructions.get(_instructions.size() - 1).getLength())
					&& OpCode.get(end.getByteCode()).canThrow()) {				

				final ControlFlowNode innermostHandler = findInnermostExceptionHandlerNode(node.getEnd().getPosition());

				if (innermostHandler == _exceptionalExit) {
					final ControlFlowNode handlerBlock = findInnermostHandlerBlock(node.getEnd().getPosition());

					ControlFlowNode finallyBlock;

					if (handlerBlock.getExceptionHandler() != null) {
						finallyBlock = findInnermostFinallyHandlerNode(
								handlerBlock.getExceptionHandler().getTryBlock().getLastInstruction().getPosition());

						if (finallyBlock.getNodeType() == ControlFlowNodeType.FinallyHandler
								&& finallyBlock.getExceptionHandler().getHandlerBlock().contains(end)) {

							finallyBlock = _exceptionalExit;
						}
					} else {
						finallyBlock = _exceptionalExit;
					}

					createEdge(node, finallyBlock, JumpType.JumpToExceptionHandler);
				} else {
					for (final ExceptionHandlerWrapper handler : _exceptionHandlers) {
						if (Comparer.equals(handler.getTryBlock(),
								innermostHandler.getExceptionHandler().getTryBlock())) {
							final ControlFlowNode handlerNode = CollectionUtilities.firstOrDefault(_nodes,
									new Predicate<ControlFlowNode>() {
										@Override
										public boolean isTrue(final ControlFlowNode node) {
											return node.getExceptionHandler() == handler;
										}
									});

							createEdge(node, handlerNode, JumpType.JumpToExceptionHandler);
						}
					}

					//
					// If we're in a catch block, and we have an adjacent
					// finally block, jump to it.
					//

					final ControlFlowNode handlerBlock = findInnermostHandlerBlock(node.getEnd().getPosition());

					if (handlerBlock != innermostHandler
							&& handlerBlock.getNodeType() == ControlFlowNodeType.CatchHandler) {

						final ControlFlowNode finallyBlock = findInnermostFinallyHandlerNode(
								handlerBlock.getExceptionHandler().getTryBlock().getLastInstruction().getPosition());

						if (finallyBlock.getNodeType() == ControlFlowNodeType.FinallyHandler) {
							createEdge(node, finallyBlock, JumpType.JumpToExceptionHandler);
						}
					}
				}
			}

			final ExceptionHandlerWrapper exceptionHandler = node.getExceptionHandler();

			if (exceptionHandler != null) {
				if (exceptionHandler.isFinally()) {
					final ControlFlowNode handlerBlock = findInnermostFinallyHandlerNode(
							exceptionHandler.getHandlerBlock().getLastInstruction().getPosition());

					if (handlerBlock.getNodeType() == ControlFlowNodeType.FinallyHandler && handlerBlock != node) {
						createEdge(node, handlerBlock, JumpType.JumpToExceptionHandler);
					}
				} else {
					final ControlFlowNode adjacentFinally = findInnermostFinallyHandlerNode(
							exceptionHandler.getTryBlock().getLastInstruction().getPosition());

					createEdge(node, adjacentFinally != null ? adjacentFinally : findParentExceptionHandlerNode(node),
							JumpType.JumpToExceptionHandler);
				}

				createEdge(node, exceptionHandler.getHandlerBlock().getFirstInstruction(), JumpType.Normal);
			}
		}
	}

	private void createBranchControlFlow(final ControlFlowNode node, final Instruction jump, final Instruction target) {
		final ControlFlowNode handlerNode = findInnermostHandlerBlock(jump.getPosition());
		final ControlFlowNode outerFinally = findInnermostHandlerBlock(jump.getPosition(), true);
		final ControlFlowNode targetHandlerNode = findInnermostHandlerBlock(target.getPosition());
		final ExceptionHandlerWrapper handler = handlerNode.getExceptionHandler();

		if (OpCode.get(jump.getByteCode()).isJumpToSubroutine() || targetHandlerNode == handlerNode
				|| (handler != null && (handler.getTryBlock().contains(jump) ? handler.getTryBlock().contains(target)
						: handler.getHandlerBlock().contains(target)))) {
			//
			// A jump within a handler is normal control flow.
			//
			createEdge(node, target, JumpType.Normal);
			return;
		}

		if (handlerNode.getNodeType() == ControlFlowNodeType.CatchHandler) {
			//
			// First look for an immediately adjacent finally handler.
			//
			ControlFlowNode finallyHandlerNode = findInnermostFinallyHandlerNode(
					handler.getTryBlock().getLastInstruction().getPosition());

			final ExceptionHandlerWrapper finallyHandler = finallyHandlerNode.getExceptionHandler();
			final ExceptionHandlerWrapper outerFinallyHandler = outerFinally.getExceptionHandler();

			if (finallyHandlerNode.getNodeType() != ControlFlowNodeType.FinallyHandler
					|| (outerFinally.getNodeType() == ControlFlowNodeType.FinallyHandler
							&& finallyHandler.getTryBlock().contains(outerFinallyHandler.getHandlerBlock()))) {

				//
				// We don't have an adjacent finally handler, or our containing
				// finally handler is
				// protected by the adjacent finally handler's try block. Use
				// the containing finally.
				//
				finallyHandlerNode = outerFinally;
			}

			if (finallyHandlerNode.getNodeType() == ControlFlowNodeType.FinallyHandler
					&& finallyHandlerNode != targetHandlerNode) {

				//
				// We are jumping out of a try or catch block by way of a
				// finally block.
				//
				createEdge(node, target, JumpType.LeaveTry);
			} else {
				//
				// We are performing a regular jumping out of a try or catch
				// block.
				//
				createEdge(node, target, JumpType.Normal);
			}

			return;
		}

		if (handlerNode.getNodeType() == ControlFlowNodeType.FinallyHandler) {
			if (handler.getTryBlock().contains(jump)) {
				//
				// We are jumping out of a try block by way of a finally block.
				//

				createEdge(node, target, JumpType.LeaveTry);
			} else {
				ControlFlowNode parentHandler = findParentExceptionHandlerNode(handlerNode);

				while (parentHandler != handlerNode
						&& parentHandler.getNodeType() == ControlFlowNodeType.CatchHandler) {

					parentHandler = findParentExceptionHandlerNode(parentHandler);
				}

				if (parentHandler.getNodeType() == ControlFlowNodeType.FinallyHandler
						&& !(parentHandler.getExceptionHandler()).getTryBlock()
								.contains(target)) {

					createEdge(node, target, JumpType.LeaveTry);
				} else {
					//
					// We are jumping out of a finally block.
					//
					createEdge(node, handlerNode.getEndFinallyNode(), JumpType.Normal);
					createEdge(handlerNode.getEndFinallyNode(), target, JumpType.Normal);
				}
			}

			return;
		}

		//
		// Last case is regular control flow.
		//
		createEdge(node, target, JumpType.Normal);
	}

	@SuppressWarnings("UnusedParameters")
	private void createReturnControlFlow(final ControlFlowNode node, final Instruction end) {
		// final ControlFlowNode handlerNode =
		// findInnermostHandlerBlock(end.getPosition());
		// final ControlFlowNode finallyNode;
		//
		// if (handlerNode.getNodeType() == ControlFlowNodeType.CatchHandler) {
		// finallyNode = findInnermostFinallyHandlerNode(
		// handlerNode.getExceptionHandler().getTryBlock().getLastInstruction().getPosition()
		// );
		// }
		// else if (handlerNode.getNodeType() ==
		// ControlFlowNodeType.FinallyHandler) {
		// finallyNode = handlerNode;
		// }
		// else {
		// finallyNode = _exceptionalExit;
		// }
		//
		// if (finallyNode.getNodeType() == ControlFlowNodeType.FinallyHandler)
		// {
		// createEdge(node, _regularExit, JumpType.LeaveTry);
		// }
		// else {
		createEdge(node, _regularExit, JumpType.Normal);
		// }
	}

	private void transformLeaveEdges() {
		//
		// Step 5: Replace LeaveTry edges with EndFinally edges.
		//

		for (int n = _nodes.size(), i = n - 1; i >= 0; i--) {
			final ControlFlowNode node = _nodes.get(i);
			final Instruction end = node.getEnd();

			if (end != null && !node.getOutgoing().isEmpty()) {
				for (final ControlFlowEdge edge : node.getOutgoing()) {
					if (edge.getType() == JumpType.LeaveTry) {
						assert OpCode.get(end.getByteCode()).isBranch();

						final ControlFlowNode handlerBlock = findInnermostHandlerBlock(end.getPosition());
						ControlFlowNode finallyBlock = findInnermostFinallyHandlerNode(end.getPosition());

						if (handlerBlock != finallyBlock) {
							final ExceptionHandlerWrapper handler = handlerBlock.getExceptionHandler();
							final ControlFlowNode adjacentFinally = findInnermostFinallyHandlerNode(
									handler.getTryBlock().getLastInstruction().getPosition());

							if (finallyBlock.getNodeType() != ControlFlowNodeType.FinallyHandler
									|| finallyBlock != adjacentFinally) {
								finallyBlock = adjacentFinally;
							}
						}

						final ControlFlowNode target = edge.getTarget();

						target.getIncoming().remove(edge);
						node.getOutgoing().remove(edge);

						if (finallyBlock.getNodeType() == ControlFlowNodeType.ExceptionalExit) {
							createEdge(node, finallyBlock, JumpType.Normal);
							continue;
						}

						assert finallyBlock.getNodeType() == ControlFlowNodeType.FinallyHandler;

						Instruction targetAddress = target.getStart();

						if (targetAddress == null && target.getExceptionHandler() != null) {
							targetAddress = target.getExceptionHandler().getHandlerBlock().getFirstInstruction();
						}

						if (finallyBlock.getExceptionHandler().getHandlerBlock().contains(end)) {
							createEdge(node, finallyBlock.getEndFinallyNode(), JumpType.Normal);
						} else {
							createEdge(node, finallyBlock, JumpType.Normal);
						}

						if (targetAddress != null) {
							while (true) {
								ControlFlowNode parentHandler = findParentExceptionHandlerNode(finallyBlock);

								while (parentHandler.getNodeType() == ControlFlowNodeType.CatchHandler
										&& !parentHandler.getExceptionHandler().getTryBlock().contains(targetAddress)) {

									parentHandler = findInnermostFinallyHandlerNode(parentHandler.getExceptionHandler()
													.getTryBlock().getLastInstruction().getPosition());

									if (parentHandler == finallyBlock) {
										parentHandler = findParentExceptionHandlerNode(finallyBlock);
									}
								}

								if (parentHandler.getNodeType() != ControlFlowNodeType.FinallyHandler
										|| parentHandler.getExceptionHandler().getTryBlock().contains(targetAddress)) {

									break;
								}

								createEdge(finallyBlock.getEndFinallyNode(), parentHandler, JumpType.EndFinally);

								finallyBlock = parentHandler;
							}
						}

						if (finallyBlock != target) {
							createEdge(finallyBlock.getEndFinallyNode(), target, JumpType.EndFinally);

							createEdge(
									findNode(finallyBlock.getExceptionHandler().getHandlerBlock().getLastInstruction()),
									finallyBlock.getEndFinallyNode(), JumpType.Normal);
						}
					}
				}
			}
		}
	}

	private void copyFinallyBlocksIntoLeaveEdges() {
		//
		// Step 5b: Copy finally blocks into the LeaveTry edges.
		//

		for (int n = _nodes.size(), i = n - 1; i >= 0; i--) {
			final ControlFlowNode node = _nodes.get(i);
			final Instruction end = node.getEnd();

			if (end != null && node.getOutgoing().size() == 1
					&& node.getOutgoing().get(0).getType() == JumpType.LeaveTry) {

				assert OpCode.get(end.getByteCode()) == OpCode.GOTO || OpCode.get(end.getByteCode()) == OpCode.GOTO_W;

				final ControlFlowEdge edge = node.getOutgoing().get(0);
				final ControlFlowNode target = edge.getTarget();

				target.getIncoming().remove(edge);
				node.getOutgoing().clear();

				final ControlFlowNode handler = findInnermostExceptionHandlerNode(end.getPosition() + end.getLength());

				assert handler.getNodeType() == ControlFlowNodeType.FinallyHandler;

				final ControlFlowNode copy = copyFinallySubGraph(handler, handler.getEndFinallyNode(), target);

				createEdge(node, copy, JumpType.Normal);
			}
		}
	}

	private ControlFlowNode copyFinallySubGraph(final ControlFlowNode start, final ControlFlowNode end,
			final ControlFlowNode newEnd) {
		return new CopyFinallySubGraphLogic(start, end, newEnd).copyFinallySubGraph();
	}

	private static boolean isNarrower(final ExceptionHandlerWrapper handler, final ExceptionHandlerWrapper anchor) {
		if (handler == null || anchor == null) {
			return false;
		}

		final Instruction tryStart = handler.getTryBlock().getFirstInstruction();
		final Instruction anchorTryStart = anchor.getTryBlock().getFirstInstruction();

		if (tryStart.getPosition() > anchorTryStart.getPosition()) {
			return true;
		}

		final Instruction tryEnd = handler.getTryBlock().getLastInstruction();
		final Instruction anchorTryEnd = anchor.getTryBlock().getLastInstruction();

		return tryStart.getPosition() == anchorTryStart.getPosition()
				&& tryEnd.getPosition() < anchorTryEnd.getPosition();
	}

	private static boolean isNarrower(final InstructionBlock block, final InstructionBlock anchor) {
		if (block == null || anchor == null) {
			return false;
		}

		final Instruction start = block.getFirstInstruction();
		final Instruction anchorStart = anchor.getFirstInstruction();
		final Instruction end = block.getLastInstruction();
		final Instruction anchorEnd = anchor.getLastInstruction();

		if (start.getPosition() > anchorStart.getPosition()) {
			return end.getPosition() < anchorEnd.getPosition() + anchorEnd.getLength();
		}

		return start.getPosition() == anchorStart.getPosition() && end.getPosition() < anchorEnd.getPosition();
	}

	private ControlFlowNode findParentExceptionHandlerNode(final ControlFlowNode node) {
		assert node.getNodeType() == ControlFlowNodeType.CatchHandler
				|| node.getNodeType() == ControlFlowNodeType.FinallyHandler;

		ControlFlowNode result = null;
		ExceptionHandlerWrapper resultHandler = null;

		final int offset = node.getExceptionHandler().getHandlerBlock()
				.getFirstInstruction().getPosition();

		for (int i = 0, n = _nodes.size(); i < n; i++) {
			final ControlFlowNode currentNode = _nodes.get(i);
			final ExceptionHandlerWrapper handler = currentNode.getExceptionHandler();

			if (handler != null && handler.getTryBlock().getFirstInstruction().getPosition() <= offset
					&& offset < (handler.getTryBlock().getLastInstruction().getPosition()
							+ handler.getTryBlock().getLastInstruction().getLength())
					&& (resultHandler == null || isNarrower(handler, resultHandler))) {

				result = currentNode;
				resultHandler = handler;
			}
		}

		return result != null ? result : _exceptionalExit;
	}

	private ControlFlowNode findInnermostExceptionHandlerNode(final int offset) {
		final ExceptionHandlerWrapper handler = findInnermostExceptionHandler(offset);

		if (handler == null) {
			return _exceptionalExit;
		}

		for (final ControlFlowNode node : _nodes) {
			if (node.getExceptionHandler() == handler && node.getCopyFrom() == null) {
				return node;
			}
		}

		throw new IllegalStateException("Could not find node for exception handler!");
	}

	private ControlFlowNode findInnermostFinallyHandlerNode(final int offset) {
		final ExceptionHandlerWrapper handler = findInnermostFinallyHandler(offset);

		if (handler == null) {
			return _exceptionalExit;
		}

		for (final ControlFlowNode node : _nodes) {
			if (node.getExceptionHandler() == handler && node.getCopyFrom() == null) {
				return node;
			}
		}

		throw new IllegalStateException("Could not find node for exception handler!");
	}

	private int getInstructionIndex(final Instruction instruction) {
		final int index = Arrays.binarySearch(_offsets, instruction.getPosition());
		assert index >= 0;
		return index;
	}

	private Instruction getInstruction(int pos) {
		int index = getInstructionIndex(pos);
		return this._instructions.get(index);
	}

	private int getInstructionIndex(final int pos) {
		final int index = Arrays.binarySearch(_offsets, pos);
		assert index >= 0;
		return index;
	}

	private ControlFlowNode findNode(final Instruction instruction) {
		final int offset = instruction.getPosition();

		for (final ControlFlowNode node : _nodes) {
			if (node.getNodeType() != ControlFlowNodeType.Normal) {
				continue;
			}

			if (offset >= node.getStart().getPosition()
					&& offset < node.getEnd().getPosition() + node.getEnd().getLength()) {

				return node;
			}
		}

		return null;
	}

	private ExceptionHandlerWrapper findInnermostExceptionHandler(final int offsetInTryBlock) {
		ExceptionHandlerWrapper result = null;

		for (final ExceptionHandlerWrapper handler : _exceptionHandlers) {
			final InstructionBlock tryBlock = handler.getTryBlock();

			if (tryBlock.getFirstInstruction().getPosition() <= offsetInTryBlock
					&& offsetInTryBlock < (tryBlock.getLastInstruction().getPosition()
							+ tryBlock.getLastInstruction().getLength())
					&& (result == null || isNarrower(handler, result))) {

				result = handler;
			}
		}
		return result;
	}

	private ExceptionHandlerWrapper findInnermostFinallyHandler(final int offsetInTryBlock) {
		ExceptionHandlerWrapper result = null;

		for (final ExceptionHandlerWrapper handler: _exceptionHandlers) {
			if (!handler.isFinally()) {
				continue;
			}

			final InstructionBlock tryBlock = handler.getTryBlock();

			if (tryBlock.getFirstInstruction().getPosition() <= offsetInTryBlock
					&& offsetInTryBlock < tryBlock.getLastInstruction().getPosition()
							+ tryBlock.getLastInstruction().getLength()
					&& (result == null || isNarrower(handler, result))) {

				result = handler;
			}
		}
		return result;
	}

	private ControlFlowNode findInnermostHandlerBlock(final int instructionOffset) {
		return findInnermostHandlerBlock(instructionOffset, false);
	}

	private ControlFlowNode findInnermostFinallyBlock(final int instructionOffset) {
		return findInnermostHandlerBlock(instructionOffset, true);
	}

	private ControlFlowNode findInnermostHandlerBlock(final int instructionOffset, final boolean finallyOnly) {
		ExceptionHandlerWrapper result = null;
		InstructionBlock resultBlock = null;

		for (final ExceptionHandlerWrapper handler: _exceptionHandlers) {
			if (finallyOnly && handler.isCatch()) {
				continue;
			}

			final InstructionBlock handlerBlock = handler.getHandlerBlock();

			if (handlerBlock.getFirstInstruction().getPosition() <= instructionOffset
					&& instructionOffset < handlerBlock.getLastInstruction().getPosition()
							+ handlerBlock.getLastInstruction().getLength()
					&& (resultBlock == null || isNarrower(handler.getHandlerBlock(), resultBlock))) {

				result = handler;
				resultBlock = handlerBlock;
			}
		}

		final ControlFlowNode innerMost = finallyOnly ? findInnermostExceptionHandlerNode(instructionOffset)
				: findInnermostFinallyHandlerNode(instructionOffset);

		final ExceptionHandlerWrapper innerHandler = innerMost.getExceptionHandler();
		final InstructionBlock innerBlock = innerHandler != null ? innerHandler.getTryBlock() : null;

		if (innerBlock != null && (resultBlock == null || isNarrower(innerBlock, resultBlock))) {
			result = innerHandler;
		}

		if (result == null) {
			return _exceptionalExit;
		}

		for (final ControlFlowNode node : _nodes) {
			if (node.getExceptionHandler() == result && node.getCopyFrom() == null) {
				return node;
			}
		}

		throw new IllegalStateException("Could not find innermost handler block!");
	}

	private ControlFlowEdge createEdge(final ControlFlowNode fromNode, final Instruction toInstruction,
			final JumpType type) {
		ControlFlowNode target = null;

		for (final ControlFlowNode node : _nodes) {
			if (node.getStart() != null && node.getStart().getPosition() == toInstruction.getPosition()) {
				if (target != null) {
					throw new IllegalStateException("Multiple edge targets detected!");
				}
				target = node;
			}
		}

		if (target != null) {
			return createEdge(fromNode, target, type);
		}

		throw new IllegalStateException("Could not find target node!");
	}

	private ControlFlowEdge createEdge(final ControlFlowNode fromNode, final ControlFlowNode toNode,
			final JumpType type) {
		final ControlFlowEdge edge = new ControlFlowEdge(fromNode, toNode, type);

		for (final ControlFlowEdge existingEdge : fromNode.getOutgoing()) {
			if (existingEdge.getSource() == fromNode && existingEdge.getTarget() == toNode
					&& existingEdge.getType() == type) {

				return existingEdge;
			}
		}

		fromNode.getOutgoing().add(edge);
		toNode.getIncoming().add(edge);

		return edge;
	}

	private static List<ExceptionHandlerWrapper> coalesceExceptionHandlers(final List<ExceptionHandlerWrapper> handlers) {
		final ArrayList<ExceptionHandlerWrapper> copy = new ArrayList<>(handlers);		
		// for (int i = 0; i < copy.size(); i++) {
		// final ExceptionHandler handler = copy.get(i);
		//
		// if (!handler.isCatch()) {
		// if (handler.getTryBlock().equals(handler.getHandlerBlock())) {
		// copy.remove(i--);
		// }
		// else if (handler.getTryBlock().getFirstInstruction() ==
		// handler.getHandlerBlock().getFirstInstruction() &&
		// handler.getTryBlock().getLastInstruction() ==
		// handler.getTryBlock().getFirstInstruction()) {
		// copy.remove(i--);
		// }
		// continue;
		// }
		//
		// final InstructionBlock tryBlock = handler.getTryBlock();
		// final InstructionBlock handlerBlock = handler.getHandlerBlock();
		//
		// for (int j = i + 1; j < copy.size(); j++) {
		// final ExceptionHandler other = copy.get(j);
		//
		// if (!other.isCatch()) {
		// continue;
		// }
		//
		// final InstructionBlock otherTry = other.getTryBlock();
		// final InstructionBlock otherHandler = other.getHandlerBlock();
		//
		// if (otherTry.equals(tryBlock) && otherHandler.equals(handlerBlock)) {
		// copy.set(
		// i,
		// ExceptionHandler.createCatch(
		// tryBlock,
		// handlerBlock,
		// MetadataHelper.findCommonSuperType(handler.getCatchType(),
		// other.getCatchType())
		// )
		// );
		//
		// copy.remove(j--);
		// }
		// }
		// }

		return copy;
	}

	private final class CopyFinallySubGraphLogic {
		final Map<ControlFlowNode, ControlFlowNode> oldToNew = new IdentityHashMap<>();
		final ControlFlowNode start;
		final ControlFlowNode end;
		final ControlFlowNode newEnd;

		CopyFinallySubGraphLogic(final ControlFlowNode start, final ControlFlowNode end, final ControlFlowNode newEnd) {
			this.start = start;
			this.end = end;
			this.newEnd = newEnd;
		}

		final ControlFlowNode copyFinallySubGraph() {
			for (final ControlFlowNode node : end.getPredecessors()) {
				collectNodes(node);
			}

			for (final ControlFlowNode old : oldToNew.keySet()) {
				reconstructEdges(old, oldToNew.get(old));
			}

			return getNew(start);
		}

		private void collectNodes(final ControlFlowNode node) {
			if (node == end || node == newEnd) {
				throw new IllegalStateException("Unexpected cycle involving finally constructs!");
			}

			if (oldToNew.containsKey(node)) {
				return;
			}

			final int newBlockIndex = _nodes.size();
			final ControlFlowNode copy;

			switch (node.getNodeType()) {
			case Normal:
				copy = new ControlFlowNode(newBlockIndex, node.getStart(), node.getEnd());
				break;

			case FinallyHandler:
				throw ContractUtils.unsupported("Unsupported FinallyHandler node");
				/*
				 * copy = new ControlFlowNode(newBlockIndex,
				 * node.getExceptionHandler(), node.getEndFinallyNode()); break;
				 */

			default:
				throw ContractUtils.unsupported();
			}

			copy.setCopyFrom(node);
			_nodes.add(copy);
			oldToNew.put(node, copy);

			if (node != start) {
				for (final ControlFlowNode predecessor : node.getPredecessors()) {
					collectNodes(predecessor);
				}
			}
		}

		private void reconstructEdges(final ControlFlowNode oldNode, final ControlFlowNode newNode) {
			for (final ControlFlowEdge oldEdge : oldNode.getOutgoing()) {
				createEdge(newNode, getNew(oldEdge.getTarget()), oldEdge.getType());
			}
		}

		private ControlFlowNode getNew(final ControlFlowNode oldNode) {
			if (oldNode == end) {
				return newEnd;
			}

			final ControlFlowNode newNode = oldToNew.get(oldNode);

			return newNode != null ? newNode : oldNode;
		}
	}
	
//	private static List<ExceptionHandlerWrapper> remapHandlers(final List<ExceptionHandlerWrapper> handlers, final List<Instruction> instructions) {
//        final List<ExceptionHandlerWrapper> newHandlers = new ArrayList<>();
//
//        for (final ExceptionHandlerWrapper handler : handlers) {
//            final InstructionBlock oldTry = handler.getTryBlock();
//            final InstructionBlock oldHandler = handler.getHandlerBlock();
//
//            final InstructionBlock newTry = new InstructionBlock(
//                instructions.atOffset(oldTry.getFirstInstruction().getPosition()),
//                instructions.atOffset(oldTry.getLastInstruction().getPosition())
//            );
//
//            final InstructionBlock newHandler = new InstructionBlock(
//                instructions.atOffset(oldHandler.getFirstInstruction().getPosition()),
//                instructions.atOffset(oldHandler.getLastInstruction().getPosition())
//            );
//
//            if (handler.isCatch()) {
//                newHandlers.add(
//                    ExceptionHandler.createCatch(
//                        newTry,
//                        newHandler,
//                        handler.getCatchType()
//                    )
//                );
//            }
//            else {
//                newHandlers.add(
//                    ExceptionHandler.createFinally(
//                        newTry,
//                        newHandler
//                    )
//                );
//            }
//        }
//
//        return newHandlers;
//    }
	
//	 public static Instruction getInstructionAtOffset(List<Instruction> insns, final int offset) {
//		 
//	        final Instruction result = tryGetAtOffset(offset);
//
//	        if (result != null) {
//	            return result;
//	        }
//
//	        throw new IndexOutOfBoundsException("No instruction found at offset " + offset + '.');
//	    }
}
