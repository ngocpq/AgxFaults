package gov.nasa.jpf.jcfg.core;

/**
 * @author Mike Strobel
 */
public enum StringComparison {
    Ordinal,
    OrdinalIgnoreCase
}
