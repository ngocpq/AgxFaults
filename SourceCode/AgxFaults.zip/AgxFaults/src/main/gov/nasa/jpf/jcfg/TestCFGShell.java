package gov.nasa.jpf.jcfg;

import java.io.PrintWriter;
import java.io.StringWriter;

import gov.nasa.jpf.Config;
import gov.nasa.jpf.JPF;
import gov.nasa.jpf.JPFShell;
import gov.nasa.jpf.jcfg.utils.DebugUtility;
import gov.nasa.jpf.util.JPFLogger;
import gov.nasa.jpf.util.LogManager;

public class TestCFGShell implements JPFShell {
	private JPFLogger logger = null;

	private Config config;

	public TestCFGShell(Config conf) {
		LogManager.init(conf);
		this.config = conf;
		logger = JPF.getLogger("jCFG");
		DebugUtility.init(conf);
	}
	
	@Override
	public void start(String[] args) {
		run();
	}

	private void run() {
		logger.finest("============ JPF Config     ============");
	    StringWriter sw = new StringWriter();
	    PrintWriter pw = new PrintWriter(sw);
	    this.config.list(pw);
	    pw.close();
	    logger.finest(sw.toString());
	    logger.finest("============ End JPF Config ============");
	    
	    Config jpfConf = config;
		JPF jpf = new JPF(jpfConf);
		
		logger.finest("============ Start ============");
	    jpf.run();
	    logger.finest("============ Finished ============");
	}
	
	
	
}
