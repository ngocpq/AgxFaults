package gov.nasa.jpf.jcfg.cfg;

public interface ITextOutput {
  int getRow();
  int getColumn();

  void indent();
  void unindent();

  void write(final char ch);
  void write(final String text);

  void writeError(final String value);

  void writeLabel(final String value);
  void writeLiteral(final Object value);
  void writeTextLiteral(final Object value);

  void writeComment(final String value);
  void writeComment(final String format, final Object... args);

  void write(final String format, final Object... args);
  void writeLine(final String text);
  void writeLine(final String format, final Object... args);
  void writeLine();

  void writeDelimiter(final String text);
  void writeOperator(final String text);
  void writeKeyword(final String text);

  void writeAttribute(String text);

  void writeDefinition(final String text, final Object definition);
  void writeDefinition(final String text, final Object definition, final boolean isLocal);

  void writeReference(final String text, final Object reference);
  void writeReference(final String text, final Object reference, final boolean isLocal);

  boolean isFoldingSupported();

  void markFoldStart(final String collapsedText, final boolean defaultCollapsed);
  void markFoldEnd();
  String getIndentToken();
  void setIndentToken(String indentToken);
}
