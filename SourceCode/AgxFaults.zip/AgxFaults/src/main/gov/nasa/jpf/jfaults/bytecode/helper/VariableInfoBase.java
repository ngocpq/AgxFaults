package gov.nasa.jpf.jfaults.bytecode.helper;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public abstract class VariableInfoBase<T> implements VariableInfo<T>{	
	private final Type<T> type;
	private final byte typeCode;
	
	@SuppressWarnings("unchecked")
	protected VariableInfoBase(byte typeCode){
		this.typeCode=typeCode;
		this.type = (Type<T>) ConcolicUtil.forTypeCode(this.typeCode);
	}
	@Override
	public Type<T> getVariableType() {
		return this.type;
	}

	@Override
	public byte getTypeCode() {
		return this.typeCode;
	}

	public abstract T getConcreteValue(ThreadInfo ti, StackFrame sf) ;

	public abstract void setConcreteValue(ThreadInfo ti, StackFrame sf, T value);

	public abstract Expression<T> getSymbolicValue(ThreadInfo ti, StackFrame sf);

	public abstract void setSymbolicValue(ThreadInfo ti, StackFrame sf, Expression<T> expr); 

}
