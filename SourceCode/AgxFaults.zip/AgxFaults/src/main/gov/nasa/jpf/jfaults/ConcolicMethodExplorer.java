/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 * 
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */
package gov.nasa.jpf.jfaults;

import gov.nasa.jpf.JPF;
import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.Valuation;
import gov.nasa.jpf.constraints.api.ValuationEntry;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.array.ArrayExpression;
import gov.nasa.jpf.constraints.array.ArrayType;
import gov.nasa.jpf.constraints.array.ArrayVariable;
import gov.nasa.jpf.constraints.array.SelectExpression;
import gov.nasa.jpf.constraints.array.StoreExpression;
import gov.nasa.jpf.constraints.expressions.CastExpression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.java.ObjectConstraints;
import gov.nasa.jpf.constraints.parser.ParserUtil;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.constraints.util.ExpressionUtil;
import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jcfg.utils.DebugUtility;
import gov.nasa.jpf.jcfg.utils.InstructionUtil;
import gov.nasa.jpf.jcfg.utils.SimpleProfiler;
import gov.nasa.jpf.jcfg.variable.LocalVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.MemoryModifiableInstruction;
import gov.nasa.jpf.jcfg.variable.MemoryPerturbatorFactory;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.bytecode.ATHROW;
import gov.nasa.jpf.jfaults.bytecode.ExecuteSuperInsntructionHelper;
import gov.nasa.jpf.jfaults.bytecode.assignment.LRETURN;
import gov.nasa.jpf.jfaults.bytecode.heap.HeapNode;
import gov.nasa.jpf.jfaults.bytecode.heap.SymbolicHeap;
import gov.nasa.jpf.jfaults.bytecode.helper.VariableInfo_Helper;
import gov.nasa.jpf.jfaults.config.AnalysisConfig;
import gov.nasa.jpf.jfaults.config.ConcolicConfig;
import gov.nasa.jpf.jfaults.config.ConcolicMethodConfig;
import gov.nasa.jpf.jfaults.config.ConcolicValues;
import gov.nasa.jpf.jfaults.config.ParamConfig;
import gov.nasa.jpf.jfaults.config.TestCaseManager;
import gov.nasa.jpf.jfaults.constraints.ConstraintsTree;
import gov.nasa.jpf.jfaults.constraints.FlowInSensitiveFormulaFaultLocator;
import gov.nasa.jpf.jfaults.constraints.FlowSensitiveFormulaFaultLocator;
import gov.nasa.jpf.jfaults.constraints.IncAngelicFormulaFaultLocator;
import gov.nasa.jpf.jfaults.constraints.IncAngelicFormulaFaultLocator2;
import gov.nasa.jpf.jfaults.constraints.InternalConstraintsTree;
import gov.nasa.jpf.jfaults.constraints.PathResult;
import gov.nasa.jpf.jfaults.constraints.PathResult.ValuationResult;
import gov.nasa.jpf.jfaults.constraints.PostCondition;
import gov.nasa.jpf.jfaults.constraints.ProgramFormulaFaultLocator;
import gov.nasa.jpf.jfaults.constraints.UnsatCoreDrivenAngelicFaultLocator;
import gov.nasa.jpf.jfaults.constraints.InternalConstraintsTree.BranchEffect;
import gov.nasa.jpf.jfaults.constraints.LocFaultsFaultLocalizator;
import gov.nasa.jpf.jfaults.constraints.McsDrivenAngelicFaultLocator;
import gov.nasa.jpf.jfaults.constraints.cfg.AngelicControlFlowGraph;
import gov.nasa.jpf.jfaults.constraints.tree.AngelicAssignmentData;
import gov.nasa.jpf.jfaults.constraints.tree.ExecutionTraceItem;
import gov.nasa.jpf.jfaults.constraints.tree.Node;
import gov.nasa.jpf.jfaults.exception.NestingControlDepthExceededException;
import gov.nasa.jpf.jfaults.objects.SymbolicObject;
import gov.nasa.jpf.jfaults.objects.SymbolicObjectsContext;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.jvm.bytecode.JVMLocalVariableInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMReturnInstruction;
import gov.nasa.jpf.util.JPFLogger;
import gov.nasa.jpf.vm.ClassInfo;
import gov.nasa.jpf.vm.DynamicElementInfo;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.Heap;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.MJIEnv;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;
import gov.nasa.jpf.vm.UncaughtException;
import gov.nasa.jpf.vm.VM;
import gov.nasa.jpf.vm.bytecode.ArrayElementInstruction;
import gov.nasa.jpf.vm.bytecode.InstructionInterface;
import gov.nasa.jpf.vm.bytecode.StoreInstruction;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import org.antlr.runtime.RecognitionException;

import com.google.common.base.Predicates;

/**
 *
 */
public class ConcolicMethodExplorer {
  
  private static final class RestoreExploreState {
    public final boolean explore;
    
    public RestoreExploreState(boolean explore) {
      this.explore = explore;
    }
    
    public RestoreExploreState clone() {
      return this;
    }
  }

  public static ConcolicMethodExplorer getCurrentAnalysis(ThreadInfo ti) {
    return ti.getAttr(ConcolicMethodExplorer.class);
  }
  
  
  /**
   * logger
   */
  private final JPFLogger logger = JPF.getLogger("jdart");
  
  /**
   * explored method
   */
  private MethodInfo methodInfo;

  /**
   * concolic config for method
   */
  private final ConcolicMethodConfig methodConfig;
  private final AnalysisConfig anaConf;
  
  /**
   * constraints tree from exploring method
   */
  private InternalConstraintsTree constraintsTree;
  private AngelicControlFlowGraph angelicCFG;
  
  /**
   * the original initial valuation for symbolic vars
   */
  private Valuation initValuation;
  
  private TestCaseManager testCaseManager;
  
  /**
   * current input value
   */
  private Valuation currValuation;
  
  private Valuation nextValuation;
  private Valuation angelicValuation;
  
  /**
   * The original values of the parameters
   */
  private Object[] initParams;
  
  private SymbolicObjectsContext symContext;
  private SymbolicObjectsContext symContextSsa; 

  /**
   * execution info about method
   */
  
  //private final SolverContext solverCtx;
  

  public ConcolicMethodExplorer(ConcolicConfig config, String id, MethodInfo mi) {
    // store method info and config
    this.methodInfo = mi;
    this.methodConfig = config.getMethodConfig(id);
    this.anaConf = methodConfig.getAnalysisConfig();
    
    // get preset values
    ConcolicValues vals = methodConfig.getConcolicValues();
    if (vals instanceof TestCaseManager)
    	this.testCaseManager = (TestCaseManager)vals;
    
    // create a constraints tree
    //this.solverCtx = config.getSolver().createContext();    
    //this.constraintsTree = new InternalConstraintsTree(solverCtx, anaConf, vals);
    //#UnsatCoreDriven, McsDriven, ProgramFormula, LocFaults, OnDemand
    String faultLocalizationKey = anaConf.getConfig().getProperty("ffl.faultlocalizator", "McsDriven");
    switch (faultLocalizationKey){
    	case "McsDriven":
    		this.constraintsTree = new McsDrivenAngelicFaultLocator(config.getSolver(), anaConf, vals);
    	break;
    	case "UnsatCoreDriven":
    		this.constraintsTree = new UnsatCoreDrivenAngelicFaultLocator(config.getSolver(), anaConf, vals);
    	break;
    	case "ProgramFormula":
    		this.constraintsTree = new ProgramFormulaFaultLocator(config.getSolver(), anaConf, vals);
      	break;
    	case "LocFaults":
    		this.constraintsTree = new LocFaultsFaultLocalizator(config.getSolver(), anaConf, vals);
      	break;
    	case "OnDemand":
    		this.constraintsTree = new InternalConstraintsTree(config.getSolver(), anaConf, vals);
      	break;
    	case "IncAngelic":
    		this.constraintsTree = new IncAngelicFormulaFaultLocator(config.getSolver(), anaConf, vals);
      	break;
    	case "FlowInSensitive":
    		this.constraintsTree = new FlowInSensitiveFormulaFaultLocator(config.getSolver(), anaConf, vals);
      	break;
    	case "FlowSensitive":
    		this.constraintsTree = new FlowSensitiveFormulaFaultLocator(config.getSolver(), anaConf, vals);
      	break;
    	default:
      	logger.info("FaultLocalizator is not valid: "+faultLocalizationKey);
    }         
    this.angelicCFG = new AngelicControlFlowGraph();
  }
  
  public void setExplore(boolean explore) {
    constraintsTree.setExplore(explore);
  }
  
  public String getId() {
    return methodConfig.getId();
  }
  
  public boolean isRootFrame(StackFrame sf) {
    return sf.getPrevious().hasFrameAttr(RootFrame.class);
  }
  
  private PostCondition collectPostCondition(ThreadInfo ti) {
    PostCondition pc = new PostCondition();
    for(SymbolicVariable<?> sv : symContext.getSymbolicVars()) {
      sv.addToPostCondition(pc);
    }
    collectSymbolicReturn(pc, ti);
    
    return pc;
  }
  
  private void collectSymbolicReturn(PostCondition pc, ThreadInfo ti) {
    byte rtc = methodInfo.getReturnTypeCode();
    if(rtc == Types.T_VOID)
      return;
    
    
    StackFrame sf = ti.getTopFrame();
    if(rtc == Types.T_ARRAY || rtc == Types.T_REFERENCE) {
      int ref = sf.peek();
      ElementInfo ei = ti.getHeap().get(ref);
      if(ei == null)
        return;
      
    }
    else { // primitive
      Type<?> type = ConcolicUtil.forTypeCode(rtc);
      Pair<?> cr = ConcolicUtil.peek(sf, type);
      if(!cr.isConcrete())
        pc.setReturn(cr.symb);
    }
  }
      
  /*private List<Expression<Boolean>> collectErrorAssertion(ThreadInfo ti) {
		//TODO: analysis exception type, 
		List<Expression<Boolean>> assertion = new ArrayList<>();
		ElementInfo exElem = ti.getPendingException().getException();
		String assertClass = AssertionError.class.getName();
		logger.fine("collectErrorAssertion: currentTreeNode: "+this.constraintsTree.getCurrentNode());
		logger.fine("collectErrorAssertion: currentOpenBranch: "+this.constraintsTree.getCurrentOpenBranchNode());
		Node branchNode = this.constraintsTree.getCurrentOpenBranchNode();
		if (branchNode!=null){
			int branchIdx = branchNode.decisionData().getSelectedBranchIndex();			
			assertion.add(new Negation(branchNode.decisionData().getConstraint(branchIdx)));			
		}		
		return assertion;
	}*/
  
  /*private List<Expression<Boolean>> collectAssertionConstraints(ThreadInfo ti) {
		List<Expression<Boolean>> assertion = new ArrayList<>();
	  	if (testCaseManager==null)
	  		return assertion;
	  	PostConditionSpec postCondSpec = testCaseManager.getPostConditionExpression(currValuation);
	  	if (postCondSpec==null)
	  		return assertion;
	  	
	  	List<Variable<?>> lstVariables = new ArrayList<>();
	  	HashMap<String, String> mapSsaVarName = new HashMap<>();
	  	for (String varName:postCondSpec.getVariableNames()){
	  		Variable var = getVariableByName(varName,this.methodInfo);  		
	  		lstVariables.add(var);
	  		Variable varSSA = getLastSSAVariableByName(varName,this.methodInfo,ti);
	  		mapSsaVarName.put(varName, varSSA.getName());
	  	}
	  	
	  	Function<String, String> renameFunction = new Function<String, String>() {
				
				@Override
				public String apply(String varName) {
					return mapSsaVarName.get(varName);
				}
			};
	  	
	  	for(String exprString :postCondSpec.getConstraints())
			try {
				Expression<Boolean> expr = ParserUtil.parseLogical(exprString,ObjectConstraints.getJavaTypes(),lstVariables);
				//rename to SSA variables
				expr = ExpressionUtil.renameVars(expr, renameFunction);
				assertion.add(expr);
			} catch (RecognitionException e) {
				throw ContractUtils.unsupported("Failed when parsing post condition specification");
			}
	  	
	  	Variable varReturn = null;
	  	for(Variable var: lstVariables){
			if (var.getName().equals("return")){
				varReturn=var;
				break;
			}
	  	}
	  	if (varReturn!=null){
	  		//add return mapping
	  		Expression returnExp = collectReturnExpression(ti);
			Expression<Boolean> expr = ExpressionUtil.makeEqualityExpression(varReturn, returnExp);
			assertion.add(expr);
	  	}
			
	  	
	  	return assertion;
	}
  
  private Variable getVariableByName(String varName, MethodInfo mInfo) {
  	if (varName.equals("return")){
  		byte rtc = mInfo.getReturnTypeCode();
  		Type<?> type = ConcolicUtil.forTypeCode(rtc);
  		Variable var = Variable.create(type, varName);
  		return var;  		
  	}
  	
  	LocalVarInfo[] localVars = mInfo.getLocalVars();
  	for(LocalVarInfo vInfo:localVars){
			if (varName.equals(vInfo.getName())){	
				String varId = mInfo.getClassInfo().getName() + '.' + mInfo.getUniqueName() + '.' + varName+vInfo.getSlotIndex();
				byte tc = Types.getBuiltinType(vInfo.getType());
				Type<?> type = ConcolicUtil.forTypeCode(tc);
	  		Variable var = Variable.create(type, varName);
	  		return var;
			}
  	}
  	throw new UnsupportedOperationException("variable not found: "+varName);
	}*/
  
	public void completePathOk(ThreadInfo ti) {
		firstExecution=false;
    PostCondition pc = collectPostCondition(ti);
    ValuationResult res = PathResult.ok(currValuation, pc);
    
    this.constraintsTree.instructionExecuted(ti, ti.getPC());
    
    if (anaConf.enableDebugFormula())
    	this.exportConstraintTree(anaConf.getConfigFileName());
    
    constraintsTree.finish(res,InstructionUtil.getSucceedTerminalInstruction());
    
    if (anaConf.enableDebugFormula())
    	this.exportConstraintTree(anaConf.getConfigFileName());
  }
  
  public void completePathError(ThreadInfo ti) {
  	firstExecution=false;
  	Instruction pc = ti.getPC();
    ElementInfo exElem = ti.getPendingException().getException();
    StringWriter sw = new StringWriter();
    try(PrintWriter pw = new PrintWriter(sw)) {
      ti.printStackTrace(pw, exElem.getObjectRef());
    }
    String st = sw.toString();
    ValuationResult res = PathResult.error(currValuation, exElem.getClassInfo().getName(), st);
    
		this.constraintsTree.instructionExecuted(ti, pc);
		
    if (anaConf.enableDebugFormula())
    	this.exportConstraintTree(anaConf.getConfigFileName());
    
    constraintsTree.finish(res,InstructionUtil.getErrorTerminalInstruction());
    
    if (anaConf.enableDebugFormula())
    	this.exportConstraintTree(anaConf.getConfigFileName());
  }

  static final Instruction ERROR_INSNTRUCTION = new ATHROW();
  
  public boolean hasMoreChoices() {
    // If the initValuation is null, then the initial
    // valuation has not been read; we are *before* the
    // first execution
    if(initValuation == null){    	
      return true;
    }
    // If there is no next valuation, try to find one
    if(nextValuation == null){
    	SimpleProfiler.start("findNext_hasMoreChoices");
      nextValuation = constraintsTree.findNext();
      SimpleProfiler.stop("findNext_hasMoreChoices");
      
      /*//TODO: (refactor this) validate result
      if (nextValuation ==null){
      	nextValuation = constraintsTree.nextAgxPathToValidate();
      }*/
    }
    return (nextValuation != null);
  }
  
  public boolean advanceValuation() {
    if(nextValuation == null){
    	SimpleProfiler.start("findNext_advanceValuation");
      nextValuation = constraintsTree.findNext();
      SimpleProfiler.stop("findNext_advanceValuation");
    }
    /*if (nextValuation != null) {
      for (Variable v : currValuation.getVariables()) {
        if (!nextValuation.containsValueFor(v)) {
          nextValuation.addEntry(new ValuationEntry(v, 
          		currValuation.getValue(v))); // returns the default value for this type
        }
      }
    }*/
    if (anaConf.isFaultLocalizationEnabled()){
    	this.angelicValuation = nextValuation;
    	nextValuation = initValuation;
    }
    currValuation = nextValuation;
    nextValuation = null;
    
    return (currValuation != null);
  }
  
  
  /**
   * registers method for concolic execution. Puts symbolic input values onto
   * the stack ...
   * 
   * @param invokeInstruction
   * @param systemState
   * @param ti 
   */
  public void initializeMethod(ThreadInfo ti, StackFrame sf) {
    logger.finest("Initializing concolic execution of " + methodInfo.getFullName());

    // mark root frame
    sf.setFrameAttr(RootFrame.getInstance());
    
    symContext = new SymbolicObjectsContext(ti.getHeap(), anaConf.getSymbolicFieldsExclude(), anaConf.getSymbolicFieldsInclude(), anaConf.getSpecialExclude());
    
    symContextSsa = new SymbolicObjectsContext(ti.getHeap(),  Predicates.alwaysTrue(),  Predicates.alwaysFalse(),  Predicates.alwaysFalse());
    
    initializeSymbolicStatic(ti);
    initializeSymbolicParams(ti, sf);
    
    List<Variable<?>> vlist = new ArrayList<>();
    logger.finest("Symbolic variables:");
    logger.finest("===================");
    for(SymbolicVariable<?> var : symContext.getSymbolicVars()) {
      logger.finest(var.getVariable().getName());
      vlist.add(var.getVariable());
    }
    logger.finest();
    
    for(String constraintStr : anaConf.getConstraints()) {
      logger.finer("Adding constraint ", constraintStr);
      try {
        Expression<Boolean> constrExpr = ParserUtil.parseLogical(constraintStr,
            ObjectConstraints.getJavaTypes(),
            vlist);
        try {
          //solverCtx.add(constrExpr);
        	this.constraintsTree.addConstraint(constrExpr);
        }
        catch(Exception ex) {
          logger.severe("Could not add constraint to solver: ", ex);
        }
      } catch (RecognitionException ex) {
        logger.severe("Could not parse constraint: ", ex);
      }
    }
    
  }
  
  private void initializeSymbolicStatic(ThreadInfo ti) {
    List<String> symbStatics = anaConf.getSymbolicStatics();
    for(String clazz : symbStatics) {
      ClassInfo ci = ClassInfo.getInitializedClassInfo(clazz, ti);
      ElementInfo ei = ci.getStaticElementInfo();
      symContext.processObject(ei, ci.getName());
    }
  }

  private void initializeSymbolicParams(ThreadInfo ti, StackFrame sf) {
    List<ParamConfig> pconfig = methodConfig.getParams();
    int argSize = pconfig.size();
    this.initParams = new Object[argSize];
    int stackIdx = methodInfo.getArgumentsSize();
    
    Heap heap = ti.getHeap();
    
    if(!methodInfo.isStatic()) {
      stackIdx--;
      int thisRef = sf.peek(stackIdx);
      ElementInfo thisEi = heap.get(thisRef);
      symContext.processObject(thisEi, "this", true);
    }
    
    byte[] argTypes = methodInfo.getArgumentTypes();
    
    for(int i = 0; i < argSize; i++) {
      ParamConfig pc = pconfig.get(i);
      String name = pc.getName();
      
      byte tc = argTypes[i];
      stackIdx--;
      if(tc == Types.T_LONG || tc == Types.T_DOUBLE)
        stackIdx--;
      
      this.initParams[i] = getVal(sf, stackIdx, tc);
      
      if(name == null)
        continue; // null name indicates non-symbolic param
      
      if(tc == Types.T_REFERENCE || tc == Types.T_ARRAY) {
        int ref = sf.peek(stackIdx);
        ElementInfo ei = heap.get(ref);
        if(ei != null)
          symContext.processObject(ei, name, true);
      }
      else { // primitive type
        Type<?> t = ConcolicUtil.forTypeCode(tc);
        SymbolicParam<?> sp = new SymbolicParam<>(t, name, stackIdx);
        symContext.addStackVar(sp);
      }
    }
  }
  
  private static Object getVal(StackFrame sf, int offset, byte type) {
    switch(type) {
    case Types.T_LONG:
      return sf.peekLong(offset);
    case Types.T_DOUBLE:
      return sf.peekDouble(offset);
    case Types.T_FLOAT:
      return sf.peekFloat(offset);
    case Types.T_INT:
      default:
      return sf.peek(offset);
    }
  }
  
  public void prepareFirstExecution(StackFrame sf) {
    initValuation = new Valuation();
    for(SymbolicVariable<?> sv : symContext.getSymbolicVars())
      sv.readInitial(initValuation, sf);
    
    currValuation = new Valuation();
    for(ValuationEntry<?> entry:initValuation.entries())
    	currValuation .addEntry(entry);
  }
  
  public void prepareReexecution(StackFrame sf) {
    logger.finest("Reexecuting with valuation " + currValuation);
    for(SymbolicVariable<?> sv : symContext.getSymbolicVars())
      sv.apply(currValuation, sf);
  }
 
  
  public void uncaughtException(ThreadInfo ti, UncaughtException uex) {
    completePathError(ti);
    ti.clearPendingException();
    ti.breakTransition(true);
  }
  
  public boolean needsDecisions() {
    return constraintsTree.needsDecision();
  }
  
  @SafeVarargs
  public final void decisionException(ThreadInfo ti, InstructionInterface insn,String exceptionType, int chosenIdx, Expression<Boolean> ...expressions) {
    BranchEffect eff = constraintsTree.decisionExceptionFlow(insn, chosenIdx, expressions,exceptionType);
    switch(eff) {
    case INCONCLUSIVE:
      logger.severe("Aborting current execution due to inconclusive divergence...");
      constraintsTree.failCurrentTarget();
      ti.breakTransition(true);
      break;
    case UNEXPECTED:
      logger.warning("Unexpected divergence in execution of current valuation ...");
      constraintsTree.failCurrentTarget(); // TODO: Here, we could make more effort ...
      break;
    default:
    }
  }
  
  @SafeVarargs
  public final void decisionControlFlow(ThreadInfo ti, InstructionInterface branchInsn, int chosenIdx, Expression<Boolean> ...expressions) {
    BranchEffect eff = constraintsTree.decisionControlFlow(branchInsn, chosenIdx, expressions);
    switch(eff) {
    case INCONCLUSIVE:
      logger.severe("Aborting current execution due to inconclusive divergence...");
      constraintsTree.failCurrentTarget();
      ti.breakTransition(true);
      break;
    case UNEXPECTED:
      logger.warning("Unexpected divergence in execution of current valuation ...");
      constraintsTree.failCurrentTarget(); // TODO: Here, we could make more effort ...
      break;
    default:    	
    }
  }
 
    
  public ConcolicMethodConfig getMethodConfig() {
    return this.methodConfig;
  }
  
  public InternalConstraintsTree getInternalConstraintsTree() {
    return this.constraintsTree;
  }
  
  public CompletedAnalysis finish() {
  	if (anaConf.enableDebugFormula()){  		
    	//this.exportConstraintTree("agx");
  		this.exportConstraintTree(anaConf.getConfigFileName());
  	}
  	this.exportProgramFormula(anaConf.getConfigFileName());
  	//TODO: perform full-path formula  	
  	//this.constraintsTree.performAllPathMethod();
  	this.constraintsTree.finish();
    return new CompletedAnalysis(methodConfig, initValuation, initParams, constraintsTree.toFinalCTree(),constraintsTree);
  }

  int pathExecutionCount = 0;
  public void newPath(StackFrame sf) {  	
  	if (initValuation == null && this.testCaseManager!=null && this.testCaseManager.hasNext()){ //run test suite
  		nextValuation = this.testCaseManager.next();
  		initValuation = nextValuation;
  		currValuation=nextValuation;  		
  		addInputConstraints();  		
  	}
  	
    if(initValuation == null) { // first execution
      prepareFirstExecution(sf);      
      addInputConstraints();
    }
    else { // reexecution
      advanceValuation();
      prepareReexecution(sf);
    }    
    pathExecutionCount++;
  }
  
  int getPathExecutionCount(){
  	return this.pathExecutionCount;
  }
  
  void addInputConstraints(){
  	List<Expression<Boolean>> initialInputConstraints = collectInputConstraints();
  	this.constraintsTree.setInitialInputConstraints(initialInputConstraints);
  	if (anaConf.isFaultLocalizationEnabled())
  		this.constraintsTree.addInputConstraint(initialInputConstraints);
  	//solverCtx.add(collectInputConstraints());
  }
  
  @SuppressWarnings({ "unchecked", "rawtypes" })
	private List<Expression<Boolean>> collectInputConstraints() {
  	List<Expression<Boolean>> inputs = new ArrayList<>();
    for(SymbolicVariable<?> sv : symContext.getSymbolicVars()){    	
      //Object value = sv.getConcolicValue(sf);
    	Object value = currValuation.getValue(sv.getVariable());
    	if (sv.getVariable() instanceof ArrayVariable){
    		ArrayVariable arrVar = (ArrayVariable) sv.getVariable();
    		ArrayType arrType = arrVar.getArrayType();
    		Object[] arr = arrType.cast(value);
    		for(int i=0;i<arrType.getLength();i++){
    			//select
    			SelectExpression select = new SelectExpression<>(arrVar, i);
    			Expression expr = Constant.createCasted(arrType.getElementType(), arr[i]);
    			Expression<Boolean> constraint= ExpressionUtil.makeEqualityExpression(select,expr);
  	      inputs.add(constraint);
    		}
    	}else{
	      Expression expr = Constant.createCasted(sv.getVariable().getType(), value);
	      Expression<Boolean> constraint= ExpressionUtil.makeEqualityExpression(sv.getVariable(),expr);
	      inputs.add(constraint);
    	}      
    }
    return inputs;
  }
  
  public void makeCurrentAnalysis(ThreadInfo ti) {
    ti.setAttr(this);
  }

  public AnalysisConfig getAnalysisConfig() {
    return anaConf;
  }
  
  public void methodExited(ThreadInfo ti, MethodInfo mi) {
  	InstructionInterface executedInsn = ti.getPC();
		this.constraintsTree.instructionExecuted(ti, executedInsn);
		
    RestoreExploreState r = ti.getTopFrame().getFrameAttr(RestoreExploreState.class);
    if(r != null) {
      constraintsTree.setExplore(r.explore);
      logger.finer("Restored exploration state after leaving method ", mi.getFullName());
    }
    this.angelicCFG.methodExited(ti,mi);
    this.constraintsTree.processExitingMethodBlock(ti, mi);
  }
  
  public void methodEntered(ThreadInfo ti, MethodInfo mi) {
    boolean explore = constraintsTree.isExplore();
    
    if(explore) {
      if(anaConf.suspendExploration(mi)) {
        ti.getTopFrame().setFrameAttr(new RestoreExploreState(explore));
        logger.finer("Suspending exploration in method " + mi.getFullName());
        constraintsTree.setExplore(false);
      }
    }
    else {
      if(anaConf.resumeExploration(mi)) {
        ti.getTopFrame().setFrameAttr(new RestoreExploreState(explore));
        logger.finer("Resuming exploration in method " + mi.getFullName());
        constraintsTree.setExplore(true);
      }
    }
    
    //constraintsTree.enterMethodBlock(mi,ti.getStackDepth());
    this.angelicCFG.methodEntered(ti,mi);
    this.constraintsTree.methodEntered(ti,mi);
    
  }
  
  
  // LEGACY API
  
  @Deprecated
  public ConstraintsTree getConstraintsTree() {
    return constraintsTree.toFinalCTree();
  }
  
  @Deprecated
  public Valuation getOriginalInitialValuation() {
    return initValuation;
  }

	private int getSelectedDecision(Expression<Boolean>[] constraints, Valuation valuation) {
		for (int i=0;i<constraints.length;i++)
			if (constraints[i].evaluate(valuation))
				return i;
		return -1;
	}

	public boolean isSuspiciousScope(InstructionInterface insn) {
		/*String codeLine = insn.getSourceLine();
		if (codeLine!=null && codeLine.trim().startsWith("assert "))
			return false;*/
		MethodInfo mi = insn.getMethodInfo();
		String insnId = mi.getFullName()+":"+insn.getFilePos()+":"+insn.getPosition();
		if (this.getAnalysisConfig().getSuspiciousScopeExclude().apply(insnId))
			return false;
		
		if (this.getAnalysisConfig().getSuspiciousScopeInclude().apply(insnId))
			return true;
		return false;
	}

	public AngelicControlFlowGraph getAngelicCFG() {
		return this.angelicCFG;
	}

	public void executeInstruction(VM vm, ThreadInfo ti, Instruction insnToExecute) {
		this.angelicCFG.executeInstruction(insnToExecute,ti);
		
//		if (this.isSuspiciousScope(insnToExecute)){
//			//create new angelic variable and perturb symbolic value 
//		}
		
	}

	public void instructionExecuted(VM vm, ThreadInfo ti, Instruction executedInsn, Instruction nextInsn) throws NestingControlDepthExceededException {
		this.angelicCFG.instructionExecuted(executedInsn,nextInsn,ti);
		this.constraintsTree.instructionExecuted(ti,executedInsn);
		this.constraintsTree.processExitingBlock(ti,nextInsn);
		this.constraintsTree.updateCurrentDependency();
		if (this.anaConf.maxNestingControlDepthExceeded(this.constraintsTree.getCurrentNode().getControlDependentDepth()))
			throw new NestingControlDepthExceededException("nesting control depth exceeded");
	}
	
	public <T> Variable<T> getOrAssignSummaryVariable(InstructionInterface insn,int operatorIdx,ThreadInfo ti, StackFrame sf,Expression<T> symValue,T concVal, Expression<Boolean> guardConstraint) {		
		String varUniqueId = "@PHI@"+InstructionUtil.getUniqueIdString(insn)+"_op"+operatorIdx;
		return getOrCreateSummaryVariable(insn, varUniqueId, ti, sf, symValue, concVal, guardConstraint);
	}
	
	public <T> Variable<T> getOrCreateSummaryVariable(InstructionInterface insn,String varUniqueId,ThreadInfo ti, StackFrame sf,Expression<T> symValue,T concVal, Expression<Boolean> guardConstraint) {		
		Variable<T> symbVariable = this.constraintsTree.getOrAssignSummaryVariable(varUniqueId,insn,symValue,guardConstraint);
		this.updateCurrentConcreteValuation(symbVariable, concVal);
		return symbVariable;
	}
	
	public <T> Pair<T> getOrCreateSummaryVariablePair(InstructionInterface insn,String varUniqueId,ThreadInfo ti, StackFrame sf,Expression<T> symValue,T concVal, Expression<Boolean> guardConstraint) {		
		Variable<T> symbVariable = getOrCreateSummaryVariable(insn, varUniqueId, ti, sf, symValue, concVal, guardConstraint);
		return new Pair<T>(concVal,symbVariable);
	}	
	
	public <T> Pair<T> getOrCreateAngelicVariable(InstructionInterface insn,String varUniqueId,ThreadInfo ti, StackFrame sf,Expression<T> symValue,T concVal) {		
		AngelicAssignmentData<T> decisionData = this.constraintsTree.getOrCreateAngelicVariableConstraint(insn,varUniqueId,symValue);
		Variable<T> symbVariable = decisionData.getAngelicVariable();
		T agxConcVal;
		if (isAngelicLocation(decisionData)){
			agxConcVal = getAngelicValue(symbVariable);			
		}else
			agxConcVal = concVal;
		this.updateCurrentConcreteValuation(symbVariable, agxConcVal);
		return new Pair<T>(agxConcVal, symbVariable)	;		
	}
	
	public <T> ArrayVariable<T> getOrCreateSymbolicArrayStore(ArrayElementInstruction insn,ThreadInfo ti, ElementInfo eiArray, int objRef,ArrayExpression<T> oldArray,Expression<Integer> idxExpr,Expression<T> valSymb) {
		ArrayType<T> arrType = oldArray.getArrayType();
		if (valSymb.getType() != arrType.getElementType()){
			logger.info("Debug: array type does not match");
			valSymb = CastExpression.create(valSymb, arrType.getElementType());
		}
		StoreExpression<T> arrayExpr = new StoreExpression<>(oldArray, idxExpr, valSymb);
		String name = eiArray.toString()+"_"+objRef;		
		ArrayVariable<T> symbArray = this.constraintsTree.getOrCreateSymbolicArrayVariable(name,insn,arrayExpr);
		//TODO: update current valuation
		
		T[] concArray = oldArray.evaluate(this.currValuation);
		Integer arrIndex = idxExpr.evaluate(this.currValuation);
		T concItem = valSymb.evaluate(this.currValuation);
		concArray[arrIndex] = concItem;
		this.updateCurrentConcreteValuation(symbArray, concArray );
		return symbArray;
	}
	
	public <T> ArrayVariable<T> getOrCreateSymbolicArray(ArrayElementInstruction insn,ThreadInfo ti, ElementInfo eiArray, int arrayRef, Expression<T>[] symbValue, T[] concValue) {
		//TODO: duplicate name
		String name = eiArray.toString()+"_"+arrayRef;
		
		ArrayVariable<T> symbArray = this.constraintsTree.getOrCreateSymbolicArrayVariable(name,insn,symbValue);
		//
		this.updateCurrentConcreteValuation(symbArray, concValue); 
		return symbArray;
	}
	
//	public <T> SymbolicObject getOrCreateSymbolicObject(InstructionInterface insn,ThreadInfo ti, ElementInfo eiObj, int objRef) {
//		String name = eiObj.toString()+"_"+objRef;		
//		ArrayType<T> arrayType = ConcolicUtil.getArrayType(ti,objRef);    	
//  	Expression[] symbValue = new Expression[arrayType.getLength()];
//  	Object[] concValue = new Object[arrayType.getLength()];
//  	for (int i=0;i<arrayType.getLength();i++){
//  		T elmConc = ConcolicUtil.getArrayElement(eiArray, i, arrayType.getElementType());
//  		Expression<T> elmSymb = eiArray.getElementAttr(i, Expression.class);
//  		if (elmSymb==null)
//  			elmSymb = Constant.create(arrayType.getElementType(), elmConc);
//  		symbValue[i] = elmSymb;
//  		concValue[i] = elmConc;	    		
//  	}
//		
//		ArrayVariable<T> symbArray = this.constraintsTree.getOrCreateSymbolicArrayVariable(name,insn,symbValue);
//		//
//		this.currValuation.setCastedValue(symbArray, concValue); 
//		return symbArray;
//	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public <T> ArrayVariable<T> getOrCreateSymbolicArray(ArrayElementInstruction insn,ThreadInfo ti, ElementInfo eiArray, int objRef) {
		String name = eiArray.toString()+"_"+objRef;		
		ArrayType<T> arrayType = ConcolicUtil.getArrayType(ti,objRef);    	
  	Expression[] symbValue = new Expression[arrayType.getLength()];
  	Object[] concValue = new Object[arrayType.getLength()];
  	for (int i=0;i<arrayType.getLength();i++){
  		T elmConc = ConcolicUtil.getArrayElement(eiArray, i, arrayType.getElementType());
  		Expression<T> elmSymb = eiArray.getElementAttr(i, Expression.class);
  		if (elmSymb==null)
  			elmSymb = Constant.create(arrayType.getElementType(), elmConc);
  		symbValue[i] = elmSymb;
  		concValue[i] = elmConc;	    		
  	}
		
		ArrayVariable<T> symbArray = this.constraintsTree.getOrCreateSymbolicArrayVariable(name,insn,symbValue);
		//
		this.updateCurrentConcreteValuation(symbArray, concValue); 
		return symbArray;
	}
	
	public <T> T getAngelicValueOfExpression(Expression<T> symCondExpr) {
		return symCondExpr.evaluate(this.currValuation);
	}
	
	public void exportConstraintTree(String prefix) {
		String dir = anaConf.getLogDirPath();
		String fileName = prefix+"_"+this.methodConfig.getMethodName();
		this.constraintsTree.exportConstraintTree(fileName);	  		
	}	
	
	public void exportProgramFormula(String prefix) {
		String dir = anaConf.getLogDirPath();
	  String formulaFileName = prefix+"_"+this.methodConfig.getMethodName()+this.getPathExecutionCount()+"_formula";
	  formulaFileName = DebugUtility.getNextUniqueName(formulaFileName);
		String formulaFilePath = dir+File.separator+formulaFileName+".txt";
	  File fileFormula = new File(formulaFilePath);
		this.constraintsTree.exportFullProgramFormula(fileFormula);
	}
	
	/**
	 * get current executing block
	 * @return
	 */
	public Node getCurrentExecutingLocation() {
		return this.constraintsTree.getCurrentExecutingLocation();		
	}
	
	public ExecutionTraceItem getCurrentExecutingTraceItem(InstructionInterface insnToExecute) {
		return this.constraintsTree.getOrAddExecutingTraceItem(insnToExecute);		
	}
	
	public Instruction checkAndCreateSymbolicSummaryVariable(ThreadInfo ti, LastModifiedLocationAttribute defAtt, InstructionInterface insnToExecute){
		ExecutionTraceItem location = this.getCurrentExecutingTraceItem(insnToExecute);
		StackFrame sf = ti.getTopFrame();
		if (defAtt==null)
			return null;
		
		return null;
	}
		
	public <T> Pair<T> perturbAngelicBranchConditionValue(ThreadInfo ti, StackFrame sf,InstructionInterface insn,Expression<T> symValue,T concVal){		
    if (this.isSuspiciousScope(insn)){    	
    	String varUniqueId = "GUARD_"+InstructionUtil.getUniqueIdString(insn);    	
	    Pair<T> pair = this.getOrCreateAngelicVariable(insn, varUniqueId, ti, sf, symValue, concVal);
    	return pair;
	  }else{
	  	T expectedValue = this.getAngelicValueOfExpression(symValue);
	  	if (!expectedValue.equals(concVal)){
	  		logger.info("Branch decision is not consisten between symbolic and concreate: symb is '"+expectedValue+"' but the conc is '"+concVal+"'");
	  	}
	  	return new Pair<T>(expectedValue, symValue);
	  }
	}

	public <T> Pair<T> perturbAngelicStackOperandReferenceValue(ThreadInfo ti, StackFrame sf,InstructionInterface insn,int stackOffset, Type<T> type){		
		LastModifiedLocationAttribute opDefAtt = ConcolicUtil.peekAttr(sf, 0,type, LastModifiedLocationAttribute.class);
		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(insn,this);
		
		Pair<T> val = ConcolicUtil.peek(sf, type);		
		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
			String varUniqueId = "@PHI@"+InstructionUtil.getUniqueIdString(insn)+"_op"+stackOffset;		
			val = this.getOrCreateSummaryVariablePair(insn, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);
			ConcolicUtil.perturbOperand(sf, stackOffset, val);
		}
		
		Pair<T> updatedAttr = val;
		if (this.isSuspiciousScope(insn)){			
			String varUniqueId = InstructionUtil.getUniqueIdString(insn)+"_op"+stackOffset;
			updatedAttr = this.getOrCreateAngelicVariable(insn,varUniqueId, ti, sf, val.symb, val.conc);
			//perturb stack operand
			ConcolicUtil.perturbOperand(sf, stackOffset, updatedAttr);
		}		
		return updatedAttr;
	}
	
	public <T> Pair<T> perturbAngelicStackOperandValue(ThreadInfo ti, StackFrame sf,InstructionInterface insn,int stackOffset, Type<T> type){		
		LastModifiedLocationAttribute opDefAtt = ConcolicUtil.peekAttr(sf, stackOffset,type, LastModifiedLocationAttribute.class);
		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(insn,this);
		
		Pair<T> val = ConcolicUtil.peek(sf,stackOffset, type);		
		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
			String varUniqueId = "@PHI@"+InstructionUtil.getUniqueIdString(insn)+"_op"+stackOffset;		
			val = this.getOrCreateSummaryVariablePair(insn, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);
			ConcolicUtil.perturbOperand(sf, stackOffset, val);
		}
		
		Pair<T> updatedAttr = val;
		if (this.isSuspiciousScope(insn)){			
			String varUniqueId = InstructionUtil.getUniqueIdString(insn)+"_op"+stackOffset;
			updatedAttr = this.getOrCreateAngelicVariable(insn,varUniqueId, ti, sf, val.symb, val.conc);
			//perturb stack operand
			ConcolicUtil.perturbOperand(sf, stackOffset, updatedAttr);
		}		
		return updatedAttr;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public <T,Instr extends InstructionInterface> Pair analyzePrimaryLocalVarAssignmentExpr(ThreadInfo ti, StackFrame sf, Instr insn,Type<T> type){
		LastModifiedLocationAttribute opDefAtt = ConcolicUtil.peekAttr(sf, 0,type, LastModifiedLocationAttribute.class);
		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(insn,this);
		
		Pair val = ConcolicUtil.peek(sf, type);		
		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
			String varUniqueId = "@PHI@"+InstructionUtil.getUniqueIdString(insn);		
			val = this.getOrCreateSummaryVariablePair(insn, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);
			ConcolicUtil.perturbOperand(sf, 0, val);
		}
		
		Pair updatedAttr = val;
		if (this.isSuspiciousScope(insn)){			
			String varUniqueId = InstructionUtil.getUniqueIdString(insn);
			updatedAttr = this.getOrCreateAngelicVariable(insn,varUniqueId, ti, sf, val.symb, val.conc);
			//perturb stack operand
			ConcolicUtil.perturbOperand(sf, 0, updatedAttr);
		}		
		return updatedAttr;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public <T,Instr extends InstructionInterface> Pair analyzeReferenceLocalVarAssignmentExpr(ThreadInfo ti, StackFrame sf, Instr insn,Type<T> type){
		LastModifiedLocationAttribute opDefAtt = ConcolicUtil.peekAttr(sf, 0,type, LastModifiedLocationAttribute.class);
		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(insn,this);
		
		Pair val = ConcolicUtil.peek(sf, type);		
		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
			String varUniqueId = "@PHI@"+InstructionUtil.getUniqueIdString(insn);		
			val = this.getOrCreateSummaryVariablePair(insn, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);
			ConcolicUtil.perturbOperand(sf, 0, val);
		}
		
		Pair updatedAttr = val;
		if (this.isSuspiciousScope(insn)){			
			String varUniqueId = InstructionUtil.getUniqueIdString(insn);
			updatedAttr = this.getOrCreateAngelicVariable(insn,varUniqueId, ti, sf, val.symb, val.conc);
			//perturb stack operand
			ConcolicUtil.perturbOperand(sf, 0, updatedAttr);
		}		
		return updatedAttr;
	}	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Pair analyzePrimaryReturnValue(ThreadInfo ti, StackFrame sf, JVMReturnInstruction returnInstr){		
		byte typeCode = returnInstr.getMethodInfo().getReturnTypeCode();		
		Type type = ConcolicUtil.forTypeCode(typeCode);
		LastModifiedLocationAttribute opDefAtt = returnInstr.getReturnAttr(ti,LastModifiedLocationAttribute.class);
		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(returnInstr,this);				
		Pair val = ConcolicUtil.peek(sf, type);
		
		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
			String varUniqueId = InstructionUtil.getUniqueIdString(returnInstr);
			varUniqueId = "@PHI@"+varUniqueId;
			val = this.getOrCreateSummaryVariablePair(returnInstr, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);
			ConcolicUtil.perturbOperand(sf, 0, val);
		}
		
		Pair updatedAttr = val;
		if (this.isSuspiciousScope(returnInstr)){			
			String varUniqueId = InstructionUtil.getUniqueIdString(returnInstr);
			updatedAttr = this.getOrCreateAngelicVariable(returnInstr,varUniqueId, ti, sf, val.symb, val.conc);
			//perturb stack operand
			ConcolicUtil.perturbOperand(sf, 0, updatedAttr);
		}
		
		MemoryPerturbator<?> perturbator = null;
		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(this.getCurrentExecutingLocation(), perturbator);
		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, val.symb.getType(), defAtt, LastModifiedLocationAttribute.class);
		return updatedAttr;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Pair analyzeReferenceReturnValue(ThreadInfo ti, StackFrame sf, JVMReturnInstruction returnInstr){		
		byte typeCode = returnInstr.getMethodInfo().getReturnTypeCode();
		
		if (typeCode == Types.T_ARRAY ||typeCode == Types.T_REFERENCE)
			ContractUtils.unreachable("return type is not reference type");
		
		Type type = ConcolicUtil.forTypeCode(typeCode);
		LastModifiedLocationAttribute opDefAtt = returnInstr.getReturnAttr(ti,LastModifiedLocationAttribute.class);
		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(returnInstr,this);				
		Pair val = ConcolicUtil.peek(sf, type);
		
		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
			String varUniqueId = InstructionUtil.getUniqueIdString(returnInstr);
			varUniqueId = "@PHI@"+varUniqueId;
			val = this.getOrCreateSummaryVariablePair(returnInstr, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);
			ConcolicUtil.perturbOperand(sf, 0, val);
		}
		
		Pair updatedAttr = val;
		if (this.isSuspiciousScope(returnInstr)){			
			String varUniqueId = InstructionUtil.getUniqueIdString(returnInstr);
			updatedAttr = this.getOrCreateAngelicVariable(returnInstr,varUniqueId, ti, sf, val.symb, val.conc);
			//perturb stack operand
			ConcolicUtil.perturbOperand(sf, 0, updatedAttr);
		}
		
		MemoryPerturbator<?> perturbator = null;
		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(this.getCurrentExecutingLocation(), perturbator);
		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, val.symb.getType(), defAtt, LastModifiedLocationAttribute.class);
		return updatedAttr;
	}	
	
	public <T> Instruction executeLoadInstruction(ThreadInfo ti, VariableStaticInfo<T> varStaticInfo,LastModifiedLocationAttribute defAtt, InstructionInterface insn) {
		StackFrame sf = ti.getTopFrame();
		if (defAtt==null)
			return null;
		
		Expression<Boolean> pathConstraint = defAtt.getModifiedGualdConstraints(insn,this);
		if (pathConstraint!=null && !ExpressionUtil.isBoolConst(pathConstraint, true)){
			//create phi variable
			MemoryPerturbator<T> perturbator = (MemoryPerturbator<T>) defAtt.getPerturbator();
			
			@SuppressWarnings("unchecked")
			Expression<T> symVal = perturbator.getDynamicAttribute(ti, sf, Expression.class);
			if (symVal!=null && varStaticInfo.isUnknowType()){
				if (!symVal.getType().equals(varStaticInfo.getType())){
					varStaticInfo.setType(symVal.getType());
				}	
			}
			
			T concVal = perturbator.getConcreteValue(ti,sf);
			if (concVal==null)
				concVal = (T)(Object) MJIEnv.NULL;
			else if (concVal instanceof DynamicElementInfo){
				DynamicElementInfo objInfo = (DynamicElementInfo)concVal;
				Object objRef = objInfo.getObjectRef();
				concVal = (T) objRef;
			}
			
			if (symVal==null){
				symVal = Constant.create(varStaticInfo.getType(), concVal);				
			}
			//update program context
			//String varUniqueId = "@PHI@"+varStaticInfo.getVarUniqueId();
			String varUniqueId = "@PHI@"+InstructionUtil.getUniqueIdString(insn);
			Variable<T> newSymbVar = this.constraintsTree.getOrAssignSummaryVariable(varUniqueId,insn,symVal,pathConstraint);		
			//update symbolic state
			this.updateCurrentConcreteValuation(newSymbVar, concVal);			
			perturbator.setDynamicAttribute(ti,sf,Expression.class,newSymbVar);
			
			//update context information
			//MemoryPerturbator<?> perturbator = MemoryPerturbatorFactory.createPerturbator(varStaticInfo,ti,sf);
			//LastModifiedLocationAttribute newDefAtt = new LastModifiedLocationAttribute(this.getCurrentExecutingLocation(),perturbator);
			defAtt.setDefinedLocation(this.getCurrentExecutingLocation());
			//varStaticInfo.setDynamicAttribute(ti, sf,LastModifiedLocationAttribute.class, newDefAtt);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public <T> Instruction perturbVariable(ThreadInfo ti, StackFrame sf, MemoryModifiableInstruction insn,VariableStaticInfo<T> varStaticInfo,MemoryPerturbator<T> perturbator) {
		if (this.isSuspiciousScope(insn)){ //perturb
			//String varUniqueId = varStaticInfo.getVarUniqueId();
			String varUniqueId = InstructionUtil.getUniqueIdString(insn);
			//String varUniqueId = InstructionUtil.getUniqueIdString(insn);
			Expression<T> symValue = perturbator.getDynamicAttribute(ti, sf, Expression.class);
			
			T concVal = perturbator.getConcreteValue(ti,sf);
			
			if (concVal==null)
				concVal = (T)(Object) MJIEnv.NULL;
			else if (concVal instanceof DynamicElementInfo){
				DynamicElementInfo objInfo = (DynamicElementInfo)concVal;
				Object objRef = objInfo.getObjectRef();
				concVal = (T) objRef;
			}

			if (symValue==null){				
				symValue = Constant.create(varStaticInfo.getType(), concVal);				
			}
			AngelicAssignmentData<T> decisionData = this.constraintsTree.getOrCreateAngelicVariableConstraint(insn,varUniqueId,symValue);
			Variable<T> newSymbVar = decisionData.getAngelicVariable();
			//perturb symb value
			perturbator.setSymbolicValue(ti, sf, newSymbVar);
			T agxConcVal;
			if (isAngelicLocation(decisionData)){
				agxConcVal = getAngelicValue(newSymbVar);
				perturbator.setConcreteValue(ti, sf, agxConcVal);
			}else
				agxConcVal = concVal;
			
			this.updateCurrentConcreteValuation(newSymbVar, agxConcVal);			
		}
		return null;	
	}
	
	public <T> void updateCurrentConcreteValuation(Variable<T> symbVar, Object concVal) {
		this.currValuation.setCastedValue(symbVar, concVal);
	}

	private <T> boolean isAngelicLocation(AngelicAssignmentData<T> decisionData) {
		if (this.angelicValuation==null)
			return false;
		
		Variable<T> newSymbVar = decisionData.getAngelicVariable();
		if (this.angelicValuation.containsValueFor(newSymbVar)){
			Variable<Boolean> agxPred =decisionData.getAngelicPredicate();
			return agxPred.evaluate(angelicValuation);			
		}
		return false;
	}
	
	private <T> T getAngelicValue(Variable<T> var) {		
		if (this.angelicValuation.containsValueFor(var)){
			return var.evaluate(angelicValuation);			
		}
		return null;
	}
	
	SymbolicHeap symbolicHeap;
	private SymbolicHeap getSymbolicHeap(ThreadInfo ti, InstructionInterface insn) {		
		ExecutionTraceItem traceItem = this.getCurrentExecutingTraceItem(insn);
		if (symbolicHeap==null)
			symbolicHeap=new SymbolicHeap();
		return symbolicHeap;
	}

	public void createNewObjectInstance(ThreadInfo ti, ElementInfo ei) {		
		//HeapNode n = new ;
		//this.symbolicHeap._add(n );		
	}

	
	boolean firstExecution = true;
	public boolean isFirstExecution(){
		return this.firstExecution;
	}
}
