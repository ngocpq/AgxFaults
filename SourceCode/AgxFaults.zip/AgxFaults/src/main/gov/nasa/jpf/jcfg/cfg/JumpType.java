package gov.nasa.jpf.jcfg.cfg;

public enum JumpType {
  /**
   * A regular control flow edge.
   */
  Normal,

  /**
   * Jump to exception handler (an exception occurred).
   */
  JumpToExceptionHandler,

  /**
   * Jump from try block (not a real jump, as the finally handler executes first).
   */
  LeaveTry,

  /**
   * Jump at the end of a finally block.
   */
  EndFinally
}
