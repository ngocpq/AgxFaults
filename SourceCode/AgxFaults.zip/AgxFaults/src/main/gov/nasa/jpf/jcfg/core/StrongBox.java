package gov.nasa.jpf.jcfg.core;

import gov.nasa.jpf.jcfg.cfg.Block;
import gov.nasa.jpf.jcfg.cfg.util.IStrongBox;

public final class StrongBox<T> implements IStrongBox, Block<T> {
    public T value;

    public StrongBox() {}

    public StrongBox(final T value) {
        this.value = value;
    }

    @Override
    public T get() {
        return this.value;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void set(final Object value) {
        this.value = (T) value;
    }

    @Override
    public void accept(final T input) {
        this.value = input;
    }

    @Override
    public String toString() {
        return "StrongBox{" +
               "value=" + value +
               '}';
    }
}