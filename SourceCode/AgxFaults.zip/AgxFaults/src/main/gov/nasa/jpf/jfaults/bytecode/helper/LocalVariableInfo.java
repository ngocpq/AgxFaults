package gov.nasa.jpf.jfaults.bytecode.helper;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public class LocalVariableInfo<T> extends VariableInfoBase<T>{

	protected LocalVariableInfo(byte typeCode) {
		super(typeCode);
		// TODO Auto-generated constructor stub
	}

	@Override
	public T getConcreteValue(ThreadInfo ti, StackFrame sf) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setConcreteValue(ThreadInfo ti, StackFrame sf, T value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Expression<T> getSymbolicValue(ThreadInfo ti, StackFrame sf) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSymbolicValue(ThreadInfo ti, StackFrame sf, Expression<T> expr) {
		// TODO Auto-generated method stub
		
	}

}
