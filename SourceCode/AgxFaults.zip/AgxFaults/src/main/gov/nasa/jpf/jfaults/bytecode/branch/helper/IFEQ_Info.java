package gov.nasa.jpf.jfaults.bytecode.branch.helper;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.Negation;
import gov.nasa.jpf.constraints.expressions.NumericBooleanExpression;
import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.constraints.NumericCMP;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.vm.StackFrame;

public class IFEQ_Info extends IfBranchInfo {

	public IFEQ_Info(IfInstruction insn, NumericComparator cmp) {
		super(insn, cmp);
	}

	@Override
	public Pair<Boolean> popBranchConditionValue(StackFrame sf) {
		Expression<?> exp = (Expression<?>) sf.getOperandAttr(Expression.class);

		if (exp == null){
			boolean condVal = this.instruction.popConditionValue(sf);
			Constant<Boolean> symVal = Constant.create(BuiltinTypes.BOOL, condVal);
			return new Pair<Boolean>(condVal,symVal); //concolic value
			//return new Pair<Boolean>(this.instruction.popConditionValue(sf), null); // concolic
																					// value
		}
		
		ConcolicUtil.Pair<Integer> pair = ConcolicUtil.popInt(sf);
		/*ConcolicUtil.Pair pair = ConcolicUtil.pop(sf,exp.getType());
		int intVal;
		if (pair.conc instanceof Character)
			intVal = (int)((Character)pair.conc).charValue();*/
		
		boolean sat = cmp.eval(pair.conc);

		Expression<Boolean> symCondition;
		if ((cmp == NumericComparator.EQ || cmp == NumericComparator.NE) && BuiltinTypes.BOOL.equals(exp.getType())) {
			// special case: boolean expressions
			symCondition = exp.requireAs(BuiltinTypes.BOOL);
			int neg = (cmp == NumericComparator.EQ) ? 0 : 1;
			if (neg == 0)
				symCondition = new Negation(symCondition);
			return new Pair<Boolean>(sat, symCondition);
		}

		if (exp instanceof NumericCMP) {
			// in this case we have to turn the cmp together with the ifne into
			// a path condition ...
			NumericCMP ncmp = (NumericCMP) exp;
			symCondition = new NumericBooleanExpression(ncmp.getLeft(), cmp, ncmp.getRight());
			return new Pair<Boolean>(sat, symCondition);
		} 

		// this is really a comparison against 0		
		//Constant<?> zero = Constant.create(exp.getType(), 0);
		Constant<?> zero = Constant.createCasted(exp.getType(), 0);
		symCondition = new NumericBooleanExpression(exp, cmp, zero);
		return new Pair<Boolean>(sat, symCondition);		
	}

	@Override
	public boolean isSymbolicConditionValue(StackFrame sf) {
		Expression<?> symExp = sf.getOperandAttr(Expression.class);
		if (symExp == null) {
			return false;
		}
		// TODO: check constant formula
		if (symExp != null && symExp instanceof Constant)
			return false;
		return true;
	}

}
