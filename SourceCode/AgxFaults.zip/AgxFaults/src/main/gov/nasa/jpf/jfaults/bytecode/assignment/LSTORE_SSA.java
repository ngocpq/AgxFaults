/*
 * Copyright (C) 2014, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 *
 * The Java Pathfinder core (jpf-core) platform is licensed under the
 * Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 *        http://www.apache.org/licenses/LICENSE-2.0. 
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 */
package gov.nasa.jpf.jfaults.bytecode.assignment;
import java.util.ArrayList;
import java.util.List;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.constraints.util.ExpressionUtil;
import gov.nasa.jpf.jcfg.variable.LocalVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.MemoryModifiableInstruction;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.jvm.bytecode.LSTORE;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.LocalVarInfo;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;

/**
 * Store long into local variable ..., value => ...
 */
public class LSTORE_SSA extends LSTORE implements MemoryModifiableInstruction{

	public LSTORE_SSA(int localVarIndex) {
		super(localVarIndex);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Instruction execute (ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
			return super.execute(ti);
		StackFrame sf = ti.getModifiableTopFrame();
		LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getModifiableVariableStaticInfo(this);
		
		Expression symbVal = ConcolicUtil.peekAttr(sf, 0, varStaticInfo.getType(), Expression.class);
		if (varStaticInfo.isUnknowType()&&symbVal!=null)
			varStaticInfo.setType(symbVal.getType());
		
		Type<?> type = varStaticInfo.getType();
		
		analysis.analyzePrimaryLocalVarAssignmentExpr(ti, sf, this, type);
		
		MemoryPerturbator<?> perturbator = new StackLocalVariablePerturbator(sf, varStaticInfo);				
		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, defAtt, LastModifiedLocationAttribute.class);
		
		return super.execute(ti);
	}
	
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public Instruction execute (ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		StackFrame sf = ti.getModifiableTopFrame();		
//		LocalVarInfo varInfo = this.getLocalVarInfo();
//		Type type = ConcolicUtil.forName(varInfo.getType());
//		
//		if (analysis!=null && analysis.isSuspiciousScope(this)){			
//			Pair val = ConcolicUtil.peek(sf, type);			
//			//make angelic variable
//			Variable<?> agxVal = analysis.getOrCreateAngelicSymbolicVariable(this, ti, sf,val.symb,val.conc);
//			
//			//perturb
//			Object agelicValue = analysis.getAngelicValueOfExpression(agxVal);
//			ConcolicUtil.setOperand(sf, 0, type, agelicValue);
//			ConcolicUtil.setOrReplaceOperandAttr(sf, 0,type, agxVal,Expression.class);
//		}
//		
//		StackLocalVariablePerturbator<Integer> perturbator = new StackLocalVariablePerturbator<>(sf, this.index,Types.T_LONG);
//		LastModifiedLocationAttribute attr = new LastModifiedLocationAttribute (analysis.getCurrentExecutingLocation(),null);
//		ConcolicUtil.setOrReplaceOperandAttr(sf, 0,type, attr, LastModifiedLocationAttribute.class);
//    //ConcolicUtil.setOrReplaceLocalAttrInt(sf, index, attr, LastModifiedLocationAttribute.class);
//		Instruction nextInst = super.execute(ti);
//		return nextInst;
//	}

//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public Instruction execute (ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return super.execute(ti);
//		StackFrame sf = ti.getModifiableTopFrame();
//		
//		//get value guard constraint of operands
//		LastModifiedLocationAttribute opDefAtt = sf.getLongOperandAttr(LastModifiedLocationAttribute.class);
//		Expression<Boolean> guardConstraint = opDefAtt.getModifiedGualdConstraints(this,analysis);
//		LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getModifiableVariableStaticInfo(this);
//		
//		Expression symbVal = sf.getLongOperandAttr(Expression.class);
//		if (varStaticInfo.isUnknowType()&&symbVal!=null)
//			varStaticInfo.setType(symbVal.getType());
//		
//		Pair val = ConcolicUtil.peek(sf, varStaticInfo.getType());
//		
//		if (guardConstraint!=null && !ExpressionUtil.isBoolConst(guardConstraint, true)){
//			String varUniqueId = "@PHI@"+varStaticInfo.getVarUniqueId();
//			val = analysis.getOrCreateSummaryVariablePair(this, varUniqueId, ti, sf, val.symb, val.conc, guardConstraint);
//		}
//		
//		Pair updatedAttr = val;
//		if (analysis.isSuspiciousScope(this)){			
//			String varUniqueId = varStaticInfo.getVarUniqueId();
//			updatedAttr = analysis.getOrCreateAngelicVariable(this,varUniqueId, ti, sf, val.symb, val.conc);
//			//perturb stack operand
//			ConcolicUtil.perturbOperand(sf, 0, updatedAttr);			
//		}
//		
//		MemoryPerturbator<?> perturbator = new StackLocalVariablePerturbator(sf, varStaticInfo);				
//		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, val.symb.getType(), defAtt, LastModifiedLocationAttribute.class);
//		
//		return super.execute(ti);
//	}	
	
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public Instruction execute (ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return super.execute(ti);
//		StackFrame sf = ti.getModifiableTopFrame();
//		
//		LocalVariableStaticInfo varStaticInfo = (LocalVariableStaticInfo) VariableStaticInfo.getModifiableVariableStaticInfo(this);		
//		MemoryPerturbator<?> perturbator = new StackLocalVariablePerturbator(sf, varStaticInfo);
//		
//		//get value guard constraint of operands
//		List<LastModifiedLocationAttribute> operandAtt = this.getOperandAttribute(ti,sf,LastModifiedLocationAttribute.class);
//		//evaluate concrete
//		Instruction nextInsn = super.execute(ti);
//		
//		//evaluate symbolic
//		Instruction alternativeInsn = analysis.perturbVariable(ti,sf,this,varStaticInfo,perturbator);
//		
//		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//		perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);
//		
//		if (alternativeInsn!=null)
//			return alternativeInsn;
//		else
//			return nextInsn;
//	}
	
	public <T> List<T> getOperandAttribute(ThreadInfo ti, StackFrame sf, Class<T> attrClazz) {
		List<T> lst = new ArrayList();
		lst.add(sf.getLongOperandAttr(attrClazz));
		return lst;
	}

	@SuppressWarnings("rawtypes")
	public VariableStaticInfo getVariableStaticInfor() {
		MethodInfo mInfo = this.getMethodInfo();
		LocalVarInfo varInfo = this.getLocalVarInfo();
//	LocalVarInfo varInfo = mInfo.getLocalVar(this.index, this.getPosition());
		if (varInfo!=null)
			return new LocalVariableStaticInfo(mInfo, varInfo);
		String varName = this.getVariableId();			
		byte typeCode = Types.T_LONG;
		int slot = this.getLocalVariableIndex();
		return new LocalVariableStaticInfo<Integer>(mInfo,varName,slot,typeCode,false);	
	}
}
