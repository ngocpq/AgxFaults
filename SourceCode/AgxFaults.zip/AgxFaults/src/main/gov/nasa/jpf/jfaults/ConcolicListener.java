/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 * 
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */
package gov.nasa.jpf.jfaults;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import gov.nasa.jpf.Config;
import gov.nasa.jpf.JPF;
import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.IfThenElse;
import gov.nasa.jpf.constraints.expressions.LogicalOperator;
import gov.nasa.jpf.constraints.expressions.PropositionalCompound;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.constraints.util.ExpressionUtil;
import gov.nasa.jpf.jcfg.cfg.OpCode;
import gov.nasa.jpf.jcfg.cfg.StackBehavior;
import gov.nasa.jpf.jcfg.utils.InstructionUtil;
import gov.nasa.jpf.jcfg.utils.SimpleProfiler;
import gov.nasa.jpf.jcfg.variable.MemoryPerturbatorFactory;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.constraints.InternalConstraintsTree;
import gov.nasa.jpf.jfaults.constraints.cfg.AngelicControlFlowGraph;
import gov.nasa.jpf.jfaults.exception.NestingControlDepthExceededException;
import gov.nasa.jpf.jfaults.objects.SymbolicObjectsContext;
import gov.nasa.jpf.jvm.bytecode.GETFIELD;
import gov.nasa.jpf.jvm.bytecode.ILOAD;
import gov.nasa.jpf.jvm.bytecode.JVMReturnInstruction;
import gov.nasa.jpf.listener.Perturbator;
import gov.nasa.jpf.report.Publisher;
import gov.nasa.jpf.search.Search;
import gov.nasa.jpf.util.JPFLogger;
import gov.nasa.jpf.vm.ClassInfo;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.ExceptionInfo;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;
import gov.nasa.jpf.vm.VM;
import gov.nasa.jpf.vm.bytecode.StoreInstruction;
import gov.nasa.jpf.vm.bytecode.WriteInstruction;

/**
 * listener steering concolic execution.
 */
public class ConcolicListener extends Perturbator {
  
  /**
   * logger
   */
  private JPFLogger logger = JPF.getLogger("jdart");
  
  
  public ConcolicListener(Config conf) {
    super(conf);
    logger.finest("ConcolicListener()");
  }


  @Override
  public void propertyViolated(Search search) {
    ThreadInfo ti = search.getVM().getCurrentThread();
    ConcolicMethodExplorer ca = ConcolicMethodExplorer.getCurrentAnalysis(ti);
    if(ca == null)
      return;
    ca.completePathError(ti);
    ti.clearPendingException();
  }
  

  /**
   * Called on exit of a method. If the method is leaving
   * the root frame of the analysis, finish the analysis
   * at this point.
   *  
   */
  @Override
  public void methodExited(VM vm, ThreadInfo ti, MethodInfo mi) {
    ConcolicMethodExplorer ca = ConcolicMethodExplorer.getCurrentAnalysis(ti);
    if(ca == null)
      return;
    
    if(ca.isRootFrame(ti.getTopFrame())) {
      ExceptionInfo pending = ti.getPendingException();
      if(pending != null) {
        // there is a pending exception
        ca.completePathError(ti);
        ti.clearPendingException();
      }
      else {// normal return
        ca.completePathOk(ti);        
      }
      // TODO: currently, this leads to program termination once all paths of our method have been explored.
      //       This is OK in terms of one analysis, but does not allow for multiple concolic analysis.
      ti.breakTransition(true);
    }
    else {
      ca.methodExited(ti, mi);
    }
    
  }


  /* ***************************************************************************
   * 
   * methods used for debugging
   * 
   */
  

  /* (non-Javadoc)
   * @see gov.nasa.jpf.ListenerAdapter#methodEntered(gov.nasa.jpf.vm.VM, gov.nasa.jpf.vm.ThreadInfo, gov.nasa.jpf.vm.MethodInfo)
   */
  @Override
  public void methodEntered(VM vm, ThreadInfo ti,
      MethodInfo mi) {
    ConcolicMethodExplorer ca = ConcolicMethodExplorer.getCurrentAnalysis(ti);
    if(ca == null)
      return;
    ca.methodEntered(ti, mi);
  }



  /*
   * (non-Javadoc)
   * @see gov.nasa.jpf.ListenerAdapter#searchStarted(gov.nasa.jpf.search.Search)
   */
  @Override
  public void searchStarted(Search search) {
    int id = search.getStateId();
    SimpleProfiler.stop("JPF-boot"); // is started in JDart.run()
    logger.finest("ConcolicListener.searchStarted(): " + id);
  }


  /*
   * (non-Javadoc)
   * @see gov.nasa.jpf.ListenerAdapter#searchFinished(gov.nasa.jpf.search.Search)
   */
  @Override
  public void searchFinished(Search search) {
    int id = search.getStateId();
    logger.finest("ConcolicListener.searchFinished(): " + id);
    int methodCount = 0;
    int lineCount = 0;
    for(Entry<MethodInfo, List<Integer>> en:traceHistogram.entrySet()){
    	methodCount++;
    	lineCount+=en.getValue().size();
    }
//    SimpleProfiler.incrCounter(SimpleProfiler.ERROR_TRACE_METHOD_COUNTER);
//    SimpleProfiler.incrCounter(SimpleProfiler.ERROR_TRACE_LINE_DISTINCT_COUNTER);
  }

//
//
//  /* (non-Javadoc)
//   * @see gov.nasa.jpf.listener.Perturbator#classLoaded(gov.nasa.jpf.vm.VM, gov.nasa.jpf.vm.ClassInfo)
//   */
  @Override
  public void classLoaded(VM vm, ClassInfo ci) {
    SymbolicObjectsContext.analyzeStatic(vm, ci);
    super.classLoaded(vm, ci);
  }

  boolean stopForDebugging(){
  	if (count == 26181)
  		return true;
  	return false;
  }

  /* (non-Javadoc)
   * @see gov.nasa.jpf.ListenerAdapter#objectCreated(gov.nasa.jpf.vm.VM, gov.nasa.jpf.vm.ThreadInfo, gov.nasa.jpf.vm.ElementInfo)
   */
  @Override
  public void objectCreated(VM vm, ThreadInfo ti,
      ElementInfo ei) {
  	ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
  	if (analysis!=null){
  		analysis.createNewObjectInstance(ti,ei);
  	}
    SymbolicObjectsContext.analyzeNewInstance(ti, ei);
    super.objectCreated(vm, ti, ei);
  }
  
  
  MethodInfo preMethod=null;
  int preLine=-1;
  
  HashMap<Instruction, Integer> insnHistogram=new HashMap<>(); 
  void addInsnHistogram(Instruction insnToExe){
  	int count;
  	if (insnHistogram.containsKey(insnToExe))
  		count = insnHistogram.get(insnToExe);
  	else{
  		count=0;
  		SimpleProfiler.incrCounter(SimpleProfiler.ERROR_TRACE_INST_DISTINC_COUNTER);    
  	}  		
  	count++;
  	insnHistogram.put(insnToExe, count);
  }
  
  HashMap<MethodInfo, List<Integer>> traceHistogram=new HashMap<>();
  void addToTraceHistogram(Instruction insnToExecute){
  	MethodInfo mInfo = insnToExecute.getMethodInfo();
  	int lineNumber = insnToExecute.getLineNumber();
  	List<Integer> lines = traceHistogram.get(mInfo);
  	if (lines==null){
  		lines = new ArrayList<>();
  		traceHistogram.put(mInfo, lines);
  		SimpleProfiler.incrCounter(SimpleProfiler.ERROR_TRACE_METHOD_COUNTER);      
  	}
  	if (!lines.contains(lineNumber)){
  		lines.add(lineNumber);
  		SimpleProfiler.incrCounter(SimpleProfiler.ERROR_TRACE_LINE_DISTINCT_COUNTER);
  	}
  }
  
  int count=0;
  @Override
  public void executeInstruction(VM vm, ThreadInfo ti, Instruction insnToExecute) {
  	ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null){
			super.executeInstruction(vm, ti, insnToExecute);
			return ;
		}		
		StackFrame sf = ti.getTopFrame();
		count++;
		logger.fine("executing: "+count);
		if (analysis.isFirstExecution() && analysis.isSuspiciousScope(insnToExecute)){			
			SimpleProfiler.incrCounter(SimpleProfiler.ERROR_TRACE_SIZE_INST_COUNTER);
			addInsnHistogram(insnToExecute);
			if (preMethod!=insnToExecute.getMethodInfo() || preLine != insnToExecute.getLineNumber()){
				preMethod= insnToExecute.getMethodInfo();
				preLine = insnToExecute.getLineNumber();
				SimpleProfiler.incrCounter(SimpleProfiler.ERROR_TRACE_SIZE_LINE_COUNTER);
				addToTraceHistogram(insnToExecute);				
			}			
		}
		int debug=0;
		if (count ==2018 || /*count ==54314 ||*/ count ==264)
			debug=1;
//		if (insnToExecute.getLineNumber()==27 /*|| insnToExecute.getLineNumber()==138 ||insnToExecute.getLineNumber()==132*/)
//			System.out.println("Debug");
//		if (InstructionUtil.getDisplayString(insnToExecute).contains("63_3_ifle"))
//			System.out.println("Debug");
		//get executed path id
		//get reach constraint / control dependent constraint
		//get value unchanged constraint:		
		//List<Expression<Boolean>> operatandValueConstraints;		
		
		//if (analysis.getAnalysisConfig().isFaultLocalizationEnabled()){
			//Make summary variables
			//TODO: fix me: Character, Boolean and Integer type operands are not correctly recognized.		
			OpCode code = OpCode.get(insnToExecute.getByteCode());			
			
			int offset=0; 
			byte[] opsTypeCode = InstructionUtil.getStackOperandTypeCode(insnToExecute,ti,sf);
			/*if (opsTypeCode.length>=2)
				System.out.println("Debug");*/
			
			for(int i=0;i<opsTypeCode.length;i++){			
				byte typeCode = opsTypeCode[i];
				int opSize =Types.getTypeSize(typeCode);			
				LastModifiedLocationAttribute defAtt = null;										
				if (opSize==2)					
					defAtt = sf.getOperandAttr(offset+1, LastModifiedLocationAttribute.class);				
				else
					defAtt = sf.getOperandAttr(offset, LastModifiedLocationAttribute.class);
				
				if (defAtt!=null){
					Expression<Boolean> pathConstraint = defAtt.getModifiedGualdConstraints(insnToExecute,analysis);
					if (pathConstraint!=null && !ExpressionUtil.isBoolConst(pathConstraint, true)){
						//get variable's value
						Expression symVal = sf.getOperandAttr(offset, Expression.class);
						Type<?> opType;
						Pair conVal;
						if (symVal!=null){
							opType = symVal.getType();
						}else{							
							if (typeCode == Types.T_VOID){
								logger.fine("warning: operand typeCode is VOID, "+insnToExecute);
								opType = BuiltinTypes.SINT32;
							}else{
								opType=ConcolicUtil.forTypeCode(typeCode);
							}
							
							if (typeCode == Types.T_INT){ //int/byte/char/short???
								//TODO: fix me
								logger.fine("Debug warning: //int/byte/char/short???");			
							}
						}
						conVal = ConcolicUtil.peek(sf, offset, opType);											
						 
						Variable<?> newSymbolVal = analysis.getOrAssignSummaryVariable(insnToExecute,i,ti, sf, conVal.symb,conVal.conc,pathConstraint);					
						
						//perturb value
						ConcolicUtil.setOrReplaceOperandAttr(sf, offset, newSymbolVal.getType(), newSymbolVal, Expression.class);
						
						LastModifiedLocationAttribute defDefAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(),null);
						ConcolicUtil.setOrReplaceOperandAttr(sf, offset, newSymbolVal.getType(), defDefAtt, LastModifiedLocationAttribute.class);
					}
				}
				if (opSize==2)
					offset+=2;
				else
					offset++;
			}
		//}
		/*//========================================
		//perturb operand stack value before store to memory
		if (insnToExecute instanceof StoreInstruction || insnToExecute instanceof WriteInstruction){
			
		}*/
		//========================================
		
		//get operands value definition location
		/*StackFrame sf = ti.getTopFrame();
		LastModifiedLocationAttribute valueDependentLocation = getValueDependentLocations(insnToExecute,ti,sf);*/
		
		if (!ti.isFirstStepInsn()){			
			analysis.executeInstruction(vm,ti,insnToExecute);
		}
		super.executeInstruction(vm, ti, insnToExecute);
		
//		if (analysis!=null){			
//			//loading variable into operator stack => create symmary variable
//			if (isVariableLoadInstruction(insnToExecute)){
//				VariableStaticInfo varStaticInfo = VariableStaticInfo.getVariableStaticInfo(insnToExecute);
//				MemoryPerturbatorFactory.createPerturbator(varStaticInfo, ti, sf,insnToExecute);
//				Instruction nextInsn = analysis.executeLoadInstruction(ti,varStaticInfo, insnToExecute);
//			}
//		}
  }
  
  /*private LastModifiedLocationAttribute getValueDependentLocations(Instruction insnToExecute, ThreadInfo ti,StackFrame sf) {
  	
		int operandCount = InstructionUtil.getStackOperandCount(insnToExecute);
		return null;
	}*/


//	private boolean isVariableLoadInstruction(Instruction insnToExecute) {
//		if (insnToExecute instanceof ILOAD)
//			return true;
//		if (insnToExecute instanceof GETFIELD)
//			return true;
//		return false;
//	}


	@Override
  public void instructionExecuted(VM vm, ThreadInfo ti, Instruction nextInsn, Instruction executedInsn) {
  	ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
  	
		if (analysis==null|| ti.isInstructionSkipped()){
			super.instructionExecuted(vm, ti, nextInsn, executedInsn);
			return;
		}
		StackFrame sf = ti.getTopFrame();		
//		if (stopForDebugging())
//			System.out.println("Debug");
		
//		if (analysis.getAnalysisConfig().isFaultLocalizationEnabled()){			
			// set last modified point of variables		
			OpCode code = OpCode.get(executedInsn.getByteCode());		
			byte[] opsTypeCode = InstructionUtil.getStackPushOperandTypeCode(executedInsn,ti,sf);				
			if (opsTypeCode.length>0){
				LastModifiedLocationAttribute attr = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(),null);
				int offset=0;
				for(int i=0;i<opsTypeCode.length;i++){
					byte typeCode = opsTypeCode[i];
					if (typeCode==Types.T_VOID)
						logger.finest("debug typecode is T_VOID");
					int opSize = Types.getTypeSize(typeCode);
					if (opSize==2)
						offset++;
					
					if (opSize==2){				
						LastModifiedLocationAttribute pre = sf.getLongOperandAttr(LastModifiedLocationAttribute.class);
							if (pre == null)
								sf.addLongOperandAttr(attr);						
					} else {
						if (sf.getTopPos()>=0){
							LastModifiedLocationAttribute pre = sf.getOperandAttr(LastModifiedLocationAttribute.class);
							if (pre == null)
								sf.addOperandAttr(attr);							
						}else
							logger.finest("Debug: stack top position <0");
					}
				}
			}
//		}
		if (!ti.isFirstStepInsn()){			
			try {
				analysis.instructionExecuted(vm,ti,executedInsn,nextInsn);
			} catch (NestingControlDepthExceededException e) {
				ti.createAndThrowException(NestingControlDepthExceededException.class.getName());
				//ti.createAndThrowException(java.lang.UnsupportedOperationException.class.getName());
			}
		}
		super.instructionExecuted(vm, ti, nextInsn, executedInsn);
  }
	
  @Override
  public void stateProcessed(Search search) {
  	//System.out.println("stateProcessed: "+search.getStateId());
  	search.requestBacktrack();
  	super.stateProcessed(search);
  }
  @Override
  public void stateAdvanced(Search search) {
//  	System.out.println("stateAdvanced: "+search.getStateId());
  	super.stateAdvanced(search);
  }  
}
