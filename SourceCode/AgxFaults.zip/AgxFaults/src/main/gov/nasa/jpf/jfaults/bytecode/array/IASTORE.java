package gov.nasa.jpf.jfaults.bytecode.array;

import gov.nasa.jpf.jfaults.bytecode.ExecuteSuperInsntructionHelper;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.ThreadInfo;

public class IASTORE extends gov.nasa.jpf.jvm.bytecode.IASTORE implements ExecuteSuperInsntructionHelper{
	@Override
	public Instruction execute(ThreadInfo ti) {		
		Instruction nextInsn = BytecodeSymbolicArrayHelper.executeArrayStore(ti, this);
		if (nextInsn!=null)
			return nextInsn;
		return super.execute(ti);
	}

	@Override
	public Instruction executeSuper(ThreadInfo ti) {
		return super.execute(ti);
	}
}