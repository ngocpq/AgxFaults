package gov.nasa.jpf.jfaults.bytecode.field;

import java.util.ArrayList;
import java.util.List;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.NumericBooleanExpression;
import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.jcfg.variable.InstanceFieldVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.LocalVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.MemoryModifiableInstruction;
import gov.nasa.jpf.jcfg.variable.StaticFieldVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.LastModifiedLocationAttribute;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.perturb.FieldPerturbator;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jfaults.perturb.StackLocalVariablePerturbator;
import gov.nasa.jpf.jvm.bytecode.PUTFIELD;
import gov.nasa.jpf.jvm.bytecode.PutHelper;
import gov.nasa.jpf.util.InstructionState;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.FieldInfo;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.MJIEnv;
import gov.nasa.jpf.vm.Scheduler;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
public class PUTFIELD_SSA extends PUTFIELD implements MemoryModifiableInstruction {

	public PUTFIELD_SSA(String fieldName, String clsDescriptor, String fieldDescriptor) {
		super(fieldName, clsDescriptor, fieldDescriptor);		
	}
	
	/**
	* Set field in object
	* ..., objectref, value => ...
	* 
	*/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Instruction execute (ThreadInfo ti) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
		if (analysis==null)
			return super.execute(ti);
		StackFrame sf = ti.getModifiableTopFrame();
		int objSlot = this.getObjectSlot(sf);		
		ElementInfo elementInfo = this.getElementInfo(ti);
						
		//check exception
		int objRef = sf.getSlot(objSlot);
		Expression symbRefObj = sf.getSlotAttr(this.getObjectSlot(sf), Expression.class);
		//constraint decision for 'null value exception'
    boolean objIsNull = (objRef == MJIEnv.NULL);
    if(symbRefObj!=null){
    	//make constraint symThis!=0
    	Expression<Boolean>[] constraints = null;
      if(analysis.needsDecisions()) {      	
        constraints = new Expression[2];
        Constant<Integer> zero = Constant.create(BuiltinTypes.SINT32, MJIEnv.NULL);
        constraints[0] = NumericBooleanExpression.create(symbRefObj, NumericComparator.NE, zero);
        constraints[1] = NumericBooleanExpression.create(symbRefObj, NumericComparator.EQ, zero);
      }
      analysis.decisionException(ti, this,NullPointerException.class.getName(), objIsNull ? 1 : 0, constraints);
    }
    
    if (objIsNull)
    	return ti.createAndThrowException("java.lang.NullPointerException", this.getMnemonic()+" access field of a null object");
    //=========	 			
		
		//perturb right-hand-side value
		int valSlot = this.getValueSlot(sf);
		byte typeCode = this.getFieldInfo().getTypeCode();
		Type type = ConcolicUtil.forTypeCode(typeCode);
		Pair updatedPair;
		if (!this.getFieldInfo().isReference() && !this.getFieldInfo().isArrayField()){			
			updatedPair = analysis.perturbAngelicStackOperandValue(ti, sf, this, 0, type);
		}else
			updatedPair = analysis.perturbAngelicStackOperandReferenceValue(ti, sf, this, 0, type);
				
		if(symbRefObj!=null){
			//TODO: update symbolic heap ?!	
			System.out.println("Debug: update symbolic heap of obj: "+symbRefObj);
		}		
		
		InstanceFieldVariableStaticInfo varStaticInfo = new InstanceFieldVariableStaticInfo(fi,elementInfo);
		MemoryPerturbator<?> perturbator = new FieldPerturbator(elementInfo, varStaticInfo);				
		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, defAtt, LastModifiedLocationAttribute.class);
		return super.execute(ti);
	}
	

//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return super.execute(ti);
//		StackFrame sf = ti.getModifiableTopFrame();
//		ElementInfo elementInfo = this.getElementInfo(ti);
//		
//		//TODO: symbolic object
//		/**
//		 * obj.data = value;
//		 * => obj2 = store(obj1, data, value)
//		 */		
//		
//		//StaticFieldVariableStaticInfo varStaticInfo = (StaticFieldVariableStaticInfo) VariableStaticInfo.getModifiableVariableStaticInfo(this);
//		InstanceFieldVariableStaticInfo varStaticInfo = new InstanceFieldVariableStaticInfo(fi,elementInfo);
//		MemoryPerturbator<?> perturbator = new FieldPerturbator(elementInfo, varStaticInfo);
//		
//		//get value guard constraint of operands
//		List<LastModifiedLocationAttribute> operandAtt = this.getOperandAttribute(ti,sf,LastModifiedLocationAttribute.class);
//		//evaluate concrete
//		Instruction nextInsn = super.execute(ti);
//		
//		//evaluate symbolic
//		//Instruction alternativeInsn = analysis.executeAssignmentInstruction(ti,sf,this,operandAtt);
//		Instruction alternativeInsn = analysis.perturbVariable(ti,sf,this,varStaticInfo,perturbator);
//		
//		LastModifiedLocationAttribute defAtt = new LastModifiedLocationAttribute(analysis.getCurrentExecutingLocation(), perturbator);
//		perturbator.setDynamicAttribute(ti, ti.getTopFrame(), LastModifiedLocationAttribute.class, defAtt);
//		
//		if (alternativeInsn!=null)
//			return alternativeInsn;
//		else
//			return nextInsn;
//	}
	
	public <T> List<T> getOperandAttribute(ThreadInfo ti, StackFrame sf, Class<T> attrClazz) {
		List<T> lst = new ArrayList();
		//object instance
		lst.add(sf.getSlotAttr(this.getObjectSlot(sf), attrClazz));
		//assigned value
		lst.add(sf.getSlotAttr(this.getValueSlot(sf), attrClazz));		
		return lst;
	}

	@Override
	public VariableStaticInfo getVariableStaticInfor() {
		return  VariableStaticInfo.getModifiableVariableStaticInfo(this);
	}
	
//	private void perturbStack(ThreadInfo ti, StackFrame sf, ElementInfo elementInfo) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return;
//		FieldInfo fieldInfo = this.getFieldInfo();		
//		Type type = ConcolicUtil.forTypeCode(fieldInfo.getTypeCode());
//		
//		if (analysis.isSuspiciousScope(this)){
//			//peek value
//			Pair pair = ConcolicUtil.peek(sf, type);			
//			
//			//perturb symbolic/memory angelic value
//			Variable<?> agxVal = analysis.getOrCreateAngelicSymbolicVariable(this, ti, sf,pair.symb,pair.conc);
//			Object agxValConc = analysis.getAngelicValueOfExpression(agxVal);
//			
//			//update symbolic/memory state
//			ConcolicUtil.setOperand(sf, 0, type, agxValConc);
//			ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, agxVal,Expression.class);
//		}		
//		LastModifiedLocationAttribute attr = new LastModifiedLocationAttribute( analysis.getCurrentExecutingLocation(),null);
//		ConcolicUtil.setOrReplaceOperandAttr(sf, 0, type, attr,LastModifiedLocationAttribute.class);
//	}
//	
//	/**
//	 * @param frame
//	 * @param eiFieldOwner
//	 */
//	private void updateMemoryValue(StackFrame frame, ElementInfo eiFieldOwner) {
//		int fieldSize = fi.getStorageSize();	        
//	  if (fieldSize == 1){
//	    Object valAttr = frame.getOperandAttr();
//	    int val = frame.peek();
//	    eiFieldOwner.set1SlotField(fi, val);
//	    eiFieldOwner.setFieldAttr(fi, valAttr);
//	    lastValue= val;
//	    
//	  } else {
//	    Object valAttr = frame.getLongOperandAttr();
//	    long val = frame.peekLong();
//	    eiFieldOwner.set2SlotField(fi, val);
//	    eiFieldOwner.setFieldAttr(fi, valAttr);
//	    lastValue= val;
//	  }
//	}
//	
//	@Override
//	public Instruction execute(ThreadInfo ti) {
//		StackFrame frame = ti.getModifiableTopFrame();
//    int objRef = frame.peek( size);
//    lastThis = objRef;
//    
//    if (objRef == MJIEnv.NULL) {
//      return ti.createAndThrowException("java.lang.NullPointerException", "referencing field '" + fname + "' on null object");
//    }
//
//    ElementInfo eiFieldOwner = ti.getModifiableElementInfo(objRef);
//    FieldInfo fieldInfo = getFieldInfo();
//    if (fieldInfo == null) {
//      return ti.createAndThrowException("java.lang.NoSuchFieldError", "no field " + fname + " in " + eiFieldOwner);
//    }
//    
//    //--- check scheduling point due to shared object access
//    Scheduler scheduler = ti.getScheduler();
//    if (scheduler.canHaveSharedObjectCG(ti,this,eiFieldOwner,fieldInfo)){
//      eiFieldOwner = scheduler.updateObjectSharedness( ti, eiFieldOwner, fi);
//      if (scheduler.setsSharedObjectCG( ti, this, eiFieldOwner, fieldInfo)){
//        return this; // re-execute
//      }
//    }
//    
//    // this might be re-executed
//    if (frame.getAndResetFrameAttr(InstructionState.class) == null){
//    	perturbStack(ti,frame,eiFieldOwner);
//    	updateMemoryValue(frame, eiFieldOwner);
//      //lastValue = PutHelper.setField(ti, frame, eiFieldOwner, fieldInfo);
//    }
//    
//    //--- check scheduling point due to exposure through shared object
//    if (isReferenceField()){
//      int refValue = frame.peek();
//      if (refValue != MJIEnv.NULL){
//        ElementInfo eiExposed = ti.getElementInfo(refValue);
//        if (scheduler.setsSharedObjectExposureCG(ti, this, eiFieldOwner, fi, eiExposed)){
//          frame.addFrameAttr( InstructionState.processed);
//          return this; // re-execute AFTER assignment
//        }
//      }
//    }
//    
//    popOperands(frame);      
//    return getNext();
//	}
//
//	/*@Override
//	public Instruction execute(ThreadInfo ti) {
//		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//		if (analysis==null)
//			return super.execute(ti);
//		
//		StackFrame sf = ti.getModifiableTopFrame();
//		ObjectFieldVariableInfo varInfo = (ObjectFieldVariableInfo) this.getModifiedVariableInfo(ti);
//		
//		LastModifiedInstructionMarker lastDefine ;
//		if (this.getFieldSize()>1)
//			lastDefine = sf.getLongOperandAttr(LastModifiedInstructionMarker.class);
//		else
//			lastDefine = sf.getOperandAttr(LastModifiedInstructionMarker.class);
//		
//		Expression<Boolean> pathConstraint=null;
//		if (lastDefine!=null)
//			pathConstraint = lastDefine.getModifiedGualdConstraints(this,analysis); //TODO: lay constrain tu luc modify thoi???
//		
//		Instruction nextInst = super.execute(ti);	
//		
//		SingleAssignement_Helper.ssaFieldPerturb(this, ti,pathConstraint,varInfo);
//		return nextInst;
////		
////		
////		
////		StackFrame sf = ti.getTopFrame();
////		ObjectFieldVariableInfo varInfo = (ObjectFieldVariableInfo) this.getModifiedVariableInfo(ti);
////		LastModifiedInstructionMarker lastDefine = varInfo.getLastModifiedMarker(ti, sf);
////		Expression<Boolean> pathConstraint=null;
////		if (lastDefine!=null)
////			pathConstraint = lastDefine.getModifiedGualdConstraints(this,analysis); //TODO: lay constrain tu luc modify thoi???
////		
////		Instruction nextInst = super.execute(ti);		
////		
////		//make ssa constraint;
////		//SymbolicFieldVariableSSA ssaVar = analysis.createSsaAssignmentFieldVariable(ti,sf,varInfo,this);
////		//SymbolicFieldVariableSSA ssaVar = varInfo.createSsaAssignmentConstraint(ti,sf,analysis);
////		
////		String varId = varInfo.getVarUniqueId();
////		Type<?> type = varInfo.getVariableType();		
////		SymbolicObjectsContext symContext = analysis.getSymbolicContext();
////		Variable<?> var = symContext .createNextSsaVariable(varId, type);
////		//symbolic value
////		Expression symVal = varInfo.getSymbolicValueOfVariable(ti, sf);
////		//concrete value
////		Object conVal = varInfo.getConcolicValueOfVariable(ti, sf);
////		
////		SymbolicFieldVariableSSA ssaVal = new SymbolicFieldVariableSSA(var,varId,null, null, symVal,conVal,insn); 
////		symContext.addStackVarSSA(ssaVal);
////		
////		return nextInst;
//	}*/
	
	
}
