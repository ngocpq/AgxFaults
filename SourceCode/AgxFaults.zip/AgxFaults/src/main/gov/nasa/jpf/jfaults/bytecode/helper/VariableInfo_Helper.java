package gov.nasa.jpf.jfaults.bytecode.helper;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.jcfg.variable.LocalVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.StaticFieldVariableStaticInfo;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.vm.FieldInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.StaticElementInfo;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.bytecode.InstructionInterface;

public class VariableInfo_Helper {
	public static <T> T getDynamicAttributeOfVariable(ThreadInfo ti, StackFrame sf,InstructionInterface executingInsn, VariableStaticInfo<?> vInfo, Class<T> attType){
		if (vInfo instanceof LocalVariableStaticInfo){
			int slotIndex = ((LocalVariableStaticInfo<?>) vInfo).getStackSlotIndex();			
	    return sf.getLocalAttr(slotIndex,attType);    
		}
		
		if (vInfo instanceof StaticFieldVariableStaticInfo){
			FieldInfo fi = ((StaticFieldVariableStaticInfo<?>) vInfo).getFieldInfo();
			StaticElementInfo ei;
			if (fi.isStatic()){
				ei = fi.getClassInfo().getStaticElementInfo();
				return ei.getFieldAttr(fi, attType);
			}
			//dynamic heap: get element for
			//TODO:
			System.out.println("getDynamicAttributeOfVariable() unimplemented for Instance Field");
		}
		//return vInfo.getDynamicAttribute(ti,sf,attType);
		return null;
	}
}
