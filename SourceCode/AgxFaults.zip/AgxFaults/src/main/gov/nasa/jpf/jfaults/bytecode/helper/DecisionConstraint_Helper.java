/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 * 
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */
package gov.nasa.jpf.jfaults.bytecode.helper;

import gov.nasa.jpf.JPF;
import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.ConcolicUtil.Pair;
import gov.nasa.jpf.jfaults.bytecode.TABLESWITCH;
import gov.nasa.jpf.jfaults.bytecode.branch.IFEQ;
import gov.nasa.jpf.jfaults.bytecode.branch.IFGE;
import gov.nasa.jpf.jfaults.bytecode.branch.IFGT;
import gov.nasa.jpf.jfaults.bytecode.branch.IFLE;
import gov.nasa.jpf.jfaults.bytecode.branch.IFLT;
import gov.nasa.jpf.jfaults.bytecode.branch.IFNE;
import gov.nasa.jpf.jfaults.bytecode.branch.IFNONNULL;
import gov.nasa.jpf.jfaults.bytecode.branch.IFNULL;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPEQ;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPGE;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPGT;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPLE;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPLT;
import gov.nasa.jpf.jfaults.bytecode.branch.IF_ICMPNE;
import gov.nasa.jpf.jfaults.bytecode.branch.LOOKUPSWITCH;
import gov.nasa.jpf.jfaults.bytecode.branch.helper.BranchVariableInfo;
import gov.nasa.jpf.jfaults.bytecode.branch.helper.IFEQ_Info;
import gov.nasa.jpf.jfaults.bytecode.branch.helper.IFNULL_Info;
import gov.nasa.jpf.jfaults.bytecode.branch.helper.IF_ICMPInfo;
import gov.nasa.jpf.jfaults.bytecode.branch.helper.SwitchInfo;
import gov.nasa.jpf.jvm.bytecode.IF_ACMPEQ;
import gov.nasa.jpf.jvm.bytecode.IF_ACMPNE;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.jvm.bytecode.SwitchInstruction;
import gov.nasa.jpf.util.JPFLogger;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.bytecode.InstructionInterface;

public abstract class DecisionConstraint_Helper {
	private static JPFLogger logger = JPF.getLogger("jdart");
	
//	public static SymbolicVariable createSymbolicVariable(InstructionInterface insn, String varName ) {
//		if (insn instanceof JVMLocalVariableInstruction){
//			SymbolicParam localVar
//			byte typeCode = getVariableTypeCode(insn);
//			Type type = ConcolicUtil.forTypeCode(typeCode);
//		}
//	}
//
//	private static byte getVariableTypeCode(InstructionInterface insn) {
//		//JVMLocalVariableInstruction
//		if (insn instanceof ALOAD || insn instanceof ASTORE)
//			return Types.T_REFERENCE;
//		if (insn instanceof DLOAD || insn instanceof DSTORE)
//			return Types.T_DOUBLE;
//		if (insn instanceof FLOAD || insn instanceof FSTORE)
//			return Types.T_FLOAT;
//		if (insn instanceof ILOAD || insn instanceof ISTORE)
//			return Types.T_INT;
//		if (insn instanceof LLOAD || insn instanceof LSTORE)
//			return Types.T_LONG;		
//		
//		//JVMLocalVariableInstruction
//		if (insn instanceof JVMReturnInstruction){
//			return insn.getMethodInfo().getReturnTypeCode();
//		}
//		
//		//array
//		
//		
//		throw new JPFException("unsupported instruction type: " + insn);
//	}
	
  @SuppressWarnings("rawtypes")
	public static BranchVariableInfo getBranchVariableInforHelper(InstructionInterface insn, ThreadInfo ti) {
		if (insn instanceof IF_ACMPEQ)
			return new IF_ICMPInfo((IfInstruction) insn, NumericComparator.EQ);
		if (insn instanceof IF_ACMPNE)
			return new IF_ICMPInfo((IfInstruction) insn, NumericComparator.NE);
		
		if (insn instanceof IF_ICMPEQ)
			return new IF_ICMPInfo((IfInstruction) insn,NumericComparator.EQ);
		if (insn instanceof IF_ICMPNE)
			return new IF_ICMPInfo((IfInstruction) insn,NumericComparator.NE);
		
		if (insn instanceof IF_ICMPGE)
			return new IF_ICMPInfo((IfInstruction) insn,NumericComparator.GE);
		if (insn instanceof IF_ICMPGT)
			return new IF_ICMPInfo((IfInstruction) insn,NumericComparator.GT);
		if (insn instanceof IF_ICMPLE)
			return new IF_ICMPInfo((IfInstruction) insn,NumericComparator.LE);
		if (insn instanceof IF_ICMPLT)
			return new IF_ICMPInfo((IfInstruction) insn,NumericComparator.LT);
		
		if (insn instanceof IFEQ)
			return new IFEQ_Info((IfInstruction) insn, NumericComparator.EQ);
		if (insn instanceof IFNE)
			return new IFEQ_Info((IfInstruction) insn, NumericComparator.NE);
		
		if (insn instanceof IFGE)
			return new IFEQ_Info((IfInstruction) insn, NumericComparator.GE);
		if (insn instanceof IFGT)
			return new IFEQ_Info((IfInstruction) insn, NumericComparator.GT);
		if (insn instanceof IFLE)
			return new IFEQ_Info((IfInstruction) insn, NumericComparator.LE);
		if (insn instanceof IFLT)
			return new IFEQ_Info((IfInstruction) insn, NumericComparator.LT);
		
		if (insn instanceof IFNULL)
			return new IFNULL_Info((IfInstruction) insn, NumericComparator.EQ);
		if (insn instanceof IFNONNULL)
			return new IFNULL_Info((IfInstruction) insn, NumericComparator.NE);
		
		if (insn instanceof LOOKUPSWITCH)
			return new SwitchInfo((SwitchInstruction) insn);	
		if (insn instanceof TABLESWITCH)
			return new SwitchInfo((SwitchInstruction) insn);	
		
		return null;
	}
  
  @SuppressWarnings("unchecked")
	public static <T> Instruction executeBranch(ThreadInfo ti, InstructionInterface insn) {
	    ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
	    if(analysis == null)
	      return null;	     	    	    	    
	    	
	    BranchVariableInfo<T> branchInfo = getBranchVariableInforHelper(insn,ti);
	    
	    StackFrame sf = ti.getModifiableTopFrame();
	    boolean inAngelicScope = analysis.isSuspiciousScope(insn); 
	    boolean containSymbol = branchInfo.isSymbolicConditionValue(sf); 
	    if (!inAngelicScope && !containSymbol)
	    	return null;	//no symbol value && not in analysis scope
	    	    
	    Pair<T> val = branchInfo.popBranchConditionValue(sf);
	    Pair<T> agxPair = analysis.perturbAngelicBranchConditionValue(ti, sf, insn, val.symb, val.conc);
	    
	    Expression<Boolean>[] decisionExprs = null;
	    if(analysis.needsDecisions()) {	    	
		    decisionExprs = branchInfo.buildDecisions(agxPair.symb);    	  
	    }else{
	    	//TODO: check consistance	    	
	    }
	    
	    int selectedBranchIdx = branchInfo.getTargetBranchIndex(agxPair.conc);	    
	    analysis.decisionControlFlow(ti, insn, selectedBranchIdx,decisionExprs);	    
	    return branchInfo.getTargetPC(selectedBranchIdx);	    
  }
  
  
  
//public static Instruction executeBranch(ThreadInfo ti, InstructionInterface insn) {
//	    ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(ti);
//	    if(analysis == null)
//	      return null;	     
//	    
//	    BranchVariableInfo<?> branchInfo = getBranchVariableInforHelper(insn,ti);
//	    
//	    StackFrame sf = ti.getModifiableTopFrame();
//	    if(!branchInfo.isSymbolicConditionValue(sf)){
//	    	if (!analysis.isSuspiciousScope(insn))
//	    		return null;	    	
//	    }
//	    
//	    int selectedBranchIdx =analysis.makeBranchingDecision(ti,sf,insn,branchInfo);
//	    return branchInfo.getTargetPC(selectedBranchIdx);	    
//  }

//	public static int makeBranchingDecision(ConcolicMethodExplorer analysis,ThreadInfo ti,StackFrame sf, InstructionInterface insn, BranchVariableInfo branchInfo) {
//		Pair<?> val = branchInfo.popBranchConditionValue(sf);
//		
//    int symbBranch = branchInfo.getTargetBranchIndex(val.conc);   
//    Expression<Boolean>[] decisionExprs = null;    	        
//    if(analysis.needsDecisions()) {      
//    	  decisionExprs = branchInfo.buildDecisions(val.symb);	      
//    }
//    
//    //TODO: perturb to angelic decision branch
//    
//    analysis.decision(ti, insn, symbBranch,decisionExprs);
//    //branchInfo.setSelectedBranch(symbBranch);
//    return symbBranch;	
//	}
}
