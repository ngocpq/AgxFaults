package gov.nasa.jpf.jcfg.componentmodel;
//package gov.nasa.jpf.jdart.componentmodel;
//
//public interface UserDataStore {
//    <T> T getUserData(final Key<T> key);
//    <T> void putUserData(final Key<T> key, final T value);
//    <T> T putUserDataIfAbsent(final Key<T> key, final T value);
//    <T> boolean replace(final Key<T> key, final T oldValue, final T newValue);
//}
//
