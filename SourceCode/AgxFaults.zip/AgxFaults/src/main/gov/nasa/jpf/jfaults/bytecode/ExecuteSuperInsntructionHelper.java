package gov.nasa.jpf.jfaults.bytecode;

import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.bytecode.InstructionInterface;

public interface ExecuteSuperInsntructionHelper extends InstructionInterface{
	Instruction executeSuper(ThreadInfo ti);
}
