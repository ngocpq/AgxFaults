package gov.nasa.jpf.jcfg.cfg;

import static java.lang.String.format;

import gov.nasa.jpf.jcfg.cfg.wrap.ExceptionHandlerWrapper;
import gov.nasa.jpf.vm.Instruction;

public class DecompilerHelpers {
	
	public static void writeType(final ITextOutput writer, final String type) {
        writer.write("Type: "+type);
    }

	public static void writeInstruction(final ITextOutput writer, final Instruction instruction) {
		writer.writeDefinition(offsetToString(instruction.getPosition()), instruction);
		writer.write(": ");
		writer.write(instruction.toString());
	}

	public static String offsetToString(final int offset) {
		return format("#%1$04d", offset);
	}

	public static void writeOffsetReference(final ITextOutput writer, final Instruction instruction) {
		VerifyArgument.notNull(writer, "writer");

		writer.writeLabel(offsetToString(instruction.getPosition()));
	}

	public static void writeEndOffsetReference(final ITextOutput writer, final Instruction instruction) {
		VerifyArgument.notNull(writer, "writer");

		writer.writeLabel(offsetToString(instruction.getPosition()+instruction.getLength()));
	}

	public static void writeExceptionHandler(PlainTextOutput output, ExceptionHandlerWrapper handler) {
		VerifyArgument.notNull(output, "output");
		VerifyArgument.notNull(handler, "handler");

		output.write("Try ");
		writeOffsetReference(output, handler.getTryBlock().getFirstInstruction());
		output.write(" - ");
		writeEndOffsetReference(output, handler.getTryBlock().getLastInstruction());
		output.write(' ');
		output.write(String.valueOf(handler.getHandlerType()));

		final String catchType = handler.getCatchType();

		if (catchType != null) {
			output.write(' ');
			writeType(output, catchType);
		}

		final InstructionBlock handlerBlock = handler.getHandlerBlock();

		output.write(' ');
		writeOffsetReference(output, handlerBlock.getFirstInstruction());

		if (handlerBlock.getLastInstruction() != null) {
			output.write(" - ");
			writeEndOffsetReference(output, handlerBlock.getLastInstruction());
		}
	}
}
