package gov.nasa.jpf.jcfg.cfg;
import gov.nasa.jpf.vm.Types;

public enum StackBehavior {
  Pop0,
  Pop1(Types.T_VOID),
  Pop2(Types.T_VOID,Types.T_VOID),
  Pop1_Pop1(Types.T_VOID,Types.T_VOID),
  Pop1_Pop2(Types.T_VOID,Types.T_VOID,Types.T_VOID),
  Pop1_PopA(Types.T_VOID,Types.T_REFERENCE),
  Pop2_Pop1(Types.T_VOID,Types.T_VOID,Types.T_VOID),
  Pop2_Pop2(Types.T_VOID,Types.T_VOID,Types.T_VOID,Types.T_VOID),
  PopI4(Types.T_INT),
  PopI8(Types.T_LONG),
  PopR4(Types.T_FLOAT),
  PopR8(Types.T_DOUBLE),
  PopA(Types.T_REFERENCE),
  PopI4_PopI4(Types.T_INT,Types.T_INT),
  PopI4_PopI8(Types.T_INT,Types.T_LONG),
  PopI8_PopI8(Types.T_LONG,Types.T_LONG),
  PopR4_PopR4(Types.T_FLOAT,Types.T_FLOAT),
  PopR8_PopR8(Types.T_DOUBLE,Types.T_DOUBLE),
  PopI4_PopA(Types.T_INT,Types.T_REFERENCE),
  PopI4_PopI4_PopA(Types.T_INT,Types.T_INT,Types.T_REFERENCE),
  PopI8_PopI4_PopA(Types.T_LONG,Types.T_INT,Types.T_REFERENCE),
  PopR4_PopI4_PopA(Types.T_FLOAT,Types.T_INT,Types.T_REFERENCE),
  PopR8_PopI4_PopA(Types.T_DOUBLE,Types.T_INT,Types.T_REFERENCE),
  PopA_PopI4_PopA(Types.T_REFERENCE,Types.T_INT,Types.T_REFERENCE),
  PopA_PopA(Types.T_REFERENCE,Types.T_REFERENCE),
  Push0,
  Push1(Types.T_VOID),
  Push1_Push1(Types.T_VOID,Types.T_VOID),
  Push1_Push1_Push1(Types.T_VOID,Types.T_VOID,Types.T_VOID),
  Push1_Push2_Push1(Types.T_VOID,Types.T_VOID,Types.T_VOID,Types.T_VOID),
  Push2(Types.T_VOID,Types.T_VOID),
  Push2_Push2(Types.T_VOID,Types.T_VOID,Types.T_VOID,Types.T_VOID),
  Push2_Push1_Push2(Types.T_VOID,Types.T_VOID,Types.T_VOID,Types.T_VOID,Types.T_VOID),
  Push2_Push2_Push2(Types.T_VOID,Types.T_VOID,Types.T_VOID,Types.T_VOID,Types.T_VOID,Types.T_VOID),
  PushI4(Types.T_INT),
  PushI8(Types.T_LONG),
  PushR4(Types.T_FLOAT),
  PushR8(Types.T_DOUBLE),
  PushA(Types.T_REFERENCE),
  PushAddress(Types.T_VOID),
  VarPop,
  VarPush;

	private StackBehavior(byte ... operandTypes){
		if (operandTypes==null||operandTypes.length==0){
			this._count = 0;
			//this._operandSize = null;
			this._operandType=null;
		}else{
			this._count = operandTypes.length;
			this._operandType = operandTypes;
			
		}
	}
	private final int _count;
	//private final int[] _operandSize;
	private final byte[] _operandType;
	public int getOperandCount(){
		return _count;
	}
	public byte getOperandTypeCode(int idx){
		return _operandType[idx];
	}
}

/*import gov.nasa.jpf.vm.Types;


public enum StackBehavior {
	  Pop0,
	  Pop1(Types.T_NONE),
	  Pop2(-1,-1),
	  Pop1_Pop1(-1,-1),
	  Pop1_Pop2(-1,-1,-1),
	  Pop1_PopA(-1,1),
	  Pop2_Pop1(-1,-1,-1),
	  Pop2_Pop2(-1,-1,-1,-1),
	  PopI4(Types.T_INT),
	  PopI8(2),
	  PopR4(1),
	  PopR8(2),
	  PopA(1),
	  PopI4_PopI4(1,1),
	  PopI4_PopI8(1,2),
	  PopI8_PopI8(2,2),
	  PopR4_PopR4(1,1),
	  PopR8_PopR8(2,2),
	  PopI4_PopA(1,1),
	  PopI4_PopI4_PopA(1,1,1),
	  PopI8_PopI4_PopA(2,1,1),
	  PopR4_PopI4_PopA(1,1,1),
	  PopR8_PopI4_PopA(2,1,1),
	  PopA_PopI4_PopA(1,1,1),
	  PopA_PopA(1,1),
	  Push0,
	  Push1(-1),
	  Push1_Push1(-1,-1),
	  Push1_Push1_Push1(-1,-1,-1),
	  Push1_Push2_Push1(-1,-1,-1,-1),
	  Push2(-1,-1),
	  Push2_Push2(-1,-1,-1,-1),
	  Push2_Push1_Push2(-1,-1,-1,-1,-1),
	  Push2_Push2_Push2(-1,-1,-1,-1,-1,-1),
	  PushI4(1),
	  PushI8(2),
	  PushR4(1),
	  PushR8(2),
	  PushA(1),
	  PushAddress(1),
	  VarPop,
	  VarPush;

		private StackBehavior(byte ... operandType){
			if (operandType==null||operandType.length==0){
				this._count = 0;
				this._operandType = null;
			}else{
				this._count = operandType.length;
				this._operandType = operandType;
			}
		}
		private final int _count;
		private final byte[] _operandType;
		public int getOperandCount(){
			return _count;
		}
		public int getOperandType(int idx){
			return _operandType[idx];
		}
	}*/

/*public enum StackBehavior {
  Pop0,
  Pop1(-1),
  Pop2(-1,-1),
  Pop1_Pop1(-1,-1),
  Pop1_Pop2(-1,-1,-1),
  Pop1_PopA(-1,1),
  Pop2_Pop1(-1,-1,-1),
  Pop2_Pop2(-1,-1,-1,-1),
  PopI4(1),
  PopI8(2),
  PopR4(1),
  PopR8(2),
  PopA(1),
  PopI4_PopI4(1,1),
  PopI4_PopI8(1,2),
  PopI8_PopI8(2,2),
  PopR4_PopR4(1,1),
  PopR8_PopR8(2,2),
  PopI4_PopA(1,1),
  PopI4_PopI4_PopA(1,1,1),
  PopI8_PopI4_PopA(2,1,1),
  PopR4_PopI4_PopA(1,1,1),
  PopR8_PopI4_PopA(2,1,1),
  PopA_PopI4_PopA(1,1,1),
  PopA_PopA(1,1),
  Push0,
  Push1(-1),
  Push1_Push1(-1,-1),
  Push1_Push1_Push1(-1,-1,-1),
  Push1_Push2_Push1(-1,-1,-1,-1),
  Push2(-1,-1),
  Push2_Push2(-1,-1,-1,-1),
  Push2_Push1_Push2(-1,-1,-1,-1,-1),
  Push2_Push2_Push2(-1,-1,-1,-1,-1,-1),
  PushI4(1),
  PushI8(2),
  PushR4(1),
  PushR8(2),
  PushA(1),
  PushAddress(1),
  VarPop,
  VarPush;

	private StackBehavior(int ... operandSize){
		if (operandSize==null||operandSize.length==0){
			this._count = 0;
			this._operandSize = null;
		}else{
			this._count = operandSize.length;
			this._operandSize = operandSize;
		}
	}
	private final int _count;
	private final int[] _operandSize;
	public int getOperandCount(){
		return _count;
	}
	public int getOperandSize(int idx){
		return _operandSize[idx];
	}
}*/
