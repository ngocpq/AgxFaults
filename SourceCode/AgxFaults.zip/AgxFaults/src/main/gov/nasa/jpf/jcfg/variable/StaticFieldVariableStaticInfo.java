package gov.nasa.jpf.jcfg.variable;
import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.jfaults.ConcolicUtil;
import gov.nasa.jpf.jfaults.perturb.FieldPerturbator;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.vm.ElementInfo;
import gov.nasa.jpf.vm.FieldInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;

public class StaticFieldVariableStaticInfo<T> implements VariableStaticInfo<T>{
	final FieldInfo fieldInfo;
	//ElementInfo elementInfo;
	//final String varUniqueId;
	private final Type<T> type;
	@SuppressWarnings("unchecked")
	public StaticFieldVariableStaticInfo(FieldInfo fInfo){
		this.fieldInfo = fInfo;
//		if (fInfo.isStatic())
//			this.elementInfo = fInfo.getClassInfo().getStaticElementInfo();
//		else
//			this.elementInfo =null;
		this.type = (Type<T>) ConcolicUtil.forTypeCode(this.fieldInfo.getTypeCode());		
	}
	
	public FieldInfo getFieldInfo(){
		return this.fieldInfo;
	}
	
	@Override
	public String getVarUniqueId() {
		return fieldInfo.getClassInfo().getName()+"."+ fieldInfo.getName();
	}
	@Override
	public byte getTypeCode() {
		return fieldInfo.getTypeCode();
	}
	
	@Override
	public Type<T> getType() {
		return this.type;
	}
	
	@Override
	public void setType(Type<T> type) {
		throw new UnsupportedOperationException("unsupported operation");
	}
	@Override
	public boolean isUnknowType() {
		return false;
	}	
	
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof StaticFieldVariableStaticInfo))
			return false;
		@SuppressWarnings("rawtypes")
		StaticFieldVariableStaticInfo<T> other = (StaticFieldVariableStaticInfo) obj;
		if (this.getVarUniqueId().equals(other.getVarUniqueId()))
			return false;
		if (this.getTypeCode() != other.getTypeCode())
			return false;
		return true;
	}
	
	@Override
	public int hashCode() {
		return (this.getVarUniqueId()+"_"+this.getTypeCode()).hashCode();
	}
	
	@Override
	public String toString() {			
		return this.getVarUniqueId()+"_"+this.getTypeCode();
	}


//	@Override
//	public <E> void setDynamicAttribute(ThreadInfo ti, StackFrame sf, Class<E> attrType, E attValue) {
//		elementInfo.defreeze();
//    E oldAttr = elementInfo.getFieldAttr(fieldInfo, attrType);
//    if (oldAttr==null)
//    	elementInfo.addFieldAttr(fieldInfo, attValue);
//    else
//    	elementInfo.replaceFieldAttr(fieldInfo, oldAttr , attValue);
//    //elementInfo.freeze();    
//	}
//	
//	@Override
//	public <E> E getDynamicAttribute(ThreadInfo ti, StackFrame sf, Class<E> attrType) {
//		return elementInfo.getFieldAttr(fieldInfo, attrType);			
//	}
//
//	@Override
//	public T getConcreteValue(ThreadInfo ti, StackFrame sf) {
//		T value = (T) elementInfo.getFieldValueObject(fieldInfo.getName());
//		return value;
//	}
//
//	@Override
//	public void setConcreteValue(ThreadInfo ti, StackFrame sf, T value) {
//		elementInfo.defreeze();		
//    ConcolicUtil.setField(elementInfo, fieldInfo, type, value);
//	}
//
//	@Override
//	public MemoryPerturbator<T> getPerturbator(ThreadInfo ti, StackFrame sf) {
//		return new FieldPerturbator<T>(this.elementInfo,this.fieldInfo);
//	}
//
//	@Override
//	public void setSymbolicValue(ThreadInfo ti, StackFrame sf, Expression<T> newSymbVar) {
//		setDynamicAttribute(ti, sf, Expression.class, newSymbVar);
//	}
	
	
}
