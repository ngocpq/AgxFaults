/*
 * Copyright (C) 2014, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 *
 * Symbolic Pathfinder (jpf-symbc) is licensed under the Apache License, 
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 *        http://www.apache.org/licenses/LICENSE-2.0. 
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 */
package gov.nasa.jpf.jfaults.bytecode.invoke;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.NumericBooleanExpression;
import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jfaults.ConcolicMethodExplorer;
import gov.nasa.jpf.jfaults.bytecode.helper.BytecodeInvokeHelper;
import gov.nasa.jpf.vm.ClassInfo;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.MJIEnv;
import gov.nasa.jpf.vm.ThreadInfo;

// need to fix names

public class INVOKEVIRTUAL extends gov.nasa.jpf.jvm.bytecode.INVOKEVIRTUAL {
	public INVOKEVIRTUAL(String clsName, String methodName, String methodSignature) {
		super(clsName, methodName, methodSignature);
	}

	@Override
	public Instruction execute(ThreadInfo th) {
		ConcolicMethodExplorer analysis = ConcolicMethodExplorer.getCurrentAnalysis(th);
    if(analysis == null)
      return super.execute(th);    
		
    StackFrame sf = th.getTopFrame();
    int objRef = this.getCalleeThis(th);//th.getCalleeThis(getArgSize());
    
    //get symbolic heap index:
    int calleeOpIndex = this.getObjectSlot(sf);
    int i = getArgSize()-1;
    calleeOpIndex= sf.getTopPos() - i;
    if (calleeOpIndex < 0){
    	calleeOpIndex = MJIEnv.NULL;
    	ContractUtils.unreachable("unreachable state");
    }
    Expression<?> symThisHeapIndex = sf.getSlotAttr(calleeOpIndex, Expression.class);
    
    if (symThisHeapIndex!=null){
    	//make constraint symThis!=0
    	Expression<Boolean>[] constraints = null;
      if(analysis.needsDecisions()) {
        constraints = new Expression[2];
        Constant<Integer> zero = Constant.create(BuiltinTypes.SINT32, MJIEnv.NULL);
        constraints[0] = NumericBooleanExpression.create(symThisHeapIndex, NumericComparator.NE, zero);
        constraints[1] = NumericBooleanExpression.create(symThisHeapIndex, NumericComparator.EQ, zero);
      }
      analysis.decisionException(th, this,NullPointerException.class.getName(), (objRef != MJIEnv.NULL) ? 0 : 1, constraints);
    }
    
		if (objRef == MJIEnv.NULL) {
      lastObj = -1;
      return th.createAndThrowException("java.lang.NullPointerException", "Calling '" + mname + "' on null object");
    }

    MethodInfo mi = getInvokedMethod(th, objRef);

    if (mi == null) {
      ClassInfo ci = th.getClassInfo(objRef);
      String clsName = (ci != null) ? ci.getName() : "?UNKNOWN?";
      return th.createAndThrowException("java.lang.NoSuchMethodError", clsName + '.' + mname);
    }
    
    
		Instruction nextInstr = BytecodeInvokeHelper.executeInstanceInvocation(objRef, this, th);
		if (nextInstr == null) {
			return super.execute(th);
		}
		return nextInstr;
	}
}
