package gov.nasa.jpf.jcfg.utils;

import gov.nasa.jpf.JPF;
import gov.nasa.jpf.util.JPFLogger;

public class LoggerUtil {

	public static JPFLogger getCFGLogger() {
		return JPF.getLogger("jcfg");
	}

	public static void writeWarning(String msg) {
		JPF.getLogger("jcfg").info(msg);
	}

}
