package gov.nasa.jpf.jcfg.variable;

import gov.nasa.jpf.JPFException;
import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.jcfg.StaticAnalysisUtility;
import gov.nasa.jpf.jfaults.perturb.MemoryPerturbator;
import gov.nasa.jpf.jvm.bytecode.ALOAD;
import gov.nasa.jpf.jvm.bytecode.ASTORE;
import gov.nasa.jpf.jvm.bytecode.ArrayStoreInstruction;
import gov.nasa.jpf.jvm.bytecode.DLOAD;
import gov.nasa.jpf.jvm.bytecode.DSTORE;
import gov.nasa.jpf.jvm.bytecode.FLOAD;
import gov.nasa.jpf.jvm.bytecode.FSTORE;
import gov.nasa.jpf.jvm.bytecode.IINC;
import gov.nasa.jpf.jvm.bytecode.ILOAD;
import gov.nasa.jpf.jvm.bytecode.ISTORE;
import gov.nasa.jpf.jvm.bytecode.JVMArrayElementInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMInvokeInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMLocalVariableInstruction;
import gov.nasa.jpf.jvm.bytecode.JVMReturnInstruction;
import gov.nasa.jpf.jvm.bytecode.LLOAD;
import gov.nasa.jpf.jvm.bytecode.LSTORE;
import gov.nasa.jpf.vm.FieldInfo;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.LocalVarInfo;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.StackFrame;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.Types;
import gov.nasa.jpf.vm.bytecode.FieldInstruction;
import gov.nasa.jpf.vm.bytecode.StoreInstruction;
import gov.nasa.jpf.vm.bytecode.WriteInstruction;

public interface VariableStaticInfo<T> {
	String getVarUniqueId();
	byte getTypeCode();
	Type<T> getType();	
	
//	<E> void setDynamicAttribute(ThreadInfo ti, StackFrame sf,Class<E> attrType,E attValue);
//	<E> E getDynamicAttribute(ThreadInfo ti, StackFrame sf, Class<E> attrType);
//	MemoryPerturbator<T> getPerturbator(ThreadInfo ti, StackFrame sf);
//	
//	void setSymbolicValue(ThreadInfo ti, StackFrame sf, Expression<T> newSymbVar);
//	T getConcreteValue(ThreadInfo ti, StackFrame sf);
//	void setConcreteValue(ThreadInfo ti, StackFrame sf,T value);
	
	void setType(Type<T> type);
	boolean isUnknowType();
	
	public static <T> VariableStaticInfo<T> getVariableStaticInfo(Instruction insn){		
		if (insn instanceof IINC){
			IINC inc = (IINC)insn;
			MethodInfo mInfo = insn.getMethodInfo();
			LocalVarInfo varInfo = inc.getMethodInfo().getLocalVar(inc.getIndex(), inc.getPosition());
			if (varInfo!=null)
				return new LocalVariableStaticInfo<T>(mInfo, varInfo);				
			String varName = "null"+inc.getIndex();			
			byte typeCode = Types.T_INT;
			int slot = inc.getIndex();
			return new LocalVariableStaticInfo<T>(mInfo,varName,slot,typeCode,false);						
		}else if (insn instanceof JVMLocalVariableInstruction){
				JVMLocalVariableInstruction localInsn = (JVMLocalVariableInstruction)insn;
				MethodInfo mInfo = localInsn.getMethodInfo();
				JVMLocalVariableInstruction lcVarInsn = (JVMLocalVariableInstruction)insn;	
				if (lcVarInsn.getLocalVarInfo()!=null)
					return new LocalVariableStaticInfo<T>(mInfo, lcVarInsn.getLocalVarInfo());				
				String varName = "null"+lcVarInsn.getLocalVariableIndex();			
				byte typeCode = getVariableTypeCode(lcVarInsn);
				return new LocalVariableStaticInfo<T>(mInfo,varName,lcVarInsn.getLocalVariableSlot(),typeCode,false);
		}else if (insn instanceof JVMArrayElementInstruction){					
			//TODO: get Local Variable Info
			JVMArrayElementInstruction arrInsn = (JVMArrayElementInstruction) insn;					
			//arrInsn.get
			//throw ContractUtils.unsupported("not finished implement to support ArrayStoreInstruction");			
			StaticAnalysisUtility.logger.warning("warning: unsupported getVariableStaticInfo(): not finished implement to support "+insn);
			return null;
		} else if (insn instanceof FieldInstruction){					
			FieldInstruction fieldInsn = (FieldInstruction)insn;
			FieldInfo fInfo = fieldInsn.getFieldInfo();
			return new StaticFieldVariableStaticInfo<T>(fInfo);
		}else if (insn instanceof JVMReturnInstruction){
			//MethodInfo mi = insn.getMethodInfo();
			//TODO:
			StaticAnalysisUtility.logger.warning("warning: unsupported getVariableStaticInfo(): not finished implement to support "+insn);
			return null;
		}else if (insn instanceof JVMInvokeInstruction){
			//JVMInvokeInstruction invInsn = (JVMInvokeInstruction)insn;
			//MethodInfo mi = invInsn.getInvokedMethod();
			//TODO: get possible slide effect
			StaticAnalysisUtility.logger.warning("warning: unsupported getVariableStaticInfo(): not finished implement to support "+insn);
			return null;
		}
		return null;
	}
	
	public static <T> VariableStaticInfo<T> getModifiableVariableStaticInfo(Instruction insn){		
		if (insn instanceof IINC){
			IINC inc = (IINC)insn;
			MethodInfo mInfo = insn.getMethodInfo();
			LocalVarInfo varInfo = inc.getMethodInfo().getLocalVar(inc.getIndex(), inc.getPosition());
			if (varInfo!=null)
				return new LocalVariableStaticInfo<T>(mInfo, varInfo);				
			String varName = "null"+inc.getIndex();			
			byte typeCode = Types.T_INT;
			int slot = inc.getIndex();
			return new LocalVariableStaticInfo<T>(mInfo,varName,slot,typeCode,false);						
		}else if (insn instanceof StoreInstruction){						
			if (insn instanceof JVMLocalVariableInstruction){
				JVMLocalVariableInstruction localInsn = (JVMLocalVariableInstruction)insn;
				MethodInfo mInfo = localInsn.getMethodInfo();
				JVMLocalVariableInstruction lcVarInsn = (JVMLocalVariableInstruction)insn;	
				if (lcVarInsn.getLocalVarInfo()!=null)
					return new LocalVariableStaticInfo<T>(mInfo, lcVarInsn.getLocalVarInfo());				
				String varName = "null"+lcVarInsn.getLocalVariableIndex();			
				byte typeCode = getVariableTypeCode(lcVarInsn);
				boolean knowType = true;
				if (typeCode == Types.T_INT || typeCode == Types.T_REFERENCE || typeCode == Types.T_ARRAY)
					knowType=false;
				return new LocalVariableStaticInfo<T>(mInfo,varName,lcVarInsn.getLocalVariableSlot(),typeCode,knowType);
			}else if (insn instanceof ArrayStoreInstruction){					
				ArrayStoreInstruction arrInsn = (ArrayStoreInstruction) insn;					
				//throw ContractUtils.unsupported("not finished implement to support ArrayStoreInstruction");
				//System.out.println("unsupported getVariableStaticInfo(): not finished implement to support "+insn);
				//TODO: fix me, this implementation is a trick. HeapObjectModificationStaticInfo 
				VariableStaticInfo<T> varInfo = parseArrayStoreLine(arrInsn);				
				return varInfo;
			}
		}else if(insn instanceof WriteInstruction){									
			if (insn instanceof FieldInstruction){
				FieldInstruction fieldInsn = (FieldInstruction) insn;
				return new StaticFieldVariableStaticInfo<T>(fieldInsn.getFieldInfo());
			}else{
				StaticAnalysisUtility.logger.warning("warning: unsupported getVariableStaticInfo(): not finished implement to support "+insn);
				return null;
			}				
		}else if (insn instanceof JVMReturnInstruction){
			//MethodInfo mi = insn.getMethodInfo();
			//TODO:
			StaticAnalysisUtility.logger.warning("unsupported getVariableStaticInfo(): not finished implement to support "+insn);
			return null;
		}else if (insn instanceof JVMInvokeInstruction){
			//JVMInvokeInstruction invInsn = (JVMInvokeInstruction)insn;
			//MethodInfo mi = invInsn.getInvokedMethod();
			//TODO: get possible slide effect
			StaticAnalysisUtility.logger.warning("warning: unsupported getVariableStaticInfo(): not finished implement to support "+insn);
			return null;
		}
		return null;
	}
	
	static <T> VariableStaticInfo<T> parseArrayStoreLine(ArrayStoreInstruction arrInsn){
		String codeLine = arrInsn.getSourceLine();
		if (codeLine==null){
			return null;
		}
		/*codeLine = codeLine.trim();
		int left = codeLine.indexOf("[");
		String varName = codeLine.substring(0, left);
		LocalVarInfo vInfo =null;
		MethodInfo methodInfo = arrInsn.getMethodInfo();
		for(LocalVarInfo var:methodInfo.getLocalVars()){
			if (var.getName().equals(varName)){
				vInfo = var;
				break;
			}
		}				
		VariableStaticInfo<T> varInfo =new LocalVariableStaticInfo<>(methodInfo, vInfo);*/
		VariableStaticInfo<T> varInfo =null;
		return varInfo;		
	}
	
	static byte getVariableTypeCode(JVMLocalVariableInstruction insn) {
		if (insn instanceof ALOAD || insn instanceof ASTORE)
			return Types.T_REFERENCE;
		if (insn instanceof DLOAD || insn instanceof DSTORE)
			return Types.T_DOUBLE;
		if (insn instanceof FLOAD || insn instanceof FSTORE)
			return Types.T_FLOAT;
		if (insn instanceof ILOAD || insn instanceof ISTORE)
			return Types.T_INT;
		if (insn instanceof LLOAD || insn instanceof LSTORE)
			return Types.T_LONG;
		
		throw new JPFException("unsupported instruction type: " + insn);
	}	
}
