package gov.nasa.jpf.jcfg.cfg;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.regex.Pattern;

import gov.nasa.jpf.jcfg.cfg.util.ArrayUtilities;
import gov.nasa.jpf.jcfg.cfg.util.BooleanBox;
import gov.nasa.jpf.jcfg.exception.ExceptionUtilities;
import gov.nasa.jpf.jcfg.utils.DebugUtility;
import gov.nasa.jpf.jcfg.utils.InstructionUtil;
import gov.nasa.jpf.jcfg.utils.LoggerUtil;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.util.JPFLogger;
import gov.nasa.jpf.vm.InfoObject;
import gov.nasa.jpf.vm.Instruction;

public final class ControlFlowGraph {
	private static JPFLogger logger = LoggerUtil.getCFGLogger();
	private final List<ControlFlowNode> _nodes;

	public final ControlFlowNode getEntryPoint() {
		return _nodes.get(0);
	}

	public final ControlFlowNode getRegularExit() {
		return _nodes.get(1);
	}

	public final ControlFlowNode getExceptionalExit() {
		return _nodes.get(2);
	}

	public final List<ControlFlowNode> getNodes() {
		return _nodes;
	}

	public ControlFlowGraph(final ControlFlowNode... nodes) {
		_nodes = ArrayUtilities.asUnmodifiableList(VerifyArgument.noNullElements(nodes, "nodes"));

		assert nodes.length >= 3;
		assert getEntryPoint().getNodeType() == ControlFlowNodeType.EntryPoint;
		assert getRegularExit().getNodeType() == ControlFlowNodeType.RegularExit;
		assert getExceptionalExit().getNodeType() == ControlFlowNodeType.ExceptionalExit;
	}

	public final void resetVisited() {
		for (final ControlFlowNode node : _nodes) {
			node.setVisited(false);
		}
	}

	public final void computePostDominance() {
		computePostDominance(new BooleanBox());
	}

	public final void computePostDominance(final BooleanBox cancelled) {
		final ControlFlowNode entryPoint = getRegularExit();

		entryPoint.setImmediatePostDominator(entryPoint);

		final BooleanBox changed = new BooleanBox(true);

		while (changed.get()) {
			changed.set(false);
			resetVisited();

			if (cancelled.get()) {
				throw new CancellationException();
			}

			entryPoint.traversePreOrder(new Function<ControlFlowNode, Iterable<ControlFlowNode>>() {
				@Override
				public final Iterable<ControlFlowNode> apply(final ControlFlowNode input) {
					return input.getPredecessors();
				}
			}, new Block<ControlFlowNode>() {
				@Override
				public final void accept(final ControlFlowNode b) {
					if (b == entryPoint) {
						return;
					}

					ControlFlowNode newImmediatePostDominator = null;

					for (final ControlFlowNode p : b.getSuccessors()) {
						if (p.isVisited() && p != b) {
							newImmediatePostDominator = p;
							break;
						}
					}

					if (newImmediatePostDominator == null) {
						throw new IllegalStateException("Could not compute new immediate dominator!");
					}

					for (final ControlFlowNode p : b.getSuccessors()) {
						if (p != b && p.getImmediatePostDominator() != null) {
							newImmediatePostDominator = findCommonPostDominator(p, newImmediatePostDominator);
						}
					}

					if (b.getImmediatePostDominator() != newImmediatePostDominator) {
						b.setImmediatePostDominator(newImmediatePostDominator);
						changed.set(true);
					}
				}
			});
		}

		entryPoint.setImmediatePostDominator(null);

		for (final ControlFlowNode node : _nodes) {
			final ControlFlowNode immediatePostDominator = node.getImmediatePostDominator();

			if (immediatePostDominator != null) {
				immediatePostDominator.getPostDominatorTreeChildren().add(node);
			}
		}
	}

	public final void computePostDominanceExceptionalExit() {
		computePostDominanceExceptionalExit(new BooleanBox());
	}
	
	public final void computePostDominanceExceptionalExit(final BooleanBox cancelled) {
		final ControlFlowNode entryPoint = getExceptionalExit();

		entryPoint.setImmediatePostDominatorExceptionalExit(entryPoint);

		final BooleanBox changed = new BooleanBox(true);

		while (changed.get()) {
			changed.set(false);
			resetVisited();

			if (cancelled.get()) {
				throw new CancellationException();
			}

			entryPoint.traversePreOrder(new Function<ControlFlowNode, Iterable<ControlFlowNode>>() {
				@Override
				public final Iterable<ControlFlowNode> apply(final ControlFlowNode input) {
					return input.getPredecessors();
				}
			}, new Block<ControlFlowNode>() {
				@Override
				public final void accept(final ControlFlowNode b) {
					if (b == entryPoint) {
						return;
					}

					ControlFlowNode newImmediatePostDominatorExceptionalExit = null;

					for (final ControlFlowNode p : b.getSuccessors()) {
						if (p.isVisited() && p != b) {
							newImmediatePostDominatorExceptionalExit = p;
							break;
						}
					}

					if (newImmediatePostDominatorExceptionalExit == null) {
						throw new IllegalStateException("Could not compute new immediate dominator exceptional exit!");
					}

					for (final ControlFlowNode p : b.getSuccessors()) {
						if (p != b && p.getImmediatePostDominatorExceptionalExit() != null) {
							newImmediatePostDominatorExceptionalExit = findCommonPostDominatorExceptionalExit(p, newImmediatePostDominatorExceptionalExit);
						}
					}

					if (b.getImmediatePostDominatorExceptionalExit() != newImmediatePostDominatorExceptionalExit) {
						b.setImmediatePostDominatorExceptionalExit(newImmediatePostDominatorExceptionalExit);
						changed.set(true);
					}
				}
			});
		}

		entryPoint.setImmediatePostDominatorExceptionalExit(null);

		for (final ControlFlowNode node : _nodes) {
			final ControlFlowNode immediatePostDominatorExceptionalExit = node.getImmediatePostDominatorExceptionalExit();

			if (immediatePostDominatorExceptionalExit != null) {
				immediatePostDominatorExceptionalExit.getPostDominatorExceptionalExitTreeChildren().add(node);
			}
		}
	}
	
	
	public final void computeDominance() {
		computeDominance(new BooleanBox());
	}

	public final void computeDominance(final BooleanBox cancelled) {
		final ControlFlowNode entryPoint = getEntryPoint();

		entryPoint.setImmediateDominator(entryPoint);

		final BooleanBox changed = new BooleanBox(true);

		while (changed.get()) {
			changed.set(false);
			resetVisited();

			if (cancelled.get()) {
				throw new CancellationException();
			}

			entryPoint.traversePreOrder(new Function<ControlFlowNode, Iterable<ControlFlowNode>>() {
				@Override
				public final Iterable<ControlFlowNode> apply(final ControlFlowNode input) {
					return input.getSuccessors();
				}
			}, new Block<ControlFlowNode>() {
				@Override
				public final void accept(final ControlFlowNode b) {
					if (b == entryPoint) {
						return;
					}

					ControlFlowNode newImmediateDominator = null;

					for (final ControlFlowNode p : b.getPredecessors()) {
						if (p.isVisited() && p != b) {
							newImmediateDominator = p;
							break;
						}
					}

					if (newImmediateDominator == null) {
						throw new IllegalStateException("Could not compute new immediate dominator!");
					}

					for (final ControlFlowNode p : b.getPredecessors()) {
						if (p != b && p.getImmediateDominator() != null) {
							newImmediateDominator = findCommonDominator(p, newImmediateDominator);
						}
					}

					if (b.getImmediateDominator() != newImmediateDominator) {
						b.setImmediateDominator(newImmediateDominator);
						changed.set(true);
					}
				}
			});
		}

		entryPoint.setImmediateDominator(null);

		for (final ControlFlowNode node : _nodes) {
			final ControlFlowNode immediateDominator = node.getImmediateDominator();

			if (immediateDominator != null) {
				immediateDominator.getDominatorTreeChildren().add(node);
			}
		}
	}

	public final void computeDominanceFrontier() {
		resetVisited();

		getEntryPoint().traversePostOrder(new Function<ControlFlowNode, Iterable<ControlFlowNode>>() {
			@Override
			public final Iterable<ControlFlowNode> apply(final ControlFlowNode input) {
				return input.getDominatorTreeChildren();
			}
		}, new Block<ControlFlowNode>() {
			@Override
			public void accept(final ControlFlowNode n) {
				final Set<ControlFlowNode> dominanceFrontier = n.getDominanceFrontier();

				dominanceFrontier.clear();

				for (final ControlFlowNode s : n.getSuccessors()) {
					if (s.getImmediateDominator() != n) {
						dominanceFrontier.add(s);
					}
				}

				for (final ControlFlowNode child : n.getDominatorTreeChildren()) {
					for (final ControlFlowNode p : child.getDominanceFrontier()) {
						if (p.getImmediateDominator() != n) {
							dominanceFrontier.add(p);
						}
					}
				}
			}
		});
	}

	public final void computePostDominanceFrontier() {
		resetVisited();

		getRegularExit().traversePostOrder(new Function<ControlFlowNode, Iterable<ControlFlowNode>>() {
			@Override
			public final Iterable<ControlFlowNode> apply(final ControlFlowNode input) {
				return input.getPostDominatorTreeChildren();
			}
		}, new Block<ControlFlowNode>() {
			@Override
			public void accept(final ControlFlowNode n) {
				final Set<ControlFlowNode> dominanceFrontier = n.getPostDominanceFrontier();

				dominanceFrontier.clear();

				for (final ControlFlowNode s : n.getPredecessors()) {
					if (s.getNodeType() == ControlFlowNodeType.ExceptionalExit)
						continue;
					if (s.getImmediatePostDominator() != n) {
						dominanceFrontier.add(s);
					}
				}

				for (final ControlFlowNode child : n.getPostDominatorTreeChildren()) {
					for (final ControlFlowNode p : child.getPostDominanceFrontier()) {
						if (p.getImmediatePostDominator() != n) {
							dominanceFrontier.add(p);
						}
					}
				}
			}
		});
	}

	public static ControlFlowNode findCommonDominator(final ControlFlowNode a, final ControlFlowNode b) {
		final Set<ControlFlowNode> path1 = new LinkedHashSet<>();

		ControlFlowNode node1 = a;
		ControlFlowNode node2 = b;

		while (node1 != null && path1.add(node1)) {
			node1 = node1.getImmediateDominator();
		}

		while (node2 != null) {
			if (path1.contains(node2)) {
				return node2;
			}
			node2 = node2.getImmediateDominator();
		}

		throw new IllegalStateException("No common dominator found!");
	}

	public static ControlFlowNode findCommonPostDominator(final ControlFlowNode a, final ControlFlowNode b) {
		final Set<ControlFlowNode> path1 = new LinkedHashSet<>();

		ControlFlowNode node1 = a;
		ControlFlowNode node2 = b;

		while (node1 != null && path1.add(node1)) {
			node1 = node1.getImmediatePostDominator();
		}

		while (node2 != null) {
			if (path1.contains(node2)) {
				return node2;
			}
			node2 = node2.getImmediatePostDominator();
		}

		throw new IllegalStateException("No common dominator found!");
	}
	
	public static ControlFlowNode findCommonPostDominatorExceptionalExit(final ControlFlowNode a, final ControlFlowNode b) {
		final Set<ControlFlowNode> path1 = new LinkedHashSet<>();

		ControlFlowNode node1 = a;
		ControlFlowNode node2 = b;

		while (node1 != null && path1.add(node1)) {
			node1 = node1.getImmediatePostDominatorExceptionalExit();
		}

		while (node2 != null) {
			if (path1.contains(node2)) {
				return node2;
			}
			node2 = node2.getImmediatePostDominatorExceptionalExit();
		}

		throw new IllegalStateException("No common dominator exceptional exit found!");
	}

	public final void export(final File path) {
		final PlainTextOutput output = new PlainTextOutput();

		output.writeLine("digraph g {");
		output.indent();

		final Set<ControlFlowEdge> edges = new LinkedHashSet<>();

		for (final ControlFlowNode node : _nodes) {
			output.writeLine("\"%s\" [", nodeName(node));
			output.indent();

			output.writeLine("label = \"%s\\l\"", escapeGraphViz(node.toString()));

			output.writeLine(", shape = \"box\"");

			output.unindent();
			output.writeLine("];");

			edges.addAll(node.getIncoming());
			edges.addAll(node.getOutgoing());

			final ControlFlowNode endFinallyNode = node.getEndFinallyNode();

			if (endFinallyNode != null) {
				output.writeLine("\"%s\" [", nodeName(endFinallyNode));
				output.indent();

				output.writeLine("label = \"%s\"", escapeGraphViz(endFinallyNode.toString()));

				output.writeLine("shape = \"box\"");

				output.unindent();
				output.writeLine("];");

				edges.addAll(endFinallyNode.getIncoming());
				edges.addAll(endFinallyNode.getOutgoing());
				// edges.add(new ControlFlowEdge(node, endFinallyNode,
				// JumpType.EndFinally));
			}
		}

		for (final ControlFlowEdge edge : edges) {
			final ControlFlowNode from = edge.getSource();
			final ControlFlowNode to = edge.getTarget();

			output.writeLine("\"%s\" -> \"%s\" [", nodeName(from), nodeName(to));
			output.indent();

			switch (edge.getType()) {
			case Normal:
				break;

			case LeaveTry:
				output.writeLine("color = \"blue\"");
				break;

			case EndFinally:
				output.writeLine("color = \"red\"");
				break;

			case JumpToExceptionHandler:
				output.writeLine("color = \"gray\"");
				break;

			default:
				output.writeLine("label = \"%s\"", edge.getType());
				break;
			}

			output.unindent();
			output.writeLine("];");
		}

		output.unindent();
		output.writeLine("}");

		try (final OutputStreamWriter out = new FileWriter(path)) {
			out.write(output.toString());
		} catch (IOException e) {
			//throw ExceptionUtilities.asRuntimeException(e);
			e.printStackTrace();
		}
	}

	private static String nodeName(final ControlFlowNode node) {
		String name = "node" + node.getBlockIndex();

		if (node.getNodeType() == ControlFlowNodeType.EndFinally) {
			name += "_ef";
		}

		return name;
	}

	private final static Pattern SAFE_PATTERN = Pattern.compile("^[\\w\\d]+$");

	private static String escapeGraphViz(final String text) {
		return escapeGraphViz(text, false);
	}

	private static String escapeGraphViz(final String text, final boolean quote) {
		if (SAFE_PATTERN.matcher(text).matches()) {
			return quote ? "\"" + text + "\"" : text;
		} else {
			return (quote ? "\"" : "") + text.replace("\\", "\\\\").replace("\r", "").replace("\n", "\\l")
					.replace("|", "\\|").replace("{", "\\{").replace("}", "\\}").replace("<", "\\<").replace(">", "\\>")
					.replace("\"", "\\\"") + (quote ? "\"" : "");
		}
	}

	public void computeJoinVariable() {
		// analyze phi variable in each node
		for (ControlFlowNode n : this.getNodes()) {
			for (VariableStaticInfo v : n.getModifiedVariablesInfo()) {
				
				for (ControlFlowNode df : n.getDominanceFrontier()) {
					if (df.getNodeType()== ControlFlowNodeType.ExceptionalExit)
						continue;					 
					
					if (df == n){ //begin of a loop?
						
					}
					//TODO: check variable scope
					df.addJoinVariableInfo(v);					
				}
			}
		}
	}

	public void computeModifiableVariable() {
		for (final ControlFlowNode node : this.getNodes()) {
			//this.computeModifiableVariableInNode(beginNode);
			node.initModifiedVariableInfoList();
		}
	}

	/*private void computeModifiableVariableInNode(ControlFlowNode node) {
		node.getModifiedVariablesInfo();
	}*/

	public void computeModifiableVariableInBranches() {
		for (final ControlFlowNode beginNode : this.getNodes()) {
			this.computeModifiableVariableInBranchBlocks(beginNode);
		}
	}
	
	public void computeModifiableVariableInBranchBlocks(final ControlFlowNode node) {
		final ControlFlowNode endNode = node.getImmediatePostDominator();
		if (endNode == null)
			return;
		if (DebugUtility.isDebugCfgEnabled())
			logger.finest("DEBUG computeModifiableVariableInBlock: beginNode=" + node.getBlockIndex() + ", endNode="+ endNode.getBlockIndex());		
		for (ControlFlowEdge edge : node.getOutgoing()) {
			final ControlFlowNode succNode = edge.getTarget(); //Todo: skip exceptional exit edge
			if (succNode == endNode){
				node.addRedefinableVariableForBranch(endNode, Collections.emptyList());
				continue;
			}
			this.resetVisited();
			node.addRedefinableVariableForBranch(succNode, succNode.getModifiedVariablesInfo());
			succNode.traversePostOrder(new Function<ControlFlowNode, Iterable<ControlFlowNode>>() {
				@Override
				public final Iterable<ControlFlowNode> apply(final ControlFlowNode input) {
					if (input == endNode)
						return new ArrayList<>();
					return input.getSuccessors();
				}
			}, new Block<ControlFlowNode>() {
				@Override
				public void accept(final ControlFlowNode n) {
					if (n == endNode || n.getNodeType() == ControlFlowNodeType.ExceptionalExit)
						return;
					for (final ControlFlowNode s : n.getSuccessors()) {
						if (s == endNode || s.getNodeType() == ControlFlowNodeType.ExceptionalExit
								|| s.getNodeType() == ControlFlowNodeType.RegularExit)
							continue;
						for (VariableStaticInfo v : s.getModifiedVariablesInfo()) {
							// TODO: check variable accessibility scope
							node.addRedefinableVariableForBranch(succNode, v);
						}
					}
				}
			});
			if (DebugUtility.isDebugCfgEnabled())
				logger.finest("Modifiable vars in branch " + succNode.getBlockIndex() + ": "+ node.getRedefinableVariableOfBranch(succNode));
		}
		if (DebugUtility.isDebugCfgEnabled())
			logger.finest("DEBUG: finished node: " + node.getBlockIndex());
	}

	/*public void computeBeginEndOfBlocks() {
		for (final ControlFlowNode node : this.getNodes()) {
			//determine begin node			
			if (node.getEnd()!=null){
				Instruction insn = node.getEnd();
				if (InstructionUtil.isConditionalBranch(insn))
					node.setIsBeginBranch(true);				
			}
			if (node.isBeginBranch()){
				//determine end branch
				ControlFlowNode endNode = node.getImmediatePostDominator();
				node.setNextBlock(endNode);
			}
		}
	}*/
}
