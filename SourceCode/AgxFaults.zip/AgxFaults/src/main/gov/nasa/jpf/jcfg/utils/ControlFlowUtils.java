package gov.nasa.jpf.jcfg.utils;

import java.util.ArrayList;
import java.util.List;

import gov.nasa.jpf.JPFException;
import gov.nasa.jpf.jcfg.StaticAnalysisUtility;
import gov.nasa.jpf.jcfg.cfg.ControlFlowEdge;
import gov.nasa.jpf.jcfg.cfg.ControlFlowGraph;
import gov.nasa.jpf.jcfg.cfg.ControlFlowNode;
import gov.nasa.jpf.jcfg.cfg.JumpType;
import gov.nasa.jpf.jcfg.cfg.OpCode;
import gov.nasa.jpf.jcfg.exception.ContractUtils;
import gov.nasa.jpf.jcfg.variable.VariableStaticInfo;
import gov.nasa.jpf.jvm.bytecode.IfInstruction;
import gov.nasa.jpf.jvm.bytecode.SwitchInstruction;
import gov.nasa.jpf.vm.InfoObject;
import gov.nasa.jpf.vm.Instruction;
import gov.nasa.jpf.vm.LocalVarInfo;
import gov.nasa.jpf.vm.MethodInfo;
import gov.nasa.jpf.vm.ThreadInfo;
import gov.nasa.jpf.vm.bytecode.InstructionInterface;

public class ControlFlowUtils {
	

	public static boolean isEndOfIf(InstructionInterface beginBranchInsn, InstructionInterface insn) {
		if (!(beginBranchInsn instanceof IfInstruction) && !(beginBranchInsn instanceof gov.nasa.jpf.jvm.bytecode.SwitchInstruction))
			throw new JPFException("Ilegal state exception");
		
		//sf and lastIfFrame is the same frame
		ControlFlowNode cfnChild = getControlFlowNode(insn);
		ControlFlowNode cfnBegin = getControlFlowNode(beginBranchInsn);
		
		ControlFlowNode cfnJoin = cfnBegin.getImmediatePostDominator();		
		//TODO: fix me, not correct
		if (cfnChild == cfnJoin)
			return true;
		else
			return false;		
	}

	public static boolean isOutsideOf(InstructionInterface beginBranchInsn, InstructionInterface insn) {
		/*if (!(beginBranchInsn instanceof IfInstruction) && !(beginBranchInsn instanceof gov.nasa.jpf.jvm.bytecode.SwitchInstruction)){
			OpCode opCode = OpCode.get(beginBranchInsn.getByteCode());
			if (!opCode.canThrow())
				return true; //throw new JPFException("Ilegal state exception");		
			
			ControlFlowNode cfnChild = getControlFlowNode(insn);
			ControlFlowNode cfnBegin = getControlFlowNode(beginBranchInsn);
			
			ControlFlowNode cfnJoin = cfnBegin.getImmediatePostDominatorExceptionalExit();		
			//TODO: fix me, not correct
			if (cfnChild == cfnJoin)
				return true;
			else
				return false;		
		}*/
		//sf and lastIfFrame is the same frame
		ControlFlowNode cfnChild = getControlFlowNode(insn);
		ControlFlowNode cfnBegin = getControlFlowNode(beginBranchInsn);
		
		ControlFlowNode cfnJoin = cfnBegin.getImmediatePostDominator();		
		//TODO: fix me, not correct
		if (cfnChild == cfnJoin)
			return true;
		else
			return false;		
	}
//
	public static ControlFlowNode getControlFlowNode(InstructionInterface insn) {
		ControlFlowNode cfn = insn.getAttr(ControlFlowNode.class);
		if (cfn==null && insn.getMethodInfo().getAttr(ControlFlowGraph.class)==null){
			StaticAnalysisUtility.getControlFlowGraph(insn.getMethodInfo());
			cfn = insn.getAttr(ControlFlowNode.class);
		}
		return cfn;
	}
	
//	public static List<VariableStaticInfo> getNeedToJoinVariables(ControlFlowNode cfn,MethodInfo mi) {
//		List<VariableStaticInfo> varInfos = new ArrayList<>();
//		for(VariableStaticInfo v: cfn.getJoinVariablesInfo()){
//			if (v instanceof LocalVarInfo){
//				LocalVarInfo lcV = (LocalVarInfo) v;
//				varInfos.add(lcV);
//			}
//		}
//		return varInfos;
//	}

	public static List<VariableStaticInfo> getModifiableVariables(InstructionInterface insn, int branchIdx) {
		MethodInfo mi = insn.getMethodInfo();
		ControlFlowNode cfnParent = ControlFlowUtils.getControlFlowNode(insn);
		ControlFlowNode cfnTarget =null;
		Instruction branch;		
		if (insn instanceof IfInstruction){			
			if (branchIdx==0)
				branch= ((IfInstruction) insn).getTarget();
			else
				branch= insn.getNext();
			cfnTarget =  ControlFlowUtils.getControlFlowNode(branch);			
		}else if (insn instanceof SwitchInstruction){
			SwitchInstruction swch = (SwitchInstruction) insn;
			if (branchIdx>=0 && branchIdx < swch.getNumberOfTargets())
				branch = mi.getInstructionAt(swch.getTargets()[branchIdx]); 
			else
				branch = mi.getInstructionAt(swch.getTarget()); //get default target
			cfnTarget =  ControlFlowUtils.getControlFlowNode(branch);			
		}else{//exception
			if (branchIdx!=0) { //normal branch
				for(ControlFlowEdge edg :cfnParent.getOutgoing())
					if (edg.getType() == JumpType.JumpToExceptionHandler){
						cfnTarget = edg.getTarget();
						break;
					}				
			}else{
				if (cfnParent.getOutgoing().size()>2)
					throw ContractUtils.unreachable("This is not a branch instruction");		
				for(ControlFlowEdge edg :cfnParent.getOutgoing())
					if (edg.getType() != JumpType.JumpToExceptionHandler){
						cfnTarget = edg.getTarget();
						break;
					}
			}			
		}
		
		if (cfnTarget==null)
			throw ContractUtils.unreachable("This is not a branch instruction");
		List<VariableStaticInfo> modifiableVarsInfo = cfnParent.getRedefinableVariableOfBranch(cfnTarget);
		if (modifiableVarsInfo==null)
			modifiableVarsInfo = new ArrayList();
		return modifiableVarsInfo;
	}
}
