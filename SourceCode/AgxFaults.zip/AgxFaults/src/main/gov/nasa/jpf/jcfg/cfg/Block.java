package gov.nasa.jpf.jcfg.cfg;

public interface Block<T> {
  public void accept(final T input);
}
