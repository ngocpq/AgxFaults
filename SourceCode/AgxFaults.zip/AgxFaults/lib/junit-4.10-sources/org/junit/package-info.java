/**
 * Provides JUnit core classes and annotations. 
 * 
 * Corresponds to junit.framework in Junit 3.x.
 *
 * @since 4.0
 */
package org.junit;