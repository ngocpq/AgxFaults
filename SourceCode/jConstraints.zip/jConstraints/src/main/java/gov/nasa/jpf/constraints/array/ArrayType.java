package gov.nasa.jpf.constraints.array;

import java.lang.reflect.Array;
import java.nio.channels.spi.AbstractInterruptibleChannel;

import gov.nasa.jpf.constraints.casts.CastOperation;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;

public class ArrayType <T> implements Type<T[]> {
	private final Class<T> elementClass;
	private final Type<T> elementType;	
	private final int length;
	
	public ArrayType(Type<T> type,int length){
		this.length=length;
		this.elementType=type;
		this.elementClass = type.getCanonicalClass();
	}
	
	public Type<T> getElementType(){
		return this.elementType;
	}
	public int getLength() {
		return this.length;
	}

	@Override
	public String getName() {
		return "array";
	}

	@Override
	public String[] getOtherNames() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Class<T[]> getCanonicalClass() {
		return (Class<T[]>) Array.newInstance(elementClass, getLength()).getClass();
	}

	@Override
	public Class<?>[] getOtherClasses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T[] cast(Object other) {
		if (other !=null && other.getClass().isArray()){			
			return (T[]) other;
		}
		throw new ClassCastException();
	}

	@Override
	public T[] getDefaultValue() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Type<?> getSuperType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <O> CastOperation<? super O, ? extends T[]> cast(Type<O> fromType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <O> CastOperation<? super O, ? extends T[]> requireCast(Type<O> fromType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T[] parse(String str) {
		if (str==null)
			return null;
		str = str.trim();
		if (str.length()>=2){
			if (str.charAt(str.length()-1)==']')
				str= str.substring(0, str.length()-1);
			if (str.charAt(0)=='[')
				str = str.substring(1);		
		}
		if (str.isEmpty())
			return null;
		String[] elmts = str.split(",");				
		T[] data = (T[]) Array.newInstance(elementClass, getLength());
		for(int i=0;i<elmts.length;i++){
			String[] pair = elmts[i].split("->");
			String strIdx = pair[0].trim();
			String strValue = pair[1].trim();
			int idx = BuiltinTypes.SINT32.parse(strIdx);
			T value = this.getElementType().parse(strValue);
			
			
			if (idx<0 || idx>=this.getLength()){
				System.out.println("Index out of bound");
				continue;
			}
			data[idx] = value;
		}
		return data;
	}	
}
