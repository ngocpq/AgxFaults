package gov.nasa.jpf.constraints.array;

import java.io.IOException;
import java.util.Collection;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.ExpressionVisitor;
import gov.nasa.jpf.constraints.api.Valuation;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.expressions.AbstractExpression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;

public class StoreExpression<E> extends AbstractExpression<E[]> implements ArrayExpression<E>{
	final ArrayExpression<E> array;	
	final Expression<Integer> index;
	final Expression<E> value;
	
	public StoreExpression(ArrayExpression<E> array, int index,E value){
		this.array=array;
		this.index = Constant.create(BuiltinTypes.SINT32, index) ;
		this.value = Constant.create(this.array.getArrayType().getElementType(),value);
	}
	
	public StoreExpression(ArrayExpression<E> array, int index,Expression<E> value){
		this.array=array;
		this.index = Constant.create(BuiltinTypes.SINT32, index) ;
		this.value = value;
	}
	
	public StoreExpression(ArrayExpression<E> array,Expression<Integer> index,Expression<E> value){
		this.array=array;
		this.index = index;
		this.value = value;
	}
	
	public ArrayExpression<E> getArray() {
		return this.array;
	}

	public Expression<Integer> getIndex() {
		return this.index;
	}
	public Expression<E> getValue() {
		return this.value;
	}
	
	@Override
	public E[] evaluate(Valuation values) {
		E[] arr = array.evaluate(values);
		int idx = index.evaluate(values);
		E v = value.evaluate(values);
		arr[idx]=v;
		return arr;
	}

	@Override
	public void collectFreeVariables(Collection<? super Variable<?>> variables) {
		array.collectFreeVariables(variables);
		index.collectFreeVariables(variables);
		value.collectFreeVariables(variables);
	}

	@Override
	public <R, D> R accept(ExpressionVisitor<R, D> visitor, D data) {
		return visitor.visit(this, data);
	}

	@Override
	public Type<E[]> getType() {
		return array.getType();
	}

	@Override
	public Expression<?>[] getChildren() {
		return new Expression[]{array,index,value};
	}

	@Override
	public Expression<?> duplicate(Expression<?>[] newChildren) {
		throw new UnsupportedOperationException("Unimplemented");
	}

	@Override
	public void print(Appendable a, int flags) throws IOException {
		a.append('(');
		this.array.print(a, flags);
		a.append('[');
		index.print(a, flags);
		a.append("] <- '");
		value.print(a, flags);
		a.append('\'');
		a.append(')');
	}

	@Override
	public void printMalformedExpression(Appendable a, int flags) throws IOException {
		a.append('(');
		if (array !=null)
			this.array.print(a, flags);
		else
			a.append("null");
		a.append('[');
		if(index!=null)
			index.print(a, flags);
		else
			a.append("null");
		a.append("] <- '");		
		if(value!=null)
			value.print(a, flags);
		else
			a.append("null");		
		a.append('\'');
		a.append(')');
	}

	@Override
	public ArrayType<E> getArrayType() {
		return (ArrayType<E>) this.getType();
	}

}
