package gov.nasa.jpf.constraints.expressions.functions;

import java.util.HashMap;

import gov.nasa.jpf.constraints.types.Type;

public class FunctionUtility {
	static HashMap<String, Function<?>> functionsMap=new HashMap<>();
	
	public static Function<?> registerFunction(String key,Function<?> fun) {
		if (functionsMap.containsKey(key))
			throw new UnsupportedOperationException("Duplicate registering for function '"+key+"'"); 
		functionsMap.put(key, fun);
		return fun;
	}
	
	public static Function<?> getFunction(String key) {
		return functionsMap.get(key);
	}
	
	public static Function<?> getOrCreateFunction(String name, Type<?> returnType, Type<?>[] paramTypes) {
		String key = name;
		/*String key = returnType.getName()+"_"+name;
		for(int i=0;i<paramTypes.length;i++)
			key+="_"+paramTypes[i].getName();*/		
		Function<?> fun = getFunction(key);
		if (fun==null){
			//fun = new Function<>(name, returnType, paramTypes); //TODO: uncomment this statements
			//functionsMap.put(key, fun);
		}		
		return fun;
	}
	
	
	
}
