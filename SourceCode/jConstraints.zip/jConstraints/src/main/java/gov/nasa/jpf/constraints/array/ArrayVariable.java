package gov.nasa.jpf.constraints.array;

import gov.nasa.jpf.constraints.api.ExpressionVisitor;
import gov.nasa.jpf.constraints.api.Valuation;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;

public class ArrayVariable<E> extends Variable<E[]> implements ArrayExpression<E>{
	
	private final ArrayType<E> arrType;
	
	public ArrayVariable(String name,Type<E> elementType,int length) {
		super(new ArrayType<>(elementType, length),name);
		arrType = (ArrayType<E>) this.getType();
	}
	public ArrayVariable(String name,ArrayType<E> arrType) {
		this(name,arrType.getElementType(),arrType.getLength());
	}
	
	public int getLength(){
		return arrType.getLength();
	}
	
//	private Class<E> getElementClass(){
//		return getElementType().getCanonicalClass();
//	}
	
	public Type<E> getElementType() {
		return arrType.getElementType();
	}
	
//	public Variable<E>[] getElementSymbols(){
//		if (elements==null){
//			elements = new Variable[getLength()];
//			for(int i=0;i<getLength();i++){
//				String eName = name+"["+i+"]";
//				elements[i] = Variable.create(type.getElementType(), eName);
//			}
//		}
//		return elements;
//	}
	
	/*private boolean checkValidBound(int index){
		return index >= 0 && index < getLength();
	}*/
	
	/*public String getElementName(int index){
		return getName()+"["+index+"]";
	}*/
	
	public Variable<Integer> getLengthSymbol(){
		return Variable.create(BuiltinTypes.SINT32, getName()+"[len]");
	}
	
	/*public Variable<E> getElementSymbol(int index){
		if (!checkValidBound(index))
			throw new IndexOutOfBoundsException("Index ='"+index+"' but the array getLength() is '"+getLength()+"'");
		//return this.getElementSymbols()[index];
		String eName = getName()+"["+index+"]";
		return Variable.create(getElementType(), eName);
	}*/
	
//	@Override
//	public void collectFreeVariables(Collection<? super Variable<?>> variables) {
//		this.getLengthVariable().collectFreeVariables(variables);
//		for(int i=0;i<getLength();i++){
//			variables.add(this.getElementSymbol(i));
//		}
//	}
	
	@Override
	public E[] evaluate(Valuation values) {
		return super.evaluate(values);
		/*E[] arr = (E[]) Array.newInstance(getElementClass(), getLength());
		for(int i=0;i<getLength();i++){
			Variable<E> e = this.getElementSymbol(i);
			arr[i] = e.evaluate(values);
		}
		return arr;*/
	}

	@Override
	public <R, D> R accept(ExpressionVisitor<R, D> visitor, D data) {
		return visitor.visit((Variable<E[]>)this, data);
	}
//
//	@Override
//	public Type<E[]> getType() {
//		return this.type;
//	}
//
//	@Override
//	public Expression<?>[] getChildren() {
//		return NO_CHILDREN;
//	}
//
//	@Override
//	public Expression<?> duplicate(Expression<?>[] newChildren) {
//		assert newChildren.length == 0;
//	    return this;
//	}
//
//	@Override
//	public void print(Appendable a, int flags) throws IOException {
//		this.getLengthVariable().print(a,flags);
//		for(int i=0;i<getLength();i++){
//			this.getElementSymbol(i).print(a, flags);
//		}		
//	}
//
//	@Override
//	public void printMalformedExpression(Appendable a, int flags) throws IOException {
//		this.getLengthVariable().printMalformedExpression(a,flags);
//		for(int i=0;i<getLength();i++){
//			this.getElementSymbol(i).printMalformedExpression(a, flags);
//		}	
//	}

	@Override
	public ArrayType<E> getArrayType() {
		return this.arrType;
	}

}
