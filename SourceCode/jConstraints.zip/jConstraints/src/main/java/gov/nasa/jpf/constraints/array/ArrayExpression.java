package gov.nasa.jpf.constraints.array;

import gov.nasa.jpf.constraints.api.Expression;

public interface ArrayExpression<E> extends Expression<E[]>{
	ArrayType<E> getArrayType();
	//Type<E> getElementType();	
}
