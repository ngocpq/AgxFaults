package gov.nasa.jpf.constraints.array;

import java.io.IOException;
import java.util.Collection;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.ExpressionVisitor;
import gov.nasa.jpf.constraints.api.Valuation;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.expressions.AbstractExpression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;

public class SelectExpression<E> extends AbstractExpression<E> {	
	final ArrayExpression<E> array;	
	final Expression<Integer> index;
	
	public SelectExpression(ArrayExpression<E> array,int index){
		this.array=array;
		this.index = Constant.create(BuiltinTypes.SINT32, index);
	}
	
	public SelectExpression(ArrayExpression<E> array,Expression<Integer> index){
		this.array=array;
		this.index = index;
	}
	
	public ArrayExpression<E> getArray() {
		return this.array;
	}

	public Expression<Integer> getIndex() {
		return this.index;
	}

	@Override
	public E evaluate(Valuation values) {
		E[] data = array.evaluate(values);
		int idx = this.index.evaluate(values);				
		return data[idx];
	}

	@Override
	public void collectFreeVariables(Collection<? super Variable<?>> variables) {
		this.array.collectFreeVariables(variables);
		this.index.collectFreeVariables(variables);
	}

	@Override
	public <R, D> R accept(ExpressionVisitor<R, D> visitor, D data) {
		return visitor.visit(this, data);
	}

	@Override
	public Type<E> getType() {
		return array.getArrayType().getElementType();
	}

	@Override
	public Expression<?>[] getChildren() {
		return new Expression[]{this.array,this.index};
	}

	@Override
	public Expression<?> duplicate(Expression<?>[] newChildren) {
		throw new UnsupportedOperationException("Unimplemented");
	}

	@Override
	public void print(Appendable a, int flags) throws IOException {
		this.array.print(a, flags);
		a.append('[');
		index.print(a, flags);
		a.append(']');
		
//		a.append("(SELECT ");
//	    this.array.print(a, flags);
//	    a.append(' ');
//	    index.print(a, flags);
//	    a.append(')');
	}

	@Override
	public void printMalformedExpression(Appendable a, int flags) throws IOException {
		if (array !=null)
			this.array.print(a, flags);
		else
			a.append("null");
		a.append('[');
		if(index!=null)
			index.print(a, flags);
		else
			a.append("null");
		a.append(']');
	}
	
	
}
