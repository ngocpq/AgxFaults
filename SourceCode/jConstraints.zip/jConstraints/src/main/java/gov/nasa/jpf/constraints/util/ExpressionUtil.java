/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 *
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 *
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */

package gov.nasa.jpf.constraints.util;

import gov.nasa.jpf.constraints.api.ConstraintSolver;
import gov.nasa.jpf.constraints.api.ConstraintSolver.Result;
import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.SolverContext;
import gov.nasa.jpf.constraints.api.Valuation;
import gov.nasa.jpf.constraints.api.ValuationEntry;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.array.ArrayConstant;
import gov.nasa.jpf.constraints.array.ArrayExpression;
import gov.nasa.jpf.constraints.array.SelectExpression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.expressions.LogicalOperator;
import gov.nasa.jpf.constraints.expressions.Negation;
import gov.nasa.jpf.constraints.expressions.NumericBooleanExpression;
import gov.nasa.jpf.constraints.expressions.NumericComparator;
import gov.nasa.jpf.constraints.expressions.PropositionalCompound;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;

import com.google.common.base.Function;
import com.google.common.base.Predicate;

public class ExpressionUtil {

	public static final Constant<Boolean> FALSE = Constant.create(BuiltinTypes.BOOL, Boolean.FALSE);
	public static final Constant<Boolean> TRUE = Constant.create(BuiltinTypes.BOOL, Boolean.TRUE);

	public static Constant<Boolean> boolConst(boolean val) {
		return val ? TRUE : FALSE;
	}

	public static boolean isConstant(Expression<?> expr, Object value) {
		if (!(expr instanceof Constant))
			return false;
		Constant<?> cnst = (Constant<?>) expr;
		return Objects.equals(cnst.getValue(), value);
	}

	public static boolean isBoolConst(Expression<?> expr, boolean value) {
		return isConstant(expr, Boolean.valueOf(value));
	}

	public static boolean isTrue(Expression<?> expr) {
		return isBoolConst(expr, true);
	}

	public static boolean isFalse(Expression<?> expr) {
		return isBoolConst(expr, false);
	}

	public static boolean containsVars(Expression<?> e) {
		return ContainsVarsVisitor.getInstance().apply(e);
	}

	public static <E> Expression<E> simplify(Expression<E> e) {
		return ExpressionSimplificationVisitor.getInstance().simplify(e);
	}

	public static <E> Expression<E> stripPrefix(Expression<E> e, String prefix) {
		return StripPrefixVisitor.INSTANCE.apply(e, prefix);
	}

	public static <E> Expression<E> addPrefix(Expression<E> e, String prefix) {
		return AddPrefixVisitor.INSTANCE.apply(e, prefix);
	}

	public static Set<Variable<?>> freeVariables(Expression<?> e) {
		Set<Variable<?>> vars = new HashSet<Variable<?>>();
		e.collectFreeVariables(vars);
		return vars;
	}

	public static Valuation stripPrefix(Valuation v, String prefix) {
		Valuation ret = new Valuation();
		for (ValuationEntry<?> e : v)
			stripEntryPrefix(e, prefix, ret);
		return ret;
	}

	private static <E> void stripEntryPrefix(ValuationEntry<E> entry, String prefix, Valuation target) {
		Variable<E> var = entry.getVariable();
		String name = var.getName();
		if (name.startsWith(prefix))
			var = Variable.create(var.getType(), name.substring(prefix.length()));
		target.setValue(var, entry.getValue());
	}

	public static Expression<Boolean> combine(LogicalOperator op, Expression<Boolean> def,
			Iterable<? extends Expression<Boolean>> expressions) {
		Iterator<? extends Expression<Boolean>> it = expressions.iterator();

		if (!it.hasNext())
			return def;

		Expression<Boolean> curr = it.next();

		while (it.hasNext()) {
			Expression<Boolean> next = it.next();
			curr = new PropositionalCompound(curr, op, next);
		}

		return curr;
	}

	public static Expression<Boolean> not(Expression<Boolean> negated) {
		if (negated instanceof Negation)
			return ((Negation) negated).getNegated();
		else if (negated instanceof NumericBooleanExpression){
			NumericBooleanExpression numCompare = (NumericBooleanExpression)negated;
			NumericComparator comparator = numCompare.getComparator().not();
			return new NumericBooleanExpression(numCompare.getLeft(),comparator,numCompare.getRight());
		}
		return new Negation(negated);
	}
	

	public static Expression<Boolean> xor(Expression<Boolean> expr1,Expression<Boolean> expr2) {
		return new PropositionalCompound(expr1,LogicalOperator.XOR,expr2);
	}
	
	@SafeVarargs
	public static Expression<Boolean> or(Expression<Boolean>... expressions) {
		return or(Arrays.asList(expressions));
	}

	public static Expression<Boolean> or(Iterable<? extends Expression<Boolean>> expressions) {
		return combine(LogicalOperator.OR, FALSE, expressions);
	}

	@SafeVarargs
	public static Expression<Boolean> and(Expression<Boolean>... expressions) {
		return and(Arrays.asList(expressions));
	}

	public static Expression<Boolean> and(Iterable<? extends Expression<Boolean>> expressions) {
		return combine(LogicalOperator.AND, TRUE, expressions);
	}

	public static <T> Expression<T> restrict(Expression<T> expr, Predicate<? super Variable<?>> pred) {
		return ExpressionRestrictionVisitor.getInstance().apply(expr, pred);
	}

	public static <T> Expression<T> transformVars(Expression<T> expr,
			Function<? super Variable<?>, ? extends Expression<?>> transform) {
		return TransformVarVisitor.getInstance().apply(expr, transform);
	}

	public static <T> Expression<T> renameVars(Expression<T> expr, Function<String, String> rename) {
		return RenameVarVisitor.getInstance().apply(expr, rename);
	}

	public static String toParseableString(Expression<?> expression) {
		Set<Variable<?>> freeVars = freeVariables(expression);

		if (freeVars.isEmpty())
			return expression.toString();

		StringBuilder sb = new StringBuilder();

		sb.append("declare ");

		try {
			boolean first = true;
			for (Variable<?> var : freeVars) {
				if (first)
					first = false;
				else
					sb.append(", ");
				var.printTyped(sb);
			}
			sb.append(" in ");
			expression.print(sb);

			return sb.toString();
		} catch (IOException ex) {
			throw new RuntimeException("Unexpected IOException while writing to a StringBuilder");
		}
	}

	public static Expression<Boolean> valuationToExpression(Valuation val) {
		Expression<Boolean> result = null;
		for (ValuationEntry<?> e : val) {
			result = addValuationEntryExpression(e, result);
		}
		return result;
	}

	private static <T> Expression<Boolean> addValuationEntryExpression(ValuationEntry<T> e, Expression<Boolean> expr) {
		Variable<T> var = e.getVariable();
		Type<T> type = var.getType();
		T value = e.getValue();
		Expression<Boolean> newExpr;
		if (BuiltinTypes.BOOL.equals(type)) {
			Expression<Boolean> bvar = var.as(BuiltinTypes.BOOL);
			if ((Boolean) value) {
				newExpr = bvar;
			} else {
				newExpr = new Negation(bvar);
			}
		} else {
			Constant<T> cnst = Constant.create(type, value);
			newExpr = new NumericBooleanExpression(var, NumericComparator.EQ, cnst);
		}
		return (expr == null) ? newExpr : ExpressionUtil.and(newExpr, expr);
	}

	public static int nestingDepth(Expression<?> expr) {
		return NestingDepthVisitor.getInstance().apply(expr);
	}

	public static Valuation combineValuations(Iterable<? extends Valuation> vals) {
		Valuation ret = new Valuation();

		for (Valuation v : vals) {
			ret.putAll(v);
		}

		return ret;
	}

	public static Valuation combineValuations(Valuation... vals) {
		return combineValuations(Arrays.asList(vals));
	}

	public static <T> Expression<T> partialEvaluate(Expression<T> expr, Valuation val) {
		return simplify(partialEvaluate(expr, val));
	}

	// LEGACY API

	@Deprecated
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Set<Variable> getVariables(Expression e) {
		return (Set<Variable>) (Set) freeVariables(e); // This may not look like
														// it's safe, but it
														// is..
	}

	@Deprecated
	public static Expression<Boolean> combine(Iterable<? extends Expression<Boolean>> expressions, LogicalOperator op) {
		return combine(op, null, expressions);
	}

	public static <T> Expression<Boolean> makeEqualityExpression(ArrayExpression<T> left, ArrayExpression<T> right) {
		if (left instanceof ArrayConstant && right instanceof ArrayConstant){
			Expression<T>[] lArr = ((ArrayConstant<T>)left).getValue();
			Expression<T>[] rArr = ((ArrayConstant<T>)right).getValue();
			Expression<Boolean> result=null;
			for(int i=0;i<lArr.length;i++)
				if (result==null)
					result = makeEqualityExpression(lArr[i], rArr[i]);
				else
					result = new PropositionalCompound(result,LogicalOperator.AND, makeEqualityExpression(lArr[i], rArr[i]));
			return result;
		}
		//not all is constant
		Expression<T>[] consArr;
		ArrayExpression<T> arrExpr;
		if (left instanceof ArrayConstant){
			consArr = ((ArrayConstant<T>)left).getValue();
			arrExpr = right;
		} else if (right instanceof ArrayConstant){
			consArr = ((ArrayConstant<T>)right).getValue();
			arrExpr = left;
		}else{
			consArr=null;
			arrExpr=null;
		}
		
		if (consArr==null)
			return NumericBooleanExpression.create(left, NumericComparator.EQ, right);
		
		//array and constant
		Expression<Boolean> result=null;
		for(int i=0;i<arrExpr.getArrayType().getLength();i++){
			SelectExpression<T> select = new SelectExpression<>(arrExpr, i);
			if (result==null)
				result = makeEqualityExpression(select, consArr[i]);
			else
				result = new PropositionalCompound(result,LogicalOperator.AND, makeEqualityExpression(select, consArr[i]));
		}
		return result;
	}
	
	public static <T> Expression<Boolean> makeEqualityExpression(Expression<T> left, Expression<T> right) {		
		if (left.getType().equals(BuiltinTypes.BOOL)){			
			if (isBoolConst(right, true))
				return left.requireAs(BuiltinTypes.BOOL);
			if (isBoolConst(right, false))
				return makeNegation(left.requireAs(BuiltinTypes.BOOL));
			
			if (isBoolConst(left, true))
				return right.requireAs(BuiltinTypes.BOOL);
			if (isBoolConst(left, false))
				return makeNegation(right.requireAs(BuiltinTypes.BOOL));
			
			return new PropositionalCompound(left.requireAs(BuiltinTypes.BOOL), LogicalOperator.EQUIV,
					right.requireAs(BuiltinTypes.BOOL));
		}else if (left instanceof ArrayExpression && right instanceof ArrayExpression)
			return makeEqualityExpression((ArrayExpression<T>)left, (ArrayExpression<T>)right);
		else
			return NumericBooleanExpression.create(left, NumericComparator.EQ, right);
	}

	private static Expression<Boolean> makeNegation(Expression<Boolean> expr) {
		if (expr instanceof Negation)
			return ((Negation) expr).getNegated();
		if (expr instanceof NumericBooleanExpression){
			NumericBooleanExpression numExpr = ((NumericBooleanExpression) expr);
			return new NumericBooleanExpression(numExpr.getLeft(),numExpr.getComparator().not(),numExpr.getRight());
		}
		return new Negation(expr);
	}

	public static <T> Expression<Boolean> makeNotEqualExpression(Expression<T> left, Expression<T> right) {
		return makeNegation(makeEqualityExpression(left, right));
	}

	public static void mk_adder(int num_bits, Expression<Boolean> in[], int _in1, int _in2,
			Expression<Boolean> result[], int _out) {
		Expression<Boolean> cout;
		int i;
		cout = FALSE;
		for (i = 0; i < num_bits; i++) {
			Expression<Boolean> in_1 = in[i + _in1];
			Expression<Boolean> in_2 = in[i + _in2];
			result[_out+i] = xor(xor(in_1, in_2), cout);			
			cout = or(and(in_1, in_2), and(in_1, cout), and(in_2, cout));
			//result[_out + i] = new PropositionalCompound(new PropositionalCompound(in_1, LogicalOperator.XOR, in_2),LogicalOperator.XOR, cout);
			//cout = or(and(in_1, in_2), and(in_1, cout), and(in_2, cout));
		}
		result[_out + num_bits] = cout;
	}

	public static int mk_adder_pairs(int num_bits, int num_ins, Expression<Boolean> in[],Expression<Boolean> out[]) {
		int out_num_bits = num_bits + 1;
		int i = 0;

		int out_num_ins = (num_ins % 2 == 0) ? (num_ins / 2) : (num_ins / 2) + 1;

		int _in1 = 0, _in2;
		int _out = 0;

		for (i = 0; i < num_ins / 2; i++) {
			_in2 = _in1 + num_bits;
			writeDebug("_in1: " + _in1 + ", _in2: " + _in2 + ", _out: " + _out);
			writeDebug("in: " + in);
			writeDebug("out: " + out);

			mk_adder(num_bits, in, _in1, _in2, out, _out);
			writeDebug("new out: " + out);

			_out += out_num_bits;

			_in1 += num_bits;
			_in1 += num_bits;
		}

		if (num_ins % 2 != 0) {
			for (i = 0; i < num_bits; i++) {
				out[_out + i] = in[_in1 + i];
			}
			out[_out + num_bits] = FALSE;
		}
		writeDebug("out_num_ins: " + out_num_ins + "\nnew out: " + out);
		return out_num_ins;
	}

	public static Expression<Boolean>[] mk_counter_circuit(Expression<Boolean>[] lits) {
		int out_sz;
		int n = lits.length;
		int num_ins = n;
		int num_bits = 1;
		Expression<Boolean>[] aux_1;
		Expression<Boolean>[] aux_2;

		if (n == 0)
			return null;

		aux_1 = Arrays.copyOf(lits, n + 1);
		aux_2 = new Expression[n + 1];

		while (num_ins > 1) {
			int new_num_ins;
			new_num_ins = mk_adder_pairs(num_bits, num_ins, aux_1, aux_2);
			// new_num_ins = aux_2.length;
			num_ins = new_num_ins;
			num_bits++;
			Expression<Boolean>[] tmp = aux_1;
			aux_1 = aux_2;
			aux_2 = tmp;
		}
		out_sz = num_bits;
		aux_1 = Arrays.copyOf(aux_1, out_sz);
		return aux_1;
	}

	public static Expression<Boolean> mk_at_most_k(Expression<Boolean>[] lits, int k)
	{	
		 int n = lits.length;
		 Expression<Boolean>[] counter_bits;
	   int counter_bits_sz;
	   if (k >= n || n <= 1)
	       return TRUE; /* nothing to be done */
	   counter_bits = mk_counter_circuit(lits);
	   counter_bits_sz = counter_bits.length;
	   Expression<Boolean> le_k_constraint = assert_le_k(counter_bits, k);
	   return le_k_constraint;
	}
	
	public static Expression<Boolean> assert_le_k(Expression<Boolean>[] val, int k) {		
		Expression<Boolean> i1, i2, not_val, out;
		int idx;
		not_val = new Negation(val[0]);
		if (get_bit(k, 0))
			out = TRUE;
		else
			out = not_val;

		int n = val.length;
		
		for (idx = 1; idx < n; idx++) {
			not_val = not(val[idx]);
			if (get_bit(k, idx)) {
				i1 = not_val;
				i2 = out;
			} else {
				i1 = FALSE;
				i2 = FALSE;
			}
			out = or(i1, i2, and(not_val, out));
		}
		writeDebug("at-most-k:\n"+out+"\n");
		return out;
	}
	
	private static boolean get_bit(int val, int idx) {
		int mask = 1 << (idx & 31);
		return (val & mask) != 0;
	}

	public static Expression<Boolean> mk_at_most_one(Expression<Boolean>[] lits) {
		return mk_at_most_k(lits, 1);
	}
	
	private static int varId=0;
	public static Variable<Boolean> mk_fresh_bool_var(SolverContext ctx) {
		return new Variable<>(BuiltinTypes.BOOL,"@__aux_@"+varId++);
	}
	
	private static Variable<Boolean> mk_fresh_bool_var() {
		return new Variable<>(BuiltinTypes.BOOL,"@__aux_@"+varId++);
	}

	static Result fu_malik_maxsat_step(SolverContext ctx, ConstraintSolver s, Expression<Boolean>[] soft_cnstrs, Expression<Boolean> [] aux_vars,Valuation model) {		
		int num_soft_cnstrs = soft_cnstrs.length;
		writeDebug("fu_malik_maxsat_step: soft "+num_soft_cnstrs+", aux "+aux_vars.length);
		
		List<Expression<Boolean>> assumptions = new ArrayList();//Expression<Boolean> [num_soft_cnstrs];
		//Expression<Boolean> [] core;
		//int core_size;
		int i = 0;
		int k = 0;
		Expression<Boolean> [] block_vars;
		for (i = 0; i < num_soft_cnstrs; i++) {
			// Recall that we asserted (soft_cnstrs[i] \/ aux_vars[i])
			// So using (NOT aux_vars[i]) as an assumption we are actually forcing the
			// soft_cnstrs[i] to be considered.
			assumptions.add(not(aux_vars[i]));
		}
		List<Expression<Boolean>> core=new ArrayList<>();
		Result is_sat = ctx.solveUnsatCore(model, assumptions, core);// performCheck(s, assumptions);
		writeDebug("is_sat: "+is_sat);
		if (is_sat == Result.SAT) {
			writeDebug("SAT");
			writeDebug("fu_malik_maxsat_step: RETURN SUCCESS");
			return is_sat; // done
		} else if (is_sat== Result.UNSAT){
			//core = s.getUnsatCore();
			int core_size = core.size();
			block_vars = new Expression[core_size];
			k = 0;
			writeDebug("unsat core size: "+core_size);
			// update soft-constraints and aux_vars
			//TODO: heuristic to select assumption, highest weight is selected first
			for (i = 0; i < num_soft_cnstrs; i++) {
				int j;
				// check whether assumption[i] is in the core or not
				for (j = 0; j < core_size; j++) {
					if (assumptions.get(i).equals(core.get(j)))
						break;
				}
				if (j < core_size) {
					// assumption[i] is in the unsat core... so soft_cnstrs[i] is in the
					// unsat core
					Expression<Boolean> block_var = mk_fresh_bool_var(ctx);
					Expression<Boolean> new_aux_var = mk_fresh_bool_var(ctx);
					soft_cnstrs[i] = or(soft_cnstrs[i], block_var);
					//ctx.add(aux_vars[i]); //disable old auxiliary variable
					aux_vars[i] = new_aux_var;
					block_vars[k] = block_var;
					k++;
					// Add new constraint containing the block variable.
					// Note that we are using the new auxiliary variable to be able to use
					// it as an assumption.
					ctx.add(or(soft_cnstrs[i], new_aux_var));
				}
			}
			Expression<Boolean> at_most1 = mk_at_most_one(block_vars);
			if (!isTrue(at_most1))
				ctx.add(at_most1);
			writeDebug("fu_malik_maxsat_step: RETURN FALSE");
			return is_sat; // not done.
		}
		return is_sat; // not done.
	}
	
	public static Result fu_malik_maxsat_step(SolverContext ctx,List<Expression<Boolean>>  soft_cnstrs,List<Expression<Boolean>> aux_vars,Valuation model) {		
		int num_soft_cnstrs = soft_cnstrs.size();
		writeDebug("fu_malik_maxsat_step: soft "+num_soft_cnstrs+", aux "+aux_vars.size());
		
		List<Expression<Boolean>> assumptions = new ArrayList();//Expression<Boolean> [num_soft_cnstrs];
		int i = 0;
		int k = 0;
		Expression<Boolean> [] block_vars;
		for (i = 0; i < num_soft_cnstrs; i++) {
			// Recall that we asserted (soft_cnstrs[i] \/ aux_vars[i])
			// So using (NOT aux_vars[i]) as an assumption we are actually forcing the
			// soft_cnstrs[i] to be considered.
			assumptions.add(not(aux_vars.get(i)));
		}
		List<Expression<Boolean>> core=new ArrayList<>();
		Result is_sat = ctx.solveUnsatCore(model, assumptions, core);// performCheck(s, assumptions);
		writeDebug("is_sat: "+is_sat);
		if (is_sat == Result.SAT) {
			writeDebug("SAT");
			writeDebug("fu_malik_maxsat_step: RETURN SUCCESS");
			return is_sat; // done
		} else if (is_sat== Result.UNSAT){
			//core = s.getUnsatCore();
			int core_size = core.size();
			block_vars = new Expression[core_size];
			k = 0;
			writeDebug("unsat core size: "+core_size);
			// update soft-constraints and aux_vars
			//TODO: heuristic to select assumption, highest weight is selected first
			for (i = 0; i < num_soft_cnstrs; i++) {
				int j;
				// check whether assumption[i] is in the core or not
				for (j = 0; j < core_size; j++) {
					if (assumptions.get(i).equals(core.get(j)))
						break;
				}
				if (j < core_size) {
					// assumption[i] is in the unsat core... so soft_cnstrs[i] is in the
					// unsat core
					Expression<Boolean> block_var = ExpressionUtil.mk_fresh_var("@__B_@",BuiltinTypes.BOOL);
					Expression<Boolean> new_aux_var = ExpressionUtil.mk_fresh_var("@__aux_@",BuiltinTypes.BOOL);
					soft_cnstrs.set(i,or(soft_cnstrs.get(i), block_var));
					Expression<Boolean> oldAux = aux_vars.get(i);
					aux_vars.set(i, new_aux_var);
					block_vars[k] = block_var;
					k++;
					// Add new constraint containing the block variable.
					// Note that we are using the new auxiliary variable to be able to use
					// it as an assumption.
					ctx.add(oldAux);//disable old soft-clause
					ctx.add(or(soft_cnstrs.get(i), new_aux_var));
				}
			}
			Expression<Boolean> at_most1 = mk_at_most_one(block_vars);
			if (!isTrue(at_most1))
				ctx.add(at_most1);
			writeDebug("fu_malik_maxsat_step: RETURN FALSE");
			return is_sat; // not done.
		}
		return is_sat; // not done.
	}
	
	public static class MaxSatResult{
		final int size;
		Valuation model;
		Result satResult;
		public MaxSatResult(Result isSat,int size,Valuation model){
			this.satResult=isSat;
			this.size = size;
			this.model = model;
		}
		public Result getResult(){
			return this.satResult;
		}
		public int getMcsSize(){
			if (this.satResult == Result.SAT)
				return this.size;
			return -1;
		}
		public Valuation getModel(){
			if (this.satResult == Result.SAT)
				return this.model;
			throw new IllegalAccessError("Cannot get model when result is not SAT");
		}
		
		public static MaxSatResult UNSAT = new MaxSatResult(Result.UNSAT, -1, null);
		
		public static MaxSatResult create(Result isSat,int size,Valuation model){
			return new MaxSatResult(isSat, size, model);
		}
	}
	
	public static MaxSatResult fu_malik_maxsat(SolverContext ctx, ConstraintSolver s, List<Expression<Boolean>> hards,List<Expression<Boolean>> softs,int boundSize,Valuation model) {
	
		Expression<Boolean>[] hard_cnstrs = new Expression[hards.size()];
		Expression<Boolean>[] soft_cnstrs = new Expression[softs.size()];

		for (int i = 0; i < hards.size(); i++) {
			Expression<Boolean> ex = hards.get(i);
			hard_cnstrs[i] = ex;			
		}
		for (int i = 0; i < softs.size(); i++) {
			Expression<Boolean> ex = softs.get(i);
			soft_cnstrs[i] = ex;
		}
		int num_hard_cnstrs = hard_cnstrs.length;
		int num_soft_cnstrs = soft_cnstrs.length;
		Expression<Boolean>[] aux_vars;
		
		assert_hard_constraints(ctx, hard_cnstrs);

		writeDebug("checking whether hard constraints are satisfiable...");		
		Result is_sat = ctx.solve(model);
		if (is_sat == Result.UNSAT) {
			// It is not possible to make the formula satisfiable even when ignoring
			// all soft constraints.
			return MaxSatResult.UNSAT;
		}
		if (num_soft_cnstrs == 0)
			return MaxSatResult.create(is_sat, 0, model); // nothing to be done...
		/*
		 * Fu&Malik algorithm is based on UNSAT-core extraction. We accomplish that
		 * using auxiliary variables (aka answer literals).
		 */
		aux_vars = assert_soft_constraints(ctx, soft_cnstrs);
		for (int k=0;k<=boundSize;k++) {
			writeDebug("iteration "+ k);
			model.reset();
			is_sat =fu_malik_maxsat_step(ctx, s, soft_cnstrs, aux_vars,model); 
			if (is_sat ==Result.SAT) {
				return MaxSatResult.create(is_sat, k, model);
			}
		}
		return MaxSatResult.UNSAT;
	}
	
	public static int fu_malik_maxsat(SolverContext ctx, ConstraintSolver s, Expression<Boolean>[] hard_cnstrs, Expression<Boolean>[] soft_cnstrs,int boundSize,Valuation model) {
		int num_hard_cnstrs = hard_cnstrs.length;
		int num_soft_cnstrs = soft_cnstrs.length;
		Expression<Boolean>[] aux_vars;
		
		assert_hard_constraints(ctx, hard_cnstrs);

		writeDebug("checking whether hard constraints are satisfiable...");		
		Result is_sat = ctx.solve(model);
		if (is_sat == Result.UNSAT) {
			// It is not possible to make the formula satisfiable even when ignoring
			// all soft constraints.
			return -1;
		}
		if (num_soft_cnstrs == 0)
			return 0; // nothing to be done...
		/*
		 * Fu&Malik algorithm is based on UNSAT-core extraction. We accomplish that
		 * using auxiliary variables (aka answer literals).
		 */
		aux_vars = assert_soft_constraints(ctx, soft_cnstrs);
		for (int k=0;k<boundSize;k++) {
			writeDebug("iteration "+ k);
			model.reset();
			Result result =fu_malik_maxsat_step(ctx, s, soft_cnstrs, aux_vars,model); 
			if (result ==Result.SAT) {
				return num_soft_cnstrs - k;
			}
		}
		return -1;
	}
	
	public static List<Valuation> fu_malik_maxsat_all(int maxBound, SolverContext ctx, ConstraintSolver s, Expression<Boolean>[] hard_cnstrs, Expression<Boolean>[] soft_cnstrs) {
		writeDebug("fu_malik_maxsat: BEGIN (max "+maxBound+", #hards "+hard_cnstrs.length+", #softs "+soft_cnstrs.length+")");
		int num_soft_cnstrs = soft_cnstrs.length; 
		Expression<Boolean>[] aux_vars;
		int k;
		List<Valuation> modelSet = new ArrayList<>();
		
		assert_hard_constraints(ctx, hard_cnstrs);
		
		writeDebug("checking whether hard constraints are satisfiable...");
		Valuation model=new Valuation();
		Result is_sat = ctx.solve(model);
		if (is_sat == Result.UNSAT) {
			writeDebug("hard constraints UNSAT");
			// It is not possible to make the formula satisfiable even when ignoring
			// all soft constraints.
			writeDebug("fu_malik_maxsat: RETURN UNSAT");
			return modelSet; //return emptySet
		}		
		
		writeDebug("hard constraints SAT, Number of soft constraints: "+num_soft_cnstrs);
		if (num_soft_cnstrs == 0){			
			modelSet.add(model);
			writeDebug("fu_malik_maxsat: RETURN SAT");
			return modelSet; // nothing to be done...
		}
		/*
		 * Fu&Malik algorithm is based on UNSAT-core extraction. We accomplish that
		 * using auxiliary variables (aka answer literals).
		 */
		aux_vars = assert_soft_constraints(ctx,soft_cnstrs);
		
		Expression<Boolean>[] aux_saved = Arrays.copyOf(aux_vars, aux_vars.length);
		k = 0;
		
		while (k<=maxBound) {
			writeDebug("iteration "+ k);
			model = new Valuation();
			Result result = fu_malik_maxsat_step(ctx, s, soft_cnstrs, aux_vars,model); 
			if (result== Result.SAT) {
				//found a MCS				
				modelSet.add(model);
				writeDebug("Number of SAT Clauses: " +(num_soft_cnstrs - k));
				/*if (MAXSAT_DEBUG){
					System.out.println("Number of SAT Clauses: " +(num_soft_cnstrs - k));
					//System.out.println("Soft Constraints: ");
					//for(int i=0;i<soft_cnstrs.length;i++)
					//	System.out.println(i+") "+ model.evaluate(soft_cnstrs[i],false)+" :=> "+soft_cnstrs[i]);
					//System.out.println("aux vars: ");
					//for(int i=0;i<aux_vars.length;i++)
					//	System.out.println(i+") "+ model.evaluate(aux_vars[i],false)+" :=> "+aux_vars[i]);
					
					System.out.println("aux_vars saved: ");
					for(int i=0;i<aux_saved.length;i++)
						System.out.println(i+") "+ model.evaluate(aux_saved[i],false)+" :=> "+aux_saved[i]);
					
						//System.out.println("Model: "+model);
						//System.out.println("Model: "+model);
				}*/
				//create block_var
				 Expression<Boolean>[] block_expression = new  Expression[k];
				int j=0;
				for(int i=0;i<aux_saved.length;i++){
					if ( aux_saved[i].evaluate(model).equals(true))
						block_expression[j++]=aux_saved[i];
				}
				 Expression<Boolean> block = not(and(block_expression));
				ctx.add(block);				
			}else
				k++;
		}
		writeDebug("fu_malik_maxsat: RETURN SAT, #models "+modelSet.size());
		return modelSet;
	}
	
	@SuppressWarnings("unchecked")
	public static List<Valuation> solveMaxSAT(int maxMCSBound,SolverContext ctx, ConstraintSolver solver, List<Expression<Boolean>> hards,List<Expression<Boolean>> softs) {
		//Map<String, Variable<?>> fvMap = new HashMap<>();

		Expression<Boolean>[] hard_cnstrs = new Expression[hards.size()];
		Expression<Boolean>[] soft_cnstrs = new Expression[softs.size()];

		for (int i = 0; i < hards.size(); i++) {
			Expression<Boolean> ex = hards.get(i);
			hard_cnstrs[i] = ex;
			Set<Variable<?>> fvs = ExpressionUtil.freeVariables(ex);
			/*for (Variable<?> v : fvs)
				fvMap.put(v.getName(), v);*/
		}
		for (int i = 0; i < softs.size(); i++) {
			Expression<Boolean> ex = softs.get(i);
			soft_cnstrs[i] = ex;
			Set<Variable<?>> fvs = ExpressionUtil.freeVariables(ex);
			/*for (Variable<?> v : fvs)
				fvMap.put(v.getName(), v);*/
		}
		List<Valuation> modelSet = fu_malik_maxsat_all(maxMCSBound, ctx, solver, hard_cnstrs,soft_cnstrs);
		
		List<Valuation> valResults = new ArrayList<>();
		if (modelSet == null)
			return valResults; // UNSAT
		return modelSet;

		/*for (Valuation m : modelSet) {
			Valuation returnModel = new Valuation();
			//getValuationFromModel(val, m, fvMap);
			for(Entry<String, Variable<?>> en:fvMap.entrySet()){
				Variable v = en.getValue();
				if (m.containsValueFor(v))
					returnModel.setValue(v, m.getValue(v));
				else
					returnModel.setDefaultValue(v);
			}
			valResults.add(returnModel);
		}
		return valResults;*/
	}
	
	public static List<Expression<Boolean>> makeRelaxableConstraints(List<Expression<Boolean>> constraints) {
		int num_cnstrs = constraints.size();
		int i;
		List<Expression<Boolean>> aux_vars=new ArrayList<>();		
		for (i = 0; i < num_cnstrs; i++) {			
			Variable<Boolean> aux =mk_fresh_var("__aux_var", BuiltinTypes.BOOL); 
			aux_vars.add(aux);
			Expression<Boolean> origin =constraints.get(i);
			Expression<Boolean> newClause =or(origin, aux); 
			constraints.set(i, newClause);			
		}
		return aux_vars;
	}
	static Expression<Boolean>[] assert_soft_constraints(SolverContext ctx, Expression<Boolean>[] cnstrs) {
		int num_cnstrs = cnstrs.length;
		int i;
		Expression<Boolean>[] aux_vars;
		aux_vars = mk_fresh_bool_var_array(ctx, num_cnstrs);
		for (i = 0; i < num_cnstrs; i++) {
			Expression<Boolean> assumption = cnstrs[i];
			ctx.add(or(assumption, aux_vars[i]));
		}
		return aux_vars;
	}

	static Expression<Boolean>[] mk_fresh_bool_var_array(SolverContext ctx, int num_vars) {
		Expression<Boolean>[] result = new Expression[num_vars];
		int i;
		for (i = 0; i < num_vars; i++) {
			result[i] = mk_fresh_bool_var(ctx);
		}
		return result;
	}
	
	/**
	 * \brief Assert hard constraints stored in the given array.
	 */
	static void assert_hard_constraints(SolverContext ctx, Expression<Boolean>[] cnstrs) {
		int num_cnstrs = cnstrs.length;
		int i;
		for (i = 0; i < num_cnstrs; i++) {
			ctx.add(cnstrs[i]);
		}
	}
	
	static final boolean DEBUG = false;
	private static void writeDebug(String msg) {
		if (DEBUG)
			System.out.println(msg);
	}
	

	public static void tst_at_most_one(SolverContext s) 
	{
		Expression<Boolean> k1      = Variable.create(BuiltinTypes.BOOL,"k1");
		Expression<Boolean> k2      =  Variable.create(BuiltinTypes.BOOL,"k2");
		Expression<Boolean> k3      =  Variable.create(BuiltinTypes.BOOL,"k3");
		Expression<Boolean> k4      =  Variable.create(BuiltinTypes.BOOL, "k4");
		Expression<Boolean> k5      =  Variable.create(BuiltinTypes.BOOL,"k5");
		Expression<Boolean> k6      = Variable.create(BuiltinTypes.BOOL, "k6");
		Expression<Boolean>[] args1 = new Expression[]{ k1, k2, k3, k4, k5 };
		Expression<Boolean>[] args2 = new Expression[]{ k4, k5, k6 };
	    Valuation m      = new Valuation();
	    Result result;
	    System.out.printf("testing at-most-one constraint\n");
	    Expression<Boolean> cons = mk_at_most_one(args1);
	    s.add(cons);
	    Expression<Boolean> cons2 = mk_at_most_one(args2);
	    s.add(cons2);
	    System.out.printf("it must be sat...\n");
	    result = s.solve(m);
	    if (result != Result.SAT)
	    	System.out.printf("BUG");	    
	    System.out.printf("model:\n%s\n",  m);
	    s.add(or(k2, k3));
	    s.add(or(k1, k6));
	    System.out.printf("it must be sat...\n");
	    m=new Valuation();
	    result = s.solve(m);
	    if (result != Result.SAT)
	    	System.out.printf("BUG");	    
	    System.out.printf("model:\n%s\n", m);
	    s.add(or(k4, k5));
	    System.out.printf("it must be unsat...\n");
	    m=new Valuation();
	    result = s.solve(m);
	    if (result != Result.SAT)
	    	System.out.printf("UNSAT");	    
	}

	static Map<String, Integer> fresh_var_map = new HashMap<>();
	public static <T> Variable<T> mk_fresh_var(String name, Type<T> type) {
		Integer id = fresh_var_map.get(name);
		if (id==null)
			id=0;
		id++;
		fresh_var_map.put(name, id);
		return Variable.create(type, name+id);
	}

	public static List<Variable> collectAllFreeVariables(List<Expression> listExprs){
		List<Variable> result = new ArrayList<>();
		for(Expression exp:listExprs){
			List<Variable> variables = new ArrayList<>();
			exp.collectFreeVariables(variables);
			for(Variable var:variables){
				if (!result.contains(var))
					result.add(var);								
			}
		}
		return result;
	}
	
	public static <T> Expression<Boolean>[] buildPartitionConstraints(Expression<T> symbExpr,T[] matchValues) {
		int numTargets = matchValues.length;
		@SuppressWarnings("unchecked")
		Expression<Boolean>[] result = new Expression[numTargets+1];
		Expression<Boolean> defaultExpr = null;
		for (int i = 0; i < numTargets; i++) {
			T tgtVal = matchValues[i];
			Constant<T> c = Constant.create(symbExpr.getType(), tgtVal);
			Expression<Boolean> posExpr = ExpressionUtil.makeEqualityExpression(symbExpr, c);
			result[i] = posExpr;
			Expression<Boolean> negExpr = ExpressionUtil.makeNotEqualExpression(symbExpr, c);
			if (defaultExpr == null)
				defaultExpr = negExpr;
			else
				defaultExpr = new PropositionalCompound(defaultExpr, LogicalOperator.AND, negExpr);
		}
		result[numTargets] = defaultExpr;

		return result;
	}

}
