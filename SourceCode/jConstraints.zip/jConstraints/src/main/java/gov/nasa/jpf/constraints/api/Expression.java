/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 *
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 *
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */
package gov.nasa.jpf.constraints.api;

import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.constraints.util.AbstractPrintable;
import gov.nasa.jpf.constraints.util.Printable;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.Set;



/**
 * Expressions consist of terms, and can be evaluated E
 */
public interface Expression<E> extends Printable {
  
  
  public static final int QUOTE_IDENTIFIERS = 1;
  public static final int INCLUDE_VARIABLE_TYPE = 2;
  public static final int INCLUDE_BOUND_DECL_TYPE = 4;
  public static final int SIMPLE_PROP_OPERATORS = 8;
  
  public static final int DEFAULT_FLAGS = QUOTE_IDENTIFIERS | INCLUDE_BOUND_DECL_TYPE;
  
  public static final int JAVA_COMPAT_FLAGS = SIMPLE_PROP_OPERATORS;
 
  public static Expression<?>[] NO_CHILDREN = new Expression[0];
  
    
  /**
   * evaluates using the provided values for symbolic variables
   * 
   * @param values
   * @return 
   */
  public E evaluate(Valuation values);  
  
  /**
   * collect all symbolic variables
   * 
   * @param names 
   */
  public void collectFreeVariables(Collection<? super Variable<?>> variables);
  
  public <R,D> R accept(ExpressionVisitor<R, D> visitor, D data);
  
  
  public Type<E> getType();
  
  public Class<E> getResultType();
  
  
  public Expression<?>[] getChildren();
  public Expression<?> duplicate(Expression<?>[] newChildren);
  
  @SuppressWarnings("unchecked")
  public <F> Expression<F> as(Type<F> type);
  
  public <F> Expression<F> requireAs(Type<F> type);
  
  public void print(Appendable a, int flags) throws IOException;

  /**A malformed Expression might contain a null value.
  This method should only be used in debug environment
   * @throws java.io.IOExceptions*/
  public void printMalformedExpression(Appendable a, int flags)
          throws IOException;

  public String toString(int flags);  
  
  public void printMalformedExpression(Appendable a) throws IOException ;

  
  // LEGACY API
  
  /**
   * replace terms according to replace
   * 
   * @param replace
   * @return 
   */
  @Deprecated
  @SuppressWarnings("rawtypes")
  public Expression replaceTerms(Map<Expression,Expression> replacements);
  
  @Deprecated
  @SuppressWarnings("rawtypes")
  public void getVariables(Set<Variable> variables) ;
}
