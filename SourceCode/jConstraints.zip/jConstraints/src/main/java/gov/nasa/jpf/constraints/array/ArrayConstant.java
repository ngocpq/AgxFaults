package gov.nasa.jpf.constraints.array;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Collection;

import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.ExpressionVisitor;
import gov.nasa.jpf.constraints.api.Valuation;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.expressions.AbstractExpression;
import gov.nasa.jpf.constraints.expressions.Constant;
import gov.nasa.jpf.constraints.types.Type;

public class ArrayConstant<T> extends AbstractExpression<T[]> implements ArrayExpression<T> {

	private final ArrayType<T> arrType;
	private final Expression<T>[] arrValue;
	
	public static <T> ArrayConstant<T> create(ArrayType<T> type, T[] value){
		return new ArrayConstant<>(type, value);
	}
	
	public static <T> ArrayConstant<T> create(ArrayType<T> type, Expression<T>[] value){
		return new ArrayConstant<>(type, value);
	}
	  
	public ArrayConstant(ArrayType<T> type, Expression<T>[] value) {
		this.arrType = type;
		this.arrValue = value.clone();		
	}
	
	public ArrayConstant(ArrayType<T> type, T[] value) {
		this.arrType = type;
		this.arrValue = new Expression[value.length];
		for (int i = 0; i < value.length; i++) {
			this.arrValue[i] = Constant.create(arrType.getElementType(), value[i]);
		}
	}

	@Override
	public ArrayType<T> getArrayType() {
		return this.arrType;
	}

	@Override
	public T[] evaluate(Valuation values) {
		T[] result =  (T[]) Array.newInstance(arrType.getElementType().getCanonicalClass(), arrType.getLength());
		for(int i=0;i<arrType.getLength();i++){
			result[i] = this.arrValue[i].evaluate(values);
		}
		return result;
	}

	@Override
	public void collectFreeVariables(Collection<? super Variable<?>> variables) {
		for(int i=0;i<arrType.getLength();i++){
			this.arrValue[i].collectFreeVariables(variables);
		}
	}

	@Override
	public <R, D> R accept(ExpressionVisitor<R, D> visitor, D data) {
		return visitor.visit(this, data);
	}

	@Override
	public Type<T[]> getType() {
		return this.arrType;
	}

	@Override
	public Expression<T>[] getChildren() {
		Expression<T>[] rs = new Expression[this.arrType.getLength()];
		for(int i=0;i<arrType.getLength();i++){
			rs[i]=this.arrValue[i];
		}
		return rs;
	}

	@Override
	public Expression<?> duplicate(Expression<?>[] newChildren) {
		throw new UnsupportedOperationException("Unimplemented");
	}

	@Override
	public void print(Appendable a, int flags) throws IOException {
		a.append('[');
		for(int i=0;i<arrValue.length;i++){
			if (i>0)
				a.append(", ");
			arrValue[i].print(a,flags);
		}
		a.append(']');
	}

	@Override
	public void printMalformedExpression(Appendable a, int flags) throws IOException {
		a.append('[');
		for(int i=0;i<arrValue.length;i++){
			if (i>0)
				a.append(", ");
			if (arrValue[i]!=null)
				arrValue[i].print(a,flags);
			else
				a.append("null");
		}
		a.append(']');
	}
	
	public Expression<T>[] getValue(){
		return this.arrValue.clone();
	}
}
