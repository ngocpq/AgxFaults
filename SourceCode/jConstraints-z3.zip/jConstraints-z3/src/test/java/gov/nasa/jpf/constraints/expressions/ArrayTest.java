/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 *
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 *
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */
package gov.nasa.jpf.constraints.expressions;

import gov.nasa.jpf.constraints.api.ConstraintSolver;
import gov.nasa.jpf.constraints.api.ConstraintSolver.Result;
import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.SolverContext;
import gov.nasa.jpf.constraints.api.Valuation;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.array.ArrayConstant;
import gov.nasa.jpf.constraints.array.ArrayExpression;
import gov.nasa.jpf.constraints.array.ArrayType;
import gov.nasa.jpf.constraints.array.ArrayVariable;
import gov.nasa.jpf.constraints.array.SelectExpression;
import gov.nasa.jpf.constraints.array.StoreExpression;
import gov.nasa.jpf.constraints.expressions.functions.FunctionExpression;
import gov.nasa.jpf.constraints.expressions.functions.math.MathFunctions;
import gov.nasa.jpf.constraints.solvers.ConstraintSolverFactory;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import java.util.Properties;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

@Test
public class ArrayTest {

	 @Test
     public static void testLogic() {
		System.out.println("------ Test array theory -----");
		Properties conf = new Properties();     
        conf.setProperty("symbolic.dp", "z3");
        ConstraintSolverFactory factory = new ConstraintSolverFactory(conf);
        ConstraintSolver solver = factory.createSolver();        
        SolverContext ctx = solver.createContext();
        
        ArrayVariable a1 = new ArrayVariable<>("a1", BuiltinTypes.SINT32,3);
        ArrayVariable a2 = new ArrayVariable<>("a2", BuiltinTypes.SINT32,3);
        ArrayVariable a3 = new ArrayVariable<>("a3", BuiltinTypes.SINT32,3);
        
        Variable x = new Variable(BuiltinTypes.SINT32, "x");
        Variable y = new Variable(BuiltinTypes.SINT32, "y");
        Variable z = new Variable(BuiltinTypes.SINT32, "z");
        
        ctx.push();
        
        SelectExpression select_a1_x = new SelectExpression(a1, x);
        ctx.add(new NumericBooleanExpression(select_a1_x,NumericComparator.EQ,x));
        
        StoreExpression store_a1_x_y = new StoreExpression<>(a1, x, y);
        ctx.add(new NumericBooleanExpression(store_a1_x_y,NumericComparator.EQ,a1));
        
        Valuation val = new Valuation();
        Result r = ctx.solve(val);        
        System.out.println(r + ": " + val);        
        assert r == Result.SAT;
        
        ctx.add(new NumericBooleanExpression(x,NumericComparator.NE,y));
        val = new Valuation();
        r = ctx.solve(val); 
        System.out.println(r + ": " + val);        
        assert r == Result.UNSAT;
        
        ctx.pop();
        val = new Valuation();
        r = ctx.solve(val); 
        System.out.println(r + ": " + val);
        System.out.println("--------------");
	 }
	 @Test
     public static void testSelect() {
        Properties conf = new Properties();     
        conf.setProperty("symbolic.dp", "z3");
        ConstraintSolverFactory factory = new ConstraintSolverFactory(conf);
        ConstraintSolver solver = factory.createSolver();        
        SolverContext ctx = solver.createContext();     
     
        ArrayVariable arr1 = new ArrayVariable<>("a1", BuiltinTypes.SINT32,3);
        SelectExpression a0 = new SelectExpression(arr1, 0);
        SelectExpression a1 = new SelectExpression(arr1, 1);
        SelectExpression a2 = new SelectExpression(arr1, 2);
        
        Variable x = new Variable(BuiltinTypes.SINT32, "x");
        Variable y = new Variable(BuiltinTypes.SINT32, "y");
        
        
        ArrayVariable arr2 = new ArrayVariable<>("a1", BuiltinTypes.SINT32,3);
        
        Expression expr = new NumericBooleanExpression(a0,NumericComparator.EQ,x);
        ctx.add(expr);
        
        Constant<Integer> m = Constant.create(BuiltinTypes.SINT32, 3);        
        Expression expr2 = new NumericBooleanExpression(x,NumericComparator.EQ,m);
        ctx.add(expr2);
        
        Valuation val = new Valuation();
        Result r = ctx.solve(val);
        System.out.println(r + ": " + val);
     }
     
     @SuppressWarnings({ "rawtypes", "unchecked" })
     @Test
	public static void testStore() {
         Properties conf = new Properties();     
         conf.setProperty("symbolic.dp", "z3");
         ConstraintSolverFactory factory = new ConstraintSolverFactory(conf);
         ConstraintSolver solver = factory.createSolver();        
         SolverContext ctx = solver.createContext(); 
      
         Constant<Integer> three = Constant.create(BuiltinTypes.SINT32, 3);
         Constant<Integer> two = Constant.create(BuiltinTypes.SINT32, 2);
         Constant<Integer> one = Constant.create(BuiltinTypes.SINT32, 1);
         Constant<Integer> zero = Constant.create(BuiltinTypes.SINT32, 0);
         
         ArrayVariable a = new ArrayVariable<>("a", BuiltinTypes.SINT32,3);
         ArrayVariable b = new ArrayVariable<>("b", BuiltinTypes.SINT32,3);
         ArrayVariable c = new ArrayVariable<>("c", BuiltinTypes.SINT32,3);
         ArrayVariable d = new ArrayVariable<>("d", BuiltinTypes.SINT32,3);
         
         SelectExpression select_a_0 = new SelectExpression(a, 0);
         SelectExpression select_a_1 = new SelectExpression(a, 1);
         SelectExpression select_a_2 = new SelectExpression(a, 2);
         
          //a = [1,2,..]
         /*ctx.add(new NumericBooleanExpression(select_a_0,NumericComparator.EQ,zero));
         ctx.add(new NumericBooleanExpression(select_a_1,NumericComparator.EQ,one));
         ctx.add(new NumericBooleanExpression(select_a_2,NumericComparator.EQ,one));*/
         
         
         // store = a[0] <- 3
         StoreExpression store1 = new StoreExpression<>(a, 0, 10);         
         StoreExpression store2 = new StoreExpression<>(store1, 1, 11);
         StoreExpression store3 = new StoreExpression<>(store2, 2, 12);
         //c = [1,2,3]
         
       //b = [1,2,3]
         ctx.add(new NumericBooleanExpression(b,NumericComparator.EQ,store3));
         
         
        /* SelectExpression<Object> select_a_0 = new SelectExpression<>(store3, 0);
         SelectExpression<Object> select_a_1 = new SelectExpression<>(store3, 1);
         SelectExpression<Object> select_a_2 = new SelectExpression<>(store3, 2);*/
         
         /*ctx.add(new NumericBooleanExpression(select_a_0,NumericComparator.EQ,zero));
         ctx.add(new NumericBooleanExpression(select_a_1,NumericComparator.EQ,one));
         ctx.add(new NumericBooleanExpression(select_a_2,NumericComparator.EQ,two));*/
         
         Valuation val = new Valuation();
         Result r = ctx.solve(val);
         System.out.println(r + ": " + val);
      }
     
//     @SuppressWarnings({ "rawtypes", "unchecked" })
//     @Test
//  	public static void testArrayConstance() {
//           Properties conf = new Properties();     
//           conf.setProperty("symbolic.dp", "z3");
//           ConstraintSolverFactory factory = new ConstraintSolverFactory(conf);
//           ConstraintSolver solver = factory.createSolver();        
//           SolverContext ctx = solver.createContext(); 
//
//           Integer[] arrInt = new Integer[]{1,2,3};
//           ArrayType aType = new ArrayType(BuiltinTypes.SINT32, 3);
//           
//           ArrayExpression a = (ArrayExpression) ArrayConstant.create(aType, arrInt);
//           
//           SelectExpression a0 = new SelectExpression(a, 0);
//           SelectExpression a1 = new SelectExpression(a, 1);
//           SelectExpression select_a_2 = new SelectExpression(a, 2);
//           
//           Variable x = new Variable(BuiltinTypes.SINT32, "x");
//           ctx.add(new NumericBooleanExpression(x,NumericComparator.EQ,select_a_2));
//           //ctx.add(new NumericBooleanExpression(x,NumericComparator.EQ,a1));
//           
//           Valuation val = new Valuation();
//           Result r = ctx.solve(val);
//           System.out.println(r + ": " + val);           
//     }
     
     @SuppressWarnings({ "rawtypes", "unchecked" })
     @Test
 	public static void testSlectAndStore() {
          Properties conf = new Properties();     
          conf.setProperty("symbolic.dp", "z3");
          ConstraintSolverFactory factory = new ConstraintSolverFactory(conf);
          ConstraintSolver solver = factory.createSolver();        
          SolverContext ctx = solver.createContext(); 
       
          ArrayVariable a = new ArrayVariable<>("a", BuiltinTypes.SINT32,3);
          ArrayVariable b = new ArrayVariable<>("b", BuiltinTypes.SINT32,3);
          ArrayVariable c = new ArrayVariable<>("c", BuiltinTypes.SINT32,3);
          ArrayVariable d = new ArrayVariable<>("d", BuiltinTypes.SINT32,3);
          
          SelectExpression a0 = new SelectExpression(a, 0);
          SelectExpression a1 = new SelectExpression(a, 1);
          SelectExpression a2 = new SelectExpression(a, 2);
          
          Constant<Integer> three = Constant.create(BuiltinTypes.SINT32, 3);
          Constant<Integer> two = Constant.create(BuiltinTypes.SINT32, 2);
          Constant<Integer> one = Constant.create(BuiltinTypes.SINT32, 1);
          
          //a = [1,2,3]
          //ctx.add(new NumericBooleanExpression(a0,NumericComparator.EQ,one));
          //ctx.add(new NumericBooleanExpression(a1,NumericComparator.EQ,two));
          ctx.add(new NumericBooleanExpression(a2,NumericComparator.EQ,three));
          
          ArrayExpression<Integer> tmp = new StoreExpression<>(new StoreExpression<>(a, 2, one),0,three);
          //b = [2,2,2]
          ctx.add(new NumericBooleanExpression(b,NumericComparator.EQ,tmp));
          
//          // store = a[0] <- 3
//          StoreExpression store1 = new StoreExpression<>(a, 0, three);         
//          StoreExpression store2 = new StoreExpression<>(store1, 2, one);
//          //c = [1,2,3]
//          ctx.add(new NumericBooleanExpression(store2,NumericComparator.EQ,c));
//          
//          SelectExpression d0 = new SelectExpression(d, 0);
//          SelectExpression d1 = new SelectExpression(d, 1);
//          SelectExpression d2 = new SelectExpression(d, 2);
//          ctx.add(new NumericBooleanExpression(d1,NumericComparator.EQ,two));
//          ctx.add(new NumericBooleanExpression(d2,NumericComparator.EQ,three));
         
          Variable x = new Variable(BuiltinTypes.SINT32, "x");
          ctx.add(new NumericBooleanExpression(x,NumericComparator.EQ,a2));
          //ctx.add(new NumericBooleanExpression(x,NumericComparator.EQ,a1));
          
          Valuation val = new Valuation();
          Result r = ctx.solve(val);
          System.out.println(r + ": " + val);
       }
     
     public static void main(String[] args) {
//    	 testLogic();
//    	 testSelect();
    	 testStore();
//    	 testSlectAndStore();
//    	 testArrayConstance();
	}
}
