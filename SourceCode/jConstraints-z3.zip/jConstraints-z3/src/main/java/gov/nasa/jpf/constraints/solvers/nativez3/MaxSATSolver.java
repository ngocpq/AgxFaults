package gov.nasa.jpf.constraints.solvers.nativez3;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.microsoft.z3.AST;
import com.microsoft.z3.ASTVector;
import com.microsoft.z3.BoolExpr;
import com.microsoft.z3.Context;
import com.microsoft.z3.Expr;
import com.microsoft.z3.FuncDecl;
import com.microsoft.z3.IntExpr;
import com.microsoft.z3.Model;
import com.microsoft.z3.Solver;
import com.microsoft.z3.Sort;
import com.microsoft.z3.Statistics.Entry;
import com.microsoft.z3.Status;
import com.microsoft.z3.Symbol;

import gov.nasa.jpf.constraints.api.Valuation;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.util.TypeUtil;

public class MaxSATSolver {

//	/**
//	 * \brief Create a full adder with inputs \c in_1, \c in_2 and \c cin. The
//	 * output of the full adder is stored in \c out, and the carry in \c c_out.
//	 */
//	void mk_full_adder(Context ctx, BoolExpr in_1, BoolExpr in_2, BoolExpr cin, BoolExpr[] out, BoolExpr[] cout) {
//		cout[0] = ctx.mkOr(ctx.mkOr(in_1, in_2), ctx.mkOr(in_1, cin), ctx.mkOr(in_2, cin));
//		out[0] = ctx.mkXor(ctx.mkXor(in_1, in_2), cin);
//	}

	private static final boolean DEBUG_MAXSAT = false;

	/**
	 * \brief Create an adder for inputs of size \c num_bits. The arguments \c in1
	 * and \c in2 are arrays of bits of size \c num_bits.
	 * 
	 * \remark \c result must be an array of size \c num_bits + 1.
	 */
	BoolExpr[] mk_adder(Context ctx, int num_bits, BoolExpr[] in_1, BoolExpr[] in_2) {
		BoolExpr[] result = new BoolExpr[num_bits+1];
		BoolExpr carry;
		int i;
		carry = ctx.mkFalse();
		for (i = 0; i < num_bits; i++) {
			//mk_full_adder
			result[i] = ctx.mkXor(ctx.mkXor(in_1[i], in_2[i]), carry);			
			carry = ctx.mkOr(ctx.mkAnd(in_1[i], in_2[i]), ctx.mkAnd(in_1[i], carry), ctx.mkAnd(in_2[i], carry));
						
		}
		result[num_bits] = carry;
		return result;
	}


	private void mk_adder(Context ctx, int num_bits, BoolExpr[] in, int _in1, int _in2, BoolExpr[] result, int _out) {
		BoolExpr cout;
		int i;
		cout = ctx.mkFalse();
		for (i = 0; i < num_bits; i++) {
			BoolExpr in_1 = in[i+_in1];
			BoolExpr in_2 = in[i+_in2];
			result[_out+i] = ctx.mkXor(ctx.mkXor(in_1, in_2), cout);			
			cout = ctx.mkOr(ctx.mkAnd(in_1, in_2), ctx.mkAnd(in_1, cout), ctx.mkAnd(in_2, cout));						
		}
		result[_out+num_bits] = cout;
	}

	
	void writeDebug(String msg){
		if (MAXSAT_DEBUG)
			System.out.println(msg);
	}
	
	String getExprString(Expr... a){
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		for(Expr expr: a){
			sb.append(expr+",");
		}
		sb.append("]");
		return sb.toString();
	}
	/**
	 * \brief Given \c num_ins "numbers" of size \c num_bits stored in \c in.
	 * Create floor(num_ins/2) adder circuits. Each circuit is adding two consecutive "numbers". 
	 * The numbers are stored one after the next in the array \c in. That is, the array \c in has size num_bits * num_ins. 
	 * Return an array of bits containing \c ceil(num_ins/2) numbers of size \c (num_bits + 1). 
	 * If num_ins/2 is not an integer, then the last "number" in the output, is the last "number" in \c in with an appended "zero".
	 */
 
	int mk_adder_pairs(Context ctx, int num_bits, int num_ins , BoolExpr[] in, BoolExpr[] out ) {		
		int out_num_bits = num_bits + 1;
		int i = 0;		
		
		
		int out_num_ins = (num_ins % 2 == 0) ? (num_ins / 2) : (num_ins / 2) + 1;
	
		int _in1 = 0,_in2;
		int _out=0;
		
		for (i = 0; i < num_ins / 2; i++) {
			_in2 = _in1+num_bits;		
			writeDebug("_in1: "+_in1+", _in2: "+_in2+", _out: "+_out);			
			writeDebug("in: "+getExprString(in));
			writeDebug("out: "+getExprString(out));
			
			mk_adder(ctx,num_bits,in,_in1,_in2,out,_out);			
			writeDebug("new out: "+getExprString(out));
			
			_out +=out_num_bits;
			
			_in1 += num_bits;
			_in1 += num_bits;			
		}
		
		if (num_ins % 2 != 0) {
			for (i = 0; i < num_bits; i++) {
				out[_out+i] = in[_in1+i];
			}
			out[_out+num_bits] = ctx.mkFalse();
		}
		writeDebug("out_num_ins: "+out_num_ins+"\nnew out: "+getExprString(out));
		return out_num_ins;
	}



	boolean MAXSAT_DEBUG = false;

/**
   \brief Create a counter circuit to count the number of "ones" in lits.
   The function returns an array of bits (i.e. boolean expressions) containing the output of the circuit.
   The size of the array is stored in out_sz.
*/
	BoolExpr[] mk_counter_circuit(Context ctx, BoolExpr[] lits) {
	 	int out_sz;
	 	int n = lits.length;
    int num_ins  = n;
    int num_bits = 1;
    BoolExpr[] aux_1;
    BoolExpr[] aux_2;
    
    if (n == 0)
        return null;
    
//    aux_1    = new BoolExpr[n + 1];      
    
    aux_1 = Arrays.copyOf(lits, n+1);
    aux_2    = new BoolExpr[n + 1];
    
    while (num_ins > 1) {
        int new_num_ins;
        new_num_ins = mk_adder_pairs(ctx, num_bits,num_ins, aux_1,aux_2);
        //new_num_ins = aux_2.length;
        num_ins = new_num_ins;
        num_bits++;
        if( MAXSAT_DEBUG)
        {
            int i;
            System.out.printf("num_bits: %d, num_ins: %d \n", num_bits, num_ins);
            for (i = 0; i < num_ins * num_bits; i++) {
                System.out.printf("bit %d:\n%s\n", i, aux_2[i]);
            }
            System.out.printf("-----------\n");
        }  		
        BoolExpr[] tmp = aux_1;
        aux_1 = aux_2;
        aux_2 = tmp;
    }
    out_sz = num_bits;    
    aux_1 = Arrays.copyOf(aux_1, out_sz);
    return aux_1;
}


	/**
	 * \brief Return the \c idx bit of \c val.
	 */
	boolean get_bit(int val, int idx) {
		int mask = 1 << (idx & 31);
		return (val & mask) != 0;
	}

	/**
	 * \brief Given an integer val encoded in n bits (boolean variables), assert
	 * the constraint that val <= k.
	 */
	void assert_le_k(Context ctx, Solver s, BoolExpr[] val, int k) {		
		BoolExpr i1, i2, not_val, out;
		int idx;
		not_val = ctx.mkNot(val[0]);
		if (get_bit(k, 0))
			out = ctx.mkTrue();
		else
			out = not_val;

		int n = val.length;
		
		for (idx = 1; idx < n; idx++) {
			not_val = ctx.mkNot(val[idx]);
			if (get_bit(k, idx)) {
				i1 = not_val;
				i2 = out;
			} else {
				i1 = ctx.mkFalse();
				i2 = ctx.mkFalse();
			}
			out = ctx.mkOr(i1, i2, ctx.mkAnd(not_val, out));
		}
		writeDebug("at-most-k:\n"+out+"\n");
		s.add(out);
	}

	/**
  \brief Assert that at most \c k literals in \c lits can be true,
  where \c n is the number of literals in lits.
  
  We use a simple encoding using an adder (counter). 
  An interesting exercise consists in implementing more sophisticated encodings.
*/
void assert_at_most_k(Context ctx, Solver s, BoolExpr[] lits, int k)
{	
	 int n = lits.length;
	 BoolExpr[] counter_bits;
   int counter_bits_sz;
   if (k >= n || n <= 1)
       return; /* nothing to be done */
   counter_bits = mk_counter_circuit(ctx, lits);
   counter_bits_sz = counter_bits.length;
   assert_le_k(ctx, s, counter_bits, k);
   //del_bool_var_array(counter_bits);
}

	/**
	 * \brief Assert that at most one literal in \c lits can be true, where \c n
	 * is the number of literals in lits.
	 */
	void assert_at_most_one(Context ctx, Solver s, BoolExpr[] lits) {
		assert_at_most_k(ctx, s, lits, 1);
	}

	/**
	 * \brief Create a fresh boolean variable.
	 */
	BoolExpr mk_fresh_bool_var(Context ctx) {
		return (BoolExpr) ctx.mkFreshConst("k", ctx.getBoolSort());
	}

	/**
	 * \brief Create an array with \c num_vars fresh boolean variables.
	 */
	BoolExpr[] mk_fresh_bool_var_array(Context ctx, int num_vars) {
		BoolExpr[] result = new BoolExpr[num_vars];
		int i;
		for (i = 0; i < num_vars; i++) {
			result[i] = mk_fresh_bool_var(ctx);
		}
		return result;
	}

	/**
	 * \brief Assert hard constraints stored in the given array.
	 */
	void assert_hard_constraints(Context ctx, Solver s, BoolExpr[] cnstrs) {
		int num_cnstrs = cnstrs.length;
		int i;
		for (i = 0; i < num_cnstrs; i++) {
			s.add(cnstrs[i]);
		}
	}

	/**
	 * \brief Assert soft constraints stored in the given array. This funtion will
	 * assert each soft-constraint C_i as (C_i or k_i) where k_i is a fresh
	 * boolean variable. It will also return an array containing these fresh
	 * variables.
	 */
	BoolExpr[] assert_soft_constraints(Context ctx, Solver s, BoolExpr[] cnstrs) {
		int num_cnstrs = cnstrs.length;
		int i;
		BoolExpr[] aux_vars;
		aux_vars = mk_fresh_bool_var_array(ctx, num_cnstrs);
		for (i = 0; i < num_cnstrs; i++) {
			BoolExpr assumption = cnstrs[i];
			s.add(ctx.mkOr(assumption, aux_vars[i]));
		}
		return aux_vars;
	}
	
	/**
	 * \brief Fu & Malik procedure for MaxSAT. This procedure is based on unsat
	 * core extraction and the at-most-one constraint.
	 * 
	 * Return the number of soft-constraints that can be satisfied. Return -1 if
	 * the hard-constraints cannot be satisfied. That is, the formula cannot be
	 * satisfied even if all soft-constraints are ignored.
	 * 
	 * For more information on the Fu & Malik procedure:
	 * 
	 * Z. Fu and S. Malik, On solving the partial MAX-SAT problem, in
	 * International Conference on Theory and Applications of Satisfiability
	 * Testing, 2006.
	 * @param freeVarMap 
	 */
	public List<Model> fu_malik_maxsat(int maxBound, Context ctx, Solver s, BoolExpr[] hard_cnstrs, BoolExpr[] soft_cnstrs) {
		long lastTime = System.currentTimeMillis();
		System.out.println("maxsat begin at: "+lastTime);
		
		writeDebug("fu_malik_maxsat: BEGIN (max "+maxBound+", #hards "+hard_cnstrs.length+", #softs "+soft_cnstrs.length+")");
		int num_hard_cnstrs = hard_cnstrs.length;
		int num_soft_cnstrs = soft_cnstrs.length; 
		BoolExpr[] aux_vars;
		Status is_sat; 
		int k;
		List<Model> modelSet = new ArrayList<>();
						
		assert_hard_constraints(ctx, s, hard_cnstrs);
		
		long temp = System.currentTimeMillis();
		writeDebug("checking whether hard constraints are satisfiable...");
		is_sat = performCheck(s);
		System.out.println("Debug: time for hard_constraint: "+(System.currentTimeMillis()-temp));
		if (is_sat == Status.UNSATISFIABLE) {
			writeDebug("hard constraints UNSAT");
			// It is not possible to make the formula satisfiable even when ignoring
			// all soft constraints.
			writeDebug("fu_malik_maxsat: RETURN UNSAT");
			return modelSet; //return emptySet
		}		
		
		writeDebug("hard constraints SAT, Number of soft constraints: "+num_soft_cnstrs);
		if (num_soft_cnstrs == 0){			
			modelSet.add(s.getModel());
			writeDebug("fu_malik_maxsat: RETURN SAT");
			return modelSet; // nothing to be done...
		}
		/*
		 * Fu&Malik algorithm is based on UNSAT-core extraction. We accomplish that
		 * using auxiliary variables (aka answer literals).
		 */
		aux_vars = assert_soft_constraints(ctx, s, soft_cnstrs);
		
		BoolExpr[] soft_cnstrs_origin = Arrays.copyOf(soft_cnstrs, soft_cnstrs.length);		
		k = 0;		
		while (k<=maxBound) {
			long lastIterTime = System.currentTimeMillis();
			System.out.println("iteration "+ k);
			writeDebug("iteration "+ k);
			if (fu_malik_maxsat_step(ctx, s, soft_cnstrs, aux_vars)) {
				//found a MCS
				Model model = s.getModel();				
				modelSet.add(model);
				writeDebug("Number of SAT Clauses: " +(num_soft_cnstrs - k));
				long time = System.currentTimeMillis()-lastTime;
				lastTime = System.currentTimeMillis();
				System.out.println("MCS computation time: "+time);
				/*if (MAXSAT_DEBUG){
					System.out.println("Number of SAT Clauses: " +(num_soft_cnstrs - k));
					//System.out.println("Soft Constraints: ");
					//for(int i=0;i<soft_cnstrs.length;i++)
					//	System.out.println(i+") "+ model.evaluate(soft_cnstrs[i],false)+" :=> "+soft_cnstrs[i]);
					//System.out.println("aux vars: ");
					//for(int i=0;i<aux_vars.length;i++)
					//	System.out.println(i+") "+ model.evaluate(aux_vars[i],false)+" :=> "+aux_vars[i]);
					
					System.out.println("aux_vars saved: ");
					for(int i=0;i<aux_saved.length;i++)
						System.out.println(i+") "+ model.evaluate(aux_saved[i],false)+" :=> "+aux_saved[i]);
					
						//System.out.println("Model: "+model);
						//System.out.println("Model: "+model);
				}*/
				//create block_var
				BoolExpr[] block_expression = new BoolExpr[k];
				int j=0;
				for(int i=0;i<soft_cnstrs_origin.length;i++){
					if (model.evaluate(soft_cnstrs_origin[i], false).isFalse()){
						block_expression[j++]=ctx.mkNot(soft_cnstrs_origin[i]);
					}
				}
				
				/*List<BoolExpr> unsatClauses = new ArrayList<>(k);
				int j=0;
				for(int i=0;i<soft_cnstrs_origin.length;i++){
					if (model.evaluate(soft_cnstrs_origin[i], false).isFalse()){
						unsatClauses.add(soft_cnstrs_origin[i]);
						j++;
					}
				}
				if (unsatClauses.size()>k){
					writeDebug(unsatClauses.toString());
				}
				
				BoolExpr[] block_expression = new BoolExpr[k];
				for(int i=0;i<unsatClauses.size();i++){
					block_expression[i]=ctx.mkNot(unsatClauses.get(i));
				}*/
				
				BoolExpr block = ctx.mkNot(ctx.mkAnd(block_expression));
				s.add(block);				
			}else
				k++;
			System.out.println("iteration time: "+(System.currentTimeMillis()- lastIterTime));
		}
		writeDebug("fu_malik_maxsat: RETURN SAT, #models "+modelSet.size());
		return modelSet;
	}
	

	/**
	 * \brief Fu & Malik procedure for MaxSAT. This procedure is based on unsat
	 * core extraction and the at-most-one constraint.
	 * 
	 * Return the number of soft-constraints that can be satisfied. Return -1 if
	 * the hard-constraints cannot be satisfied. That is, the formula cannot be
	 * satisfied even if all soft-constraints are ignored.
	 * 
	 * For more information on the Fu & Malik procedure:
	 * 
	 * Z. Fu and S. Malik, On solving the partial MAX-SAT problem, in
	 * International Conference on Theory and Applications of Satisfiability
	 * Testing, 2006.
	 */
	public int fu_malik_maxsat(Context ctx, Solver s, BoolExpr[] hard_cnstrs, BoolExpr[] soft_cnstrs) {
		int num_hard_cnstrs = hard_cnstrs.length;
		int num_soft_cnstrs = soft_cnstrs.length;
		BoolExpr[] aux_vars;
		Status is_sat;
		int k;
		assert_hard_constraints(ctx, s, hard_cnstrs);

		writeDebug("checking whether hard constraints are satisfiable...");
		is_sat = performCheck(s);
		if (is_sat == Status.UNSATISFIABLE) {
			// It is not possible to make the formula satisfiable even when ignoring
			// all soft constraints.
			return -1;
		}
		if (num_soft_cnstrs == 0)
			return 0; // nothing to be done...
		/*
		 * Fu&Malik algorithm is based on UNSAT-core extraction. We accomplish that
		 * using auxiliary variables (aka answer literals).
		 */
		aux_vars = assert_soft_constraints(ctx, s, soft_cnstrs);
		k = 0;
		for (;;) {
			writeDebug("iteration "+ k);
			if (fu_malik_maxsat_step(ctx, s, soft_cnstrs, aux_vars)) {
				return num_soft_cnstrs - k;
			}
			k++;
		}
	}

	boolean fu_malik_maxsat_step(Context ctx, Solver s, BoolExpr[] soft_cnstrs, BoolExpr[] aux_vars) {		
		int num_soft_cnstrs = soft_cnstrs.length;
		writeDebug("fu_malik_maxsat_step: soft "+num_soft_cnstrs+", aux "+aux_vars.length);
		
		BoolExpr[] assumptions = new BoolExpr[num_soft_cnstrs];
		Status is_sat;
		BoolExpr[] core;
		int core_size;
		int i = 0;
		int k = 0;
		BoolExpr[] block_vars;
		for (i = 0; i < num_soft_cnstrs; i++) {
			// Recall that we asserted (soft_cnstrs[i] \/ aux_vars[i])
			// So using (NOT aux_vars[i]) as an assumption we are actually forcing the
			// soft_cnstrs[i] to be considered.
			assumptions[i] = ctx.mkNot(aux_vars[i]);
		}
		is_sat = performCheck(s, assumptions);
		writeDebug("is_sat: "+is_sat);
		if (is_sat == Status.SATISFIABLE) {
			writeDebug("SAT");
			writeDebug("fu_malik_maxsat_step: RETURN SUCCESS");
			return true; // done
		} else {
			core = s.getUnsatCore();
			core_size = core.length;
			block_vars = new BoolExpr[core_size];
			k = 0;
			writeDebug("unsat core size: "+core_size);
			// update soft-constraints and aux_vars			
			for (i = 0; i < num_soft_cnstrs; i++) {
				int j;
				// check whether assumption[i] is in the core or not				
				for (j = 0; j < core_size; j++) {
					if (assumptions[i].equals(core[j]))
						break;
				}
				if (j < core_size) {
					// assumption[i] is in the unsat core... so soft_cnstrs[i] is in the
					// unsat core
					BoolExpr block_var = mk_fresh_bool_var(ctx);
					BoolExpr new_aux_var = mk_fresh_bool_var(ctx);
					soft_cnstrs[i] = ctx.mkOr(soft_cnstrs[i], block_var);
					aux_vars[i] = new_aux_var;
					block_vars[k] = block_var;
					k++;
					// Add new constraint containing the block variable.
					// Note that we are using the new auxiliary variable to be able to use
					// it as an assumption.
					s.add(ctx.mkOr(soft_cnstrs[i], new_aux_var));
				}
			}
			assert_at_most_one(ctx, s, block_vars);
			writeDebug("fu_malik_maxsat_step: RETURN FALSE");
			return false; // not done.
		}
	}


	/**
	 * @param s
	 * @param assumptions
	 * @return
	 */
	private Status performCheck(Solver s, BoolExpr[] assumptions) {
		Status is_sat;
		String solverContextInfo = getSolverSummary(s);
		writeDebug(solverContextInfo);
		writeDebug("checking SAT assumptions size "+assumptions.length+" ...");
		
		is_sat = s.check(assumptions);
		writeDebug("solver statistics: \n"+getStatisticString(s));
		return is_sat;
	}

	private Status performCheck(Solver s) {
		Status is_sat;
		String solverContextInfo = getSolverSummary(s);
		writeDebug(solverContextInfo);
		writeDebug("checking SAT ...");
		is_sat = s.check();
		writeDebug("solver statistics: \n"+getStatisticString(s));
		return is_sat;
	}
	private String getStatisticString(Solver s){
		StringBuffer sb = new StringBuffer();
		for(Entry en:s.getStatistics().getEntries()){
			sb.append(en.Key+": "+en.getValueString()+"\n");			
		}
		return sb.toString();
	}
	
	private String getSolverSummary(Solver s) {		
		StringBuffer sb = new StringBuffer();
		sb.append("--solver info--\n");
		sb.append("#assertion: "+s.getNumAssertions()+"\n");		
		sb.append("---------------");
		return sb.toString();
	}


	/**
  \brief Create a logical context.
  Enable model construction only.
*/
Context mk_context() 
{
	HashMap<String, String> cfg = new HashMap<String, String>();
	cfg.put("model", "true");
	Context ctx = new Context(cfg);
  return ctx;
}

	void tst_at_most_one() 
	{
	    Context ctx = mk_context();
	    Solver s = ctx.mkSolver();
	    BoolExpr k1      = ctx.mkBoolConst("k1");
	    BoolExpr k2      =  ctx.mkBoolConst( "k2");
	    BoolExpr k3      =  ctx.mkBoolConst("k3");
	    BoolExpr k4      =  ctx.mkBoolConst( "k4");
	    BoolExpr k5      =  ctx.mkBoolConst("k5");
	    BoolExpr k6      = ctx.mkBoolConst( "k6");
	    BoolExpr[] args1 = new BoolExpr[]{ k1, k2, k3, k4, k5 };
	    BoolExpr[] args2 = new BoolExpr[]{ k4, k5, k6 };
	    Model m      = null;
	    Status result;
	    System.out.printf("testing at-most-one constraint\n");
	    assert_at_most_one(ctx, s,args1);
	    assert_at_most_one(ctx, s, args2);
	    System.out.printf("it must be sat...\n");
	    result = s.check();
	    if (result != Status.SATISFIABLE)
	    	System.out.printf("BUG");
	    m = s.getModel();
	    System.out.printf("model:\n%s\n",  m);
	    s.add(ctx.mkOr(k2, k3));
	    s.add(ctx.mkOr(k1, k6));
	    System.out.printf("it must be sat...\n");
	    result = s.check();
	    if (result != Status.SATISFIABLE)
	    	System.out.printf("BUG");
	    m = s.getModel();
	    System.out.printf("model:\n%s\n", m);
	    s.add(ctx.mkOr(k4, k5));
	    System.out.printf("it must be unsat...\n");
	    result = s.check();
	    if (result == Status.SATISFIABLE)
	    	System.out.printf("BUG");	    
	}
	
	void tst_maxsat() 
	{
		Context ctx = mk_context();
    Solver s = ctx.mkSolver();
    IntExpr x = ctx.mkIntConst("x");
    IntExpr y = ctx.mkIntConst("y");
    IntExpr z = ctx.mkIntConst("z");
    
    List<BoolExpr> softs = new ArrayList<BoolExpr>();
    softs.add(ctx.mkGt(x, ctx.mkInt(0))); 	// x > 0 
    softs.add(ctx.mkLe(x, ctx.mkInt(-1)));	// x <= -1
    softs.add(ctx.mkOr(ctx.mkGt(x, ctx.mkInt(0)),ctx.mkLt(y, ctx.mkInt(1))));	// x > 0 || y < 1
    softs.add(ctx.mkGt(y, ctx.mkInt(2)));
    softs.add(ctx.mkGt(y, ctx.mkInt(3)));
    softs.add(ctx.mkLe(y, ctx.mkInt(-1)));
    
    List<BoolExpr> hard = new ArrayList<BoolExpr>();
    hard.add(ctx.mkEq(z, ctx.mkAdd(x,y)));    
    
    BoolExpr[] hard_cnstrs= hard.toArray(new BoolExpr[hard.size()]);
		BoolExpr[] soft_cnstrs = softs.toArray(new BoolExpr[softs.size()]);
		
		int k = this.fu_malik_maxsat(ctx, s, hard_cnstrs, soft_cnstrs);
		System.out.println("Number of sat clauses = "+k);
		Model m = s.getModel();
		System.out.println("Model: ");
		System.out.println("x = "+m.evaluate(x, false));
		System.out.println("y = "+m.evaluate(y, false));
		System.out.println("z = "+m.evaluate(z, false));
		
		for(int i=0;i<softs.size();i++){
			System.out.println("clause "+i+") "+softs.get(i)+" :=> "+m.evaluate(softs.get(i),false));					
		}
		for(int i=0;i<hard.size();i++){
			System.out.println("clause "+i+") "+hard.get(i)+" :=> "+m.evaluate(hard.get(i),false));					
		}
		System.out.println("x = "+m.evaluate(x, false));
		
	}
	
	void tst_maxsat(int bound) 
	{
		Context ctx = mk_context();
    Solver s = ctx.mkSolver();
    IntExpr x = ctx.mkIntConst("x");
    IntExpr y = ctx.mkIntConst("y");
    IntExpr z = ctx.mkIntConst("z");
    
    List<BoolExpr> softs = new ArrayList<BoolExpr>();
    softs.add(ctx.mkGt(x, ctx.mkInt(0))); 	// x > 0 
    softs.add(ctx.mkLe(x, ctx.mkInt(-1)));	// x <= -1
    softs.add(ctx.mkOr(ctx.mkGt(x, ctx.mkInt(0)),ctx.mkLt(y, ctx.mkInt(1))));	// x > 0 || y < 1
    softs.add(ctx.mkGt(y, ctx.mkInt(2))); // y>2
    softs.add(ctx.mkGt(y, ctx.mkInt(3))); // y>3
    softs.add(ctx.mkLe(y, ctx.mkInt(-1))); // y<=-1
    
    List<BoolExpr> hard = new ArrayList<BoolExpr>();
    hard.add(ctx.mkEq(z, ctx.mkAdd(x,y)));    //z = x+y
    
    BoolExpr[] hard_cnstrs= hard.toArray(new BoolExpr[hard.size()]);
		BoolExpr[] soft_cnstrs = softs.toArray(new BoolExpr[softs.size()]);
		
		List<Model> result = this.fu_malik_maxsat(bound, ctx, s, hard_cnstrs, soft_cnstrs);		
		System.out.println("Number of Result = "+result.size());
		for(int k=0;k<result.size();k++){
			Model m = result.get(k);
			int mcsSize = 0;
			for(int i=0;i<softs.size();i++){
				if (m.evaluate(softs.get(i),false).isFalse())
					mcsSize++;
			}
			System.out.println("----- MCS "+k+", size = "+mcsSize+" ---------");
			System.out.println("Model: x = "+m.evaluate(x, false)+", y = "+m.evaluate(y, false)+",z = "+m.evaluate(z, false));
			
			for(int i=0;i<softs.size();i++){
				System.out.println("clause "+i+") "+ m.evaluate(softs.get(i),false)+ "\t <=: "+softs.get(i));					
			}
			for(int i=0;i<hard.size();i++){
				System.out.println("clause "+i+") "+ m.evaluate(hard.get(i),false)+ "\t <=: "+hard.get(i));					
			}
		}
	}
	public static void main(String[] args) {
		MaxSATSolver p = new MaxSATSolver();
		p.tst_at_most_one();
		p.tst_maxsat(3);
	}
}
