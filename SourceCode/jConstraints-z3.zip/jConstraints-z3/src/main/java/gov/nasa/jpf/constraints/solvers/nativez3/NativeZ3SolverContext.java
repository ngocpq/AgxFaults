/*
 * Copyright (C) 2015, United States Government, as represented by the 
 * Administrator of the National Aeronautics and Space Administration.
 * All rights reserved.
 *
 * The PSYCO: A Predicate-based Symbolic Compositional Reasoning environment 
 * platform is licensed under the Apache License, Version 2.0 (the "License"); you 
 * may not use this file except in compliance with the License. You may obtain a 
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0. 
 *
 * Unless required by applicable law or agreed to in writing, software distributed 
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 * specific language governing permissions and limitations under the License.
 */
package gov.nasa.jpf.constraints.solvers.nativez3;

import gov.nasa.jpf.constraints.api.ConstraintSolver.Result;
import gov.nasa.jpf.constraints.api.Expression;
import gov.nasa.jpf.constraints.api.SolverContext;
import gov.nasa.jpf.constraints.api.Valuation;
import gov.nasa.jpf.constraints.api.Variable;
import gov.nasa.jpf.constraints.array.ArrayVariable;
import gov.nasa.jpf.constraints.expressions.functions.FunctionExpression;
import gov.nasa.jpf.constraints.types.BuiltinTypes;
import gov.nasa.jpf.constraints.types.Type;
import gov.nasa.jpf.constraints.util.ExpressionUtil;
import gov.nasa.jpf.constraints.util.TypeUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.microsoft.z3.AST;
import com.microsoft.z3.BoolExpr;
import com.microsoft.z3.Expr;
import com.microsoft.z3.FuncDecl;
import com.microsoft.z3.FuncDecl.Parameter;
import com.microsoft.z3.FuncInterp;
import com.microsoft.z3.FuncInterp.Entry;
import com.microsoft.z3.Global;
import com.microsoft.z3.Model;
import com.microsoft.z3.Native;
import com.microsoft.z3.Solver;
import com.microsoft.z3.Sort;
import com.microsoft.z3.Status;
import com.microsoft.z3.Symbol;
import com.microsoft.z3.Z3Exception;
import com.microsoft.z3.enumerations.Z3_ast_kind;
import com.microsoft.z3.enumerations.Z3_decl_kind;
import com.microsoft.z3.enumerations.Z3_parameter_kind;
import com.microsoft.z3.enumerations.Z3_sort_kind;

public class NativeZ3SolverContext extends SolverContext {

	private static final Logger logger = Logger.getLogger("constraints");

	private final Deque<NativeZ3ExpressionGenerator> generatorStack = new ArrayDeque<NativeZ3ExpressionGenerator>();
	private final Deque<Map<String, Variable<?>>> freeVarsStack = new ArrayDeque<Map<String, Variable<?>>>();

	// private final Deque<Map<String,Variable<?>>> auxiliaryVarsStack
	// = new ArrayDeque<Map<String,Variable<?>>>();

	private Solver solver;
	// private boolean unsat_core_enabled=false;

	public NativeZ3SolverContext(Solver solver, NativeZ3ExpressionGenerator rootGenerator) {
		this.solver = solver;
		this.generatorStack.push(rootGenerator);
		this.freeVarsStack.push(new HashMap<String, Variable<?>>());
		// String unsat_core =Global.getParameter("unsat_core");
		// if (unsat_core!=null)
		// this.unsat_core_enabled = Boolean.parseBoolean(unsat_core);
	}

	// private boolean isUnsatCoreEnabled(){
	// return unsat_core_enabled;
	// }

	@Override
	public void push() {
		try {
			solver.push();
			Map<String, Variable<?>> fvMap = freeVarsStack.peek();
			generatorStack.push(generatorStack.peek().createChild());
			freeVarsStack.push(new HashMap<String, Variable<?>>(fvMap));
		} catch (Z3Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	@Override
	public void pop(int n) {
		for (int i = 0; i < n; i++) {
			NativeZ3ExpressionGenerator gen = generatorStack.pop();
			gen.dispose();
			freeVarsStack.pop();
		}
		try {
			solver.pop(n);
		} catch (Z3Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	@Override
	public List<Valuation> solveMaxSAT(int maxMCSBound, List<Expression<Boolean>> hards,
			List<Expression<Boolean>> softs) {
		MaxSATSolver maxSatSolver = new MaxSATSolver();
		NativeZ3ExpressionGenerator gen = generatorStack.peek();
		Map<String, Variable<?>> fvMap = freeVarsStack.peek();

		BoolExpr[] hard_cnstrs = new BoolExpr[hards.size()];
		BoolExpr[] soft_cnstrs = new BoolExpr[softs.size()];

		for (int i = 0; i < hards.size(); i++) {
			Expression<Boolean> ex = hards.get(i);
			hard_cnstrs[i] = gen.generateAssertion(ex);
			Set<Variable<?>> fvs = ExpressionUtil.freeVariables(ex);
			for (Variable<?> v : fvs)
				fvMap.put(v.getName(), v);
		}
		for (int i = 0; i < softs.size(); i++) {
			Expression<Boolean> ex = softs.get(i);
			soft_cnstrs[i] = gen.generateAssertion(ex);
			Set<Variable<?>> fvs = ExpressionUtil.freeVariables(ex);
			for (Variable<?> v : fvs)
				fvMap.put(v.getName(), v);
		}
		List<Model> modelSet = maxSatSolver.fu_malik_maxsat(maxMCSBound, gen.ctx, this.solver, hard_cnstrs,
				soft_cnstrs);
		List<Valuation> valResults = new ArrayList<>();

		if (modelSet == null)
			return valResults; // UNSAT

		for (Model m : modelSet) {
			Valuation val = new Valuation();
			getValuationFromModel(val, m, fvMap,gen);
			valResults.add(val);
		}
		return valResults;
	}

	@Override
	public int solveMaxSAT(Valuation val, List<Expression<Boolean>> hards, List<Expression<Boolean>> softs) {
		MaxSATSolver maxSatSolver = new MaxSATSolver();
		NativeZ3ExpressionGenerator gen = generatorStack.peek();
		Map<String, Variable<?>> fvMap = freeVarsStack.peek();

		BoolExpr[] hard_cnstrs = new BoolExpr[hards.size()];
		BoolExpr[] soft_cnstrs = new BoolExpr[softs.size()];

		for (int i = 0; i < hards.size(); i++) {
			Expression<Boolean> ex = hards.get(i);
			hard_cnstrs[i] = gen.generateAssertion(ex);
			Set<Variable<?>> fvs = ExpressionUtil.freeVariables(ex);
			for (Variable<?> v : fvs)
				fvMap.put(v.getName(), v);
		}
		for (int i = 0; i < softs.size(); i++) {
			Expression<Boolean> ex = softs.get(i);
			soft_cnstrs[i] = gen.generateAssertion(ex);
			Set<Variable<?>> fvs = ExpressionUtil.freeVariables(ex);
			for (Variable<?> v : fvs)
				fvMap.put(v.getName(), v);
		}

		BoolExpr[] soft_origin = Arrays.copyOf(hard_cnstrs, soft_cnstrs.length);

		int satCount = maxSatSolver.fu_malik_maxsat(gen.ctx, this.solver, hard_cnstrs, soft_cnstrs);
		if (satCount == -1)
			return -1;

		Model model = this.solver.getModel();

		try {
			if (logger.isLoggable(Level.FINE)) {
				String modelText = model.toString().replace("\n", ", ").trim();
				logger.fine(modelText);
			}

			if (gen.isTainted(model)) {
				model.dispose();
				logger.info("Model is tainted, rechecking ...");
				model = gen.recheckUntainted();
				if (model == null)
					return -2;
			}

			Map<String, Variable<?>> freeVars = new HashMap<String, Variable<?>>(freeVarsStack.peek());

			getValuationFromModel(val, model, freeVars,gen);
		} finally {
			model.dispose();
		}

		logger.finer("Satisfiable, valuation " + val);
		return satCount;
	}

	public static String getArrayValuationFromModel(Model m,Expr some_array_1, ArrayVariable<?> var){
		//System.out.println("------- getArrayValuationFromModel for: "+some_array_1);
		Expr mval = m.eval(some_array_1, false);
		//System.out.println("mval = " + mval);
		FuncDecl mfd = mval.getFuncDecl();
		Stack<Expr> storeStackIndex= new Stack<>();
		Stack<Expr> storeStackValue= new Stack<>();
		
		while(mfd.getDeclKind() == Z3_decl_kind.Z3_OP_STORE) {
			Expr addr = mval.getArgs()[1];
		    Expr data = mval.getArgs()[2];		    
		    // put them into the stack, say __stack__ for later use
		    storeStackIndex.push(addr);
		    storeStackValue.push(data);
		    // recursively handle the OP_STORE case, because the first
		    // argument can still be an Z3_OP_STORE
		    mval = mval.getArgs()[0];
		    mfd = mval.getFuncDecl();
		}
		Map<String, String> mapData = new HashMap<>();
		// now that we peel the Z3_OP_STORE
		if(mfd.getDeclKind() == Z3_decl_kind.Z3_OP_CONST_ARRAY) {
			Expr arg0 = mval.getArgs()[0];
			String index = "0"; //TODO: fix me: get index value?!
			String value = parValueString(arg0, var.getElementType());
			mapData.put(index, value);			
		}else if( mfd.getDeclKind() == Z3_decl_kind.Z3_OP_AS_ARRAY ) {
			//System.out.println("Z3_OP_AS_ARRAY");
			FuncInterp fun_interp =getArrayFuncInterp(mfd, m);
			//System.out.println("The Z3 expr(fun_interp) for the array is : " + fun_interp);
			if (fun_interp==null)
				return null;
			int num_entries = fun_interp.getNumEntries();
			for (int i = 0; i < num_entries; i++) {
				Entry entry = fun_interp.getEntries()[i];
				Expr k = entry.getArgs()[0];
				Expr v = entry.getValue();
				
				String index = parValueString(k, BuiltinTypes.SINT32);
				String value = parValueString(v, var.getElementType());
				mapData.put(index, value);				
			}	
			//Expr default_value = fun_interp.getElse();
			//System.out.println("Default value:" + default_value);			
		}
		while (!storeStackIndex.isEmpty()){
			Expr k = storeStackIndex.pop();
			Expr v = storeStackValue.pop();
			
			String index = parValueString(k, BuiltinTypes.SINT32);
			String value = parValueString(v, var.getElementType());
			mapData.put(index, value);		
		}
		StringBuffer strBuff =new StringBuffer();
		int i = 0;
		for(java.util.Map.Entry<String, String> en:mapData.entrySet()){
			if (i>0)
				strBuff.append(",");
			strBuff.append(en.getKey()+"->"+en.getValue());
			i++;
		}
		return strBuff.toString();
	}
	
	public static void getValuationFromModel(Valuation val, Model model, Map<String, Variable<?>> freeVarsMap, NativeZ3ExpressionGenerator gen) {
		Map<String, Variable<?>> freeVars = new HashMap(freeVarsMap);
		long max = model.getNumConsts();
		//FuncDecl[] decls = model.getDecls();
		FuncDecl[] decls = model.getConstDecls();
		try {
			for (int i = 0; i < max; i++) {
				try{
					FuncDecl decl = decls[i];
	
					Symbol sym = null;
					String text = null;
					try {
						sym = decl.getName();
						text = sym.toString().trim();
					} finally {
						sym.dispose();
					}				
					
					if (text.equals("NaN")){
						System.out.println("Debug");
					}
					
					//System.out.println("symbol: "+text);
					//printDecInfo(decl);
					
					Variable<?> v = freeVars.get(text);					
					if (v == null) {
						continue;
					}
					freeVars.remove(text);										
					
					if (v instanceof ArrayVariable){ //array								
						Expr varExpr = gen.getOriginVariable(v);						
						String value = getArrayValuationFromModel(model,varExpr,(ArrayVariable<?>) v);
						val.setParsedValue(v, value);
					}else{
						AST res = model.getConstInterp(decl);
						try {
							String value = res.toString().trim();
							if (TypeUtil.isRealSort(v) && value.contains("/")) {
								String[] split = value.split("/");
								BigDecimal nom = new BigDecimal(split[0].trim());
								BigDecimal den = new BigDecimal(split[1].trim());
								BigDecimal quot = nom.divide(den, 10, RoundingMode.FLOOR);								
								value = quot.toPlainString();
							}
							val.setParsedValue(v, value);
						} finally {
							res.dispose();
						}
					}
				}catch(Z3Exception ex){
					ex.printStackTrace();
				}
			}
		}finally {
			for (int i = 0; i < decls.length; i++)
				decls[i].dispose();
		}
		for (Variable<?> r : freeVars.values())
			val.setDefaultValue(r);
	}

	private static void printDecInfo(FuncDecl decl) {
		System.out.println(decl);
		System.out.println("getDeclKind: "+decl.getDeclKind()+", getASTKind: "+decl.getASTKind());
		System.out.println("getArity: "+decl.getArity()+", isApp: "+decl.isApp()+", isVar: "+decl.isVar()+", isExpr: "+decl.isExpr()+", isFuncDecl: "+decl.isFuncDecl());
	}

	private static FuncInterp getArrayFuncInterp(FuncDecl arrayEvalFuncDecl, Model model) {
		int a=1,b=0;
		//System.out.println(arrayEvalFuncDecl.getDeclKind());
		if( arrayEvalFuncDecl.getDeclKind() == Z3_decl_kind.Z3_OP_AS_ARRAY)
			a=b;
		//System.out.println(arrayEvalFuncDecl.getNumParameters());
		if (arrayEvalFuncDecl.getNumParameters() == 1)
			b=a;
		if (arrayEvalFuncDecl.getParameters()[0].getParameterKind() == Z3_parameter_kind.Z3_PARAMETER_FUNC_DECL)
			a++;
		Parameter para0 = arrayEvalFuncDecl.getParameters()[0];
		final FuncDecl arrayInterpretationFuncDecl = arrayEvalFuncDecl.getParameters()[0].getFuncDecl(); 
		final FuncInterp interpretation = model.getFuncInterp(arrayInterpretationFuncDecl);
		return interpretation;
	}

	@Override
	public Result solveUnsatCore(Valuation val, List<Expression<Boolean>> assumptions, List<Expression<Boolean>> unsatCore) {
		return solve(val,assumptions, unsatCore);
	}

	@Override
	public Result solve(Valuation val) {
		return solve(val, null,null);
	}

	//List<Expression<?>> _unsatCore;
	public Result solve(Valuation val, List<Expression<Boolean>> assumption,List<Expression<Boolean>> unsatCore) {
		logger.finer("Solving ...");
		try {
			NativeZ3ExpressionGenerator gen = generatorStack.peek();
			Expr[] assumes;
			if (assumption!=null)
				assumes= new Expr[assumption.size()];
			else
				assumes= new Expr[0];
			for(int i=0;i<assumes.length;i++){
				//assumes[i] = gen.visit(assumption[i]);
				assumes[i] = assumption.get(i).accept(gen, null);
			}
			Status status = solver.check(assumes);
			
			if (status != Status.SATISFIABLE || val == null) {
				logger.finer("Not satisfiable: " + status);				
				if (status == Status.UNSATISFIABLE) {
					if (unsatCore!=null){
						logger.finest("unsat core: ");
						BoolExpr[] usat_core = solver.getUnsatCore();
						for (Expr e : usat_core) {
							logger.finest("  " + e.getSExpr());
							for (int i=0;i<assumes.length;i++)
								if (assumes[i].equals(e))
									unsatCore.add(assumption.get(i));																		
						}
					}
				}

				return translateStatus(status);
			}

			Model model = solver.getModel();
			try {
				if (logger.isLoggable(Level.FINE)) {
					String modelText = model.toString().replace("\n", ", ").trim();
					logger.fine(modelText);
				}
				if (gen.isTainted(model)) {
					model.dispose();
					logger.info("Model is tainted, rechecking ...");
					model = gen.recheckUntainted();
					if (model == null)
						return Result.DONT_KNOW;
				}
				
				///////////////////////// function ///////////
				//gen.funcDecls
				long maxFunc = model.getNumFuncs();
				FuncDecl[] funcDecls = model.getFuncDecls();				
				try {
					for (int i = 0; i < maxFunc; i++) {
						FuncDecl decl = funcDecls[i];

						Symbol sym = null;
						String text = null;
						try {
							sym = decl.getName();
							text = sym.toString().trim();
						} finally {
							sym.dispose();
						}
						
						FunctionExpression<?> func = gen.getOriginFunction(decl);
						if (func==null)
							continue;
						Type<?> type = func.getType();
						//String funcName = func.getFunction().getName();
						Type<?>[] paraTypes = func.getFunction().getParamTypes();
						
						FuncInterp funcInterp = model.getFuncInterp(decl);
						try{													
							for(int j=0;j<funcInterp.getNumEntries();j++){
								Entry et = funcInterp.getEntries()[j];
								Expr[] args = et.getArgs();
								Expr funcValue = et.getValue();
								String funcResult = parValueString(funcValue,type);;
								Object[] paraObj = new Object[paraTypes.length];
								for(int k=0;k<args.length;k++){
									Expr arg = args[k];
									String pValue = parValueString(arg,paraTypes[k]);
									paraObj[k] = paraTypes[k].parse(pValue);
								}								
								String varName = func.buildFunctionCallString(paraObj);
								//System.out.println("function var: "+varName);
								Variable var = Variable.create(type, varName);
								val.setParsedValue(var, funcResult);
							}
						} finally {
							funcInterp.dispose();
						}						
					}
				} finally {
					for (int i = 0; i < funcDecls.length; i++)
						funcDecls[i].dispose();
				}

				Map<String, Variable<?>> freeVars = new HashMap<String, Variable<?>>(freeVarsStack.peek());				
				// FIXME mi: using origVars here fixes the issue that variables
				// occuring only in the
				// scope of quantifiers are part of the valuation. Might it
				// break something
				// else?
				getValuationFromModel(val, model, freeVars,gen);
				/*long max = model.getNumConsts();
				FuncDecl[] decls = model.getConstDecls();				
				try {
					for (int i = 0; i < max; i++) {
						FuncDecl decl = decls[i];

						Symbol sym = null;
						String text = null;
						try {
							sym = decl.getName();
							text = sym.toString().trim();
						} finally {
							sym.dispose();
						}

						Variable<?> v = freeVars.get(text);

						if (v == null) {
							continue;
						}
						freeVars.remove(text);

						AST res = model.getConstInterp(decl);
						try {
							String value = res.toString().trim();
							if (TypeUtil.isRealSort(v) && value.contains("/")) {
								String[] split = value.split("/");
								BigDecimal nom = new BigDecimal(split[0].trim());
								BigDecimal den = new BigDecimal(split[1].trim());
								BigDecimal quot = nom.divide(den, 10, RoundingMode.FLOOR);

								val.setParsedValue(v, quot.toPlainString());
							} else
								val.setParsedValue(v, value);
						} finally {
							res.dispose();
						}
					}
				} finally {
					for (int i = 0; i < decls.length; i++)
						decls[i].dispose();
				}

				for (Variable<?> r : freeVars.values())
					val.setDefaultValue(r);*/

			} finally {
				model.dispose();
			}

			logger.finer("Satisfiable, valuation " + val);
			return Result.SAT;
		} catch (Z3Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	private static String parValueString(AST res,Type<?> type) {		
		boolean isReal=false;
		if (type instanceof BuiltinTypes.DoubleType || type instanceof BuiltinTypes.FloatType)
			isReal=true;
		String value = res.toString().trim();
		if (isReal && value.contains("/")) {
			String[] split = value.split("/");
			BigDecimal nom = new BigDecimal(split[0].trim());
			BigDecimal den = new BigDecimal(split[1].trim());
			BigDecimal quot = nom.divide(den, 10, RoundingMode.FLOOR);
			return quot.toPlainString();
		} else
			return value;	
	}

	public void dispose() {
		while (!generatorStack.isEmpty())
			generatorStack.pop().dispose();
		freeVarsStack.clear();

		try {
			solver.dispose();
		} catch (Z3Exception ex) {
		} finally {
			solver = null;
		}
	}

	protected void finalize() throws Throwable {
		super.finalize();

		if (solver != null)
			dispose();
	}

	@Override
	public void add(List<Expression<Boolean>> expressions) {
		BoolExpr[] exprs = new BoolExpr[expressions.size()];

		NativeZ3ExpressionGenerator gen = generatorStack.peek();

		Map<String, Variable<?>> fvMap = freeVarsStack.peek();

		int i = 0;
		try {
			for (Expression<Boolean> ex : expressions) {
				// logger.finer("Checking " + ex);
				exprs[i++] = gen.generateAssertion(ex);
				Set<Variable<?>> fvs = ExpressionUtil.freeVariables(ex);
				for (Variable<?> v : fvs)
					fvMap.put(v.getName(), v);
			}
			solver.add(exprs);
		} catch (Z3Exception ex) {
			throw new RuntimeException(ex);
		} finally {
			// !!! This is a very important corner case. Sometimes, the
			// expression
			// might just be a single boolean variable, WHICH MAY BE PROTECTED!
			gen.safeDispose(exprs);
		}
	}

	private static Result translateStatus(Status status) {
		switch (status) {
		case SATISFIABLE:
			return Result.SAT;
		case UNSATISFIABLE:
			return Result.UNSAT;
		default: // case UNKNOWN:
			return Result.DONT_KNOW;
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		try {
			for (BoolExpr e : this.solver.getAssertions()) {
				sb.append(e.getSExpr()).append("\n");
			}
		} catch (Z3Exception ex) {
			sb.append("Error: ").append(ex.getMessage());
		}
		return sb.toString();
	}
 
	@Override
	public String toSMTLib() {
		return this.solver.toString();		
	}
}